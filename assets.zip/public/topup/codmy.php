<?php
// DEBUG â€“ boleh buang bila production
error_reporting(E_ALL);
ini_set('display_errors', 1);

// public/topup/mlbbmy.php
require_once '../../config/app.php';
require_once '../../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ========================
   SETTING PAGE
======================== */
$gameSlug        = 'codmy';        // slug dlm table games
$requireZoneId   = 0;               // 1 = perlu Zone ID, 0 = tak perlu
$minzzCashLabel  = 'Minzz Cash';

/* ========================
   USER & MINZZ CASH
======================== */
$userId       = $_SESSION['user_id'] ?? null;
$userName     = $_SESSION['name'] ?? '';
$userRoleRaw  = $_SESSION['role'] ?? 'public';
$userRole     = strtolower($userRoleRaw);
$walletAmount = 0.0;

if ($userId) {
    $stmtU = $conn->prepare("
        SELECT name, role, balance AS saldo
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $stmtU->bind_param('i', $userId);
    $stmtU->execute();
    $resU = $stmtU->get_result()->fetch_assoc();
    $stmtU->close();

    if ($resU) {
        $userName     = $resU['name'] ?? $userName;
        $userRole     = strtolower($resU['role'] ?? $userRole);
        $walletAmount = (float)($resU['saldo'] ?? 0);
    }
}

function format_rm($amount) {
    return 'RM' . number_format((float)$amount, 2, '.', ',');
}

/* ========================
   GAME DATA (games table)
======================== */
$stmtG = $conn->prepare("
    SELECT id, name, slug, publisher, icon, path, description, is_active
    FROM games
    WHERE slug = ? AND is_active = 1
    LIMIT 1
");
$stmtG->bind_param('s', $gameSlug);
$stmtG->execute();
$game = $stmtG->get_result()->fetch_assoc();
$stmtG->close();

if (!$game) {
    http_response_code(404);
    echo "Game dengan slug '{$gameSlug}' tidak ditemui.";
    exit;
}

$gameId      = (int)$game['id'];
$gameName    = $game['name'];
$publisher   = $game['publisher'] ?: 'Unknown';
$heroImage   = $game['icon'];
$heroIcon    = $game['icon'];
$gameDesc    = $game['description'] ?? '';

/* ========================
   PRODUCTS (ikut game_slug)
======================== */
$products = [];
$stmtP = $conn->prepare("
    SELECT id, product_name, icon, public_price, reseller_price, srv_code, sort_order
    FROM products
    WHERE game_slug = ? AND is_active = 1
    ORDER BY sort_order ASC, public_price ASC, id ASC
");
$stmtP->bind_param('s', $gameSlug);
$stmtP->execute();
$resP = $stmtP->get_result();
while ($row = $resP->fetch_assoc()) {
    $products[] = $row;
}
$stmtP->close();

$isReseller = ($userRole === 'reseller');
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Topup <?php echo htmlspecialchars($gameName); ?> - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root{
            --bg-main: #020617;
            --bg-card: #020617;
            --bg-section: #030712;
            --accent-1: #2563eb;
            --accent-2: #38bdf8;
            --accent-soft: rgba(59,130,246,0.25);
            --danger: #f97373;
            --text-main: #ffffff;
            --text-muted: #9ca3af;
            --pill-bg: #020617;
        }

        *{ box-sizing: border-box; }

        body{
            margin: 0;
            font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: radial-gradient(circle at top, #0f172a 0, #020617 60%);
            color: var(--text-main);
        }

        a{ color: inherit; text-decoration: none; }

        .game-page{
            min-height: 100vh;
            background: var(--bg-main);
        }

        .game-main-container{
            max-width: 960px;
            margin: 0 auto;
            padding: 0 10px 120px;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(18px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ======================
           HERO
        ======================= */
        .game-hero-wrap{
            position: relative;
            margin: 0 -10px 60px;
        }

        .game-hero-banner{
            position: relative;
            width: 100%;
            height: 210px;
            overflow: hidden;
            background-color: #020617;
        }

        .game-hero-banner::before{
            content:"";
            position: absolute;
            inset: 0;
            background: url('<?php echo htmlspecialchars($heroImage); ?>') center/cover no-repeat;
            transform: scale(1.05);
            filter: blur(1px);
        }

        .game-hero-banner::after{
            content:"";
            position: absolute;
            inset: 0;
            background: linear-gradient(to bottom,
                    rgba(0,0,0,0.25) 0%,
                    rgba(0,0,0,0.65) 40%,
                    rgba(0,0,0,0.95) 100%);
        }

        @media (min-width: 768px){
            .game-hero-banner{ height: 250px; }
        }

        .game-hero-card.fullwidth{
            position: relative;
            width: 100%;
            margin: -60px 0 0 0;
            padding: 0;
            z-index: 10;
        }

        .game-hero-inner{
            display: flex;
            gap: 16px;
            padding: 18px 18px;
            border-radius: 0 0 26px 26px;
            width: 100%;
            background: linear-gradient(to bottom, rgba(2,6,23,0.7), #020617 85%);
            border-bottom: 1px solid rgba(148,163,184,0.25);
            box-shadow:
                0 18px 38px rgba(0,0,0,0.85),
                0 0 0 1px rgba(15,23,42,0.75);
            animation: fadeUp .45s ease-out both;
        }

        .hero-icon-wrap{
            flex-shrink: 0;
            width: 86px;
            height: 86px;
            border-radius: 24px;
            overflow: hidden;
            background: #020617;
            border: 2px solid rgba(56,189,248,0.6);
            box-shadow: 0 20px 35px rgba(0,0,0,0.7);
            transform: perspective(600px) rotateY(-15deg) rotateX(4deg) rotateZ(-4deg);
            transition: transform .25s ease, box-shadow .25s ease;
        }
        .hero-icon-wrap img{
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .hero-icon-wrap:hover{
            transform: perspective(600px) rotateY(-5deg) rotateX(2deg) rotateZ(-1deg);
            box-shadow: 0 26px 40px rgba(0,0,0,0.85);
        }

        .hero-main{
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-width: 0;
        }
        .hero-title{
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 3px;
        }
        .hero-sub{
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 10px;
        }

        .hero-pills{
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }
        .hero-pill{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 999px;
            background: #020617;
            border: 1px solid rgba(148,163,184,0.55);
            font-size: 11px;
        }
        .hero-pill-dot{
            width: 7px;
            height: 7px;
            border-radius: 999px;
        }
        .dot-green{ background: #22c55e; }
        .dot-blue{ background: #38bdf8; }
        .dot-yellow{ background: #facc15; }

        /* ======================
           TABS
        ======================= */
        .tab-bar{
            margin-top: 22px;
            display: flex;
            border-radius: 999px;
            overflow: hidden;
            border: 1px solid rgba(148,163,184,0.5);
            background: #020617;
        }
        .tab-btn{
            flex:1;
            text-align:center;
            padding: 10px 4px;
            font-size: 14px;
            font-weight: 500;
            cursor:pointer;
        }
        .tab-btn.active{
            background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
        }
        .tab-btn.inactive{
            color: var(--text-muted);
        }

        .tab-content{
            margin-top: 16px;
        }
        .tab-pane{ display:none; }
        .tab-pane.active{ display:block; }

        /* ======================
           FLOW CONTAINER (belakang semua step)
        ======================= */
        .steps-shell{
            margin-top: 10px;
            border-radius: 28px;
            padding: 14px 10px 18px;
            background: radial-gradient(circle at top, #020819, #020617 65%);
            border: 1px solid rgba(31,41,55,0.9);
            box-shadow: 0 20px 40px rgba(0,0,0,0.9);
        }

        /* ======================
           CARDS STEP
        ======================= */
        .step-card{
            margin-top: 12px;
            border-radius: 22px;
            background: #030712;
            border: 1px solid rgba(55,65,81,0.9);
            box-shadow: 0 4px 14px rgba(15,23,42,0.9);
            padding: 14px 16px 16px;
            position: relative;
        }
        .step-header{
            display:flex;
            align-items:center;
            gap:10px;
            margin-bottom: 12px;
        }
        .step-number{
            width: 26px;
            height: 26px;
            border-radius: 9px;
            background: linear-gradient(135deg, var(--accent-1), var(--accent-2));
            display:flex;
            align-items:center;
            justify-content:center;
            font-weight:600;
            font-size:14px;
        }
        .step-title{
            font-size:15px;
            font-weight:600;
        }

        .form-row{
            display:flex;
            flex-direction:column;
            gap:4px;
            margin-bottom:10px;
        }
        .form-row label{
            font-size:12px;
        }
        .form-row small{
            font-size:11px;
            color: var(--text-muted);
        }
        .form-input{
            width:100%;
            padding:9px 11px;
            border-radius:12px;
            border:1px solid rgba(75,85,99,0.9);
            background:#020617;
            color:var(--text-main);
            font-size:13px;
        }
        .form-input::placeholder{
            color:#6b7280;
        }

        .form-grid-2{
            display:grid;
            grid-template-columns: repeat(2,minmax(0,1fr));
            gap: 10px;
        }
        @media(max-width:480px){
            .form-grid-2{ grid-template-columns: 1fr; }
        }

        /* ======================
           PRODUCTS
        ======================= */
        .products-grid{
            display:grid;
            grid-template-columns: repeat(2,minmax(0,1fr));
            gap:12px;
            margin-top:12px;
        }
        @media(min-width:600px){
            .products-grid{ grid-template-columns: repeat(3,minmax(0,1fr)); }
        }

        .product-card{
            cursor:pointer;
        }

        .product-card-inner{
            position:relative;
            border-radius:18px;
            overflow:hidden;
            background:#020617;
            box-shadow:0 10px 22px rgba(15,23,42,0.9);
            transition: transform .15s ease-out, box-shadow .15s ease-out;
        }

        .product-card-header{
            padding:10px 12px 8px;
            background:#1f2933;
            position:relative;
        }
        .product-card-header::before{
            content:"";
            position:absolute;
            inset:0;
            background-image:
                radial-gradient(circle at 1px 1px, rgba(148,163,184,0.4) 1px, transparent 0);
            background-size:6px 6px;
            opacity:0.25;
            pointer-events:none;
        }
        .product-card-header > *{
            position:relative;
            z-index:1;
        }

        .product-name-row{
            display:flex;
            align-items:center;
            gap:10px;
            margin-bottom:6px;
        }
        .product-icon-wrap{
            width:32px;
            height:32px;
            border-radius:10px;
            overflow:hidden;
            background:#020617;
            flex-shrink:0;
            border:1px solid rgba(148,163,184,0.5);
        }
        .product-icon-wrap img{
            width:100%;
            height:100%;
            object-fit:cover;
        }
        .product-name-text{
            flex:1;
            min-width:0;
        }
        .product-name{
            font-size:12px;
            font-weight:600;
            color:#f9fafb;
            white-space:nowrap;
            overflow:hidden;
            text-overflow:ellipsis;
        }

        .product-price-row{
            display:flex;
            align-items:center;
            gap:6px;
        }
        .product-diamond-icon{
            font-size:16px;
        }
        .product-price{
            font-size:13px;
            font-weight:600;
            color:#f97316;
        }

        .product-card-footer{
            padding:6px 8px 8px;
            background:#020617;
            display:flex;
            justify-content:flex-end;
        }

        .product-badge{
            display:flex;
            align-items:center;
            background:#ffffff;
            border-radius:10px;
            padding:4px 6px;
            box-shadow:0 2px 4px rgba(0,0,0,0.25);
            gap:4px;
        }

        .product-badge .badge-icon svg{
            width:12px;
            height:12px;
        }

        .badge-text{
            display:flex;
            flex-direction:column;
            line-height:1.1;
        }
        .badge-text .b1{
            font-size:8px;
            font-weight:600;
            color:#4b5563;
        }
        .badge-text .b2{
            font-size:9px;
            font-weight:700;
            color:#111827;
        }

        .product-card:hover .product-card-inner{
            transform:translateY(-2px);
            box-shadow:0 14px 26px rgba(15,23,42,1);
        }
        .product-card.selected .product-card-inner{
            transform:translateY(-2px);
            box-shadow:0 18px 30px rgba(15,23,42,1);
            outline:1px solid #38bdf8;
        }

        /* ======================
           PAYMENT â€“ MINZZ CASH ONLY
        ======================= */
        .payment-options{
            display:flex;
            flex-direction:column;
            gap:8px;
        }

        .payment-card{
            position:relative;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:12px 14px;
            border-radius:18px;
            background:#111827;
            border:1px solid rgba(75,85,99,0.9);
            box-shadow:0 10px 24px rgba(0,0,0,0.9);
            font-size:13px;
        }

        .payment-card-left{
            display:flex;
            align-items:center;
            gap:12px;
        }
        .payment-icon{
            width:40px;
            height:40px;
            border-radius:999px;
            background: radial-gradient(circle at top,#1e293b,#020617);
            border:1px solid rgba(148,163,184,0.9);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:20px;
        }
        .payment-name{
            font-weight:600;
        }
        .payment-sub{
            font-size:11px;
            color:var(--text-muted);
        }

        .payment-ribbon{
            position:absolute;
            top:-4px;
            right:-4px;
            background:linear-gradient(135deg,#38bdf8,#2563eb);
            color:#f9fafb;
            font-size:10px;
            font-weight:700;
            padding:4px 14px;
            border-radius:0 14px 0 14px;
            box-shadow:0 4px 10px rgba(15,23,42,0.8);
        }

        /* ======================
           STICKY ORDER BAR
        ======================= */
        .order-sticky{
            position:fixed;
            left:0;
            right:0;
            bottom:0;
            z-index:40;
            padding:10px 10px 14px;
            background: linear-gradient(to top, #020617 0, rgba(2,6,23,0.96) 60%, rgba(2,6,23,0));
        }
        .order-card{
            max-width:960px;
            margin:0 auto;
            border-radius:22px;
            background: #020617;
            padding:10px 14px 12px;
            box-shadow:0 -8px 24px rgba(0,0,0,0.95);
            border:1px solid rgba(31,41,55,0.85);
        }
        .order-top{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:10px;
            font-size:12px;
            color:#e5e7eb;
        }
        .order-title{
            font-weight:500;
        }
        .order-meta{
            font-size:11px;
        }
        .order-btn{
            margin-top:8px;
            width:100%;
            border:none;
            border-radius:18px;
            padding:11px 10px;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:8px;
            font-size:14px;
            font-weight:600;
            cursor:pointer;
            background: linear-gradient(135deg, #38bdf8, #2563eb);
            color:#f9fafb;
            box-shadow:0 10px 26px rgba(15,23,42,0.95);
        }
        .order-btn-icon{
            width:18px;
            height:18px;
            border-radius:5px;
            border:2px solid rgba(248,250,252,0.9);
        }

        .order-warning{
            margin-top:6px;
            font-size:11px;
            color:var(--danger);
        }

        .desc-text{
            font-size:13px;
            color:var(--text-muted);
            line-height:1.6;
        }

        /* =============== ORDER CONFIRMATION MODAL =============== */
        @keyframes modalFadeIn {
            from { opacity:0; }
            to   { opacity:1; }
        }
        @keyframes modalSlideUp {
            from { transform: translateY(30px) scale(0.96); opacity:0; }
            to   { transform: translateY(0) scale(1); opacity:1; }
        }

        .modal-backdrop{
            position: fixed;
            inset: 0;
            background: rgba(15,23,42,0.85);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 60;
        }

        .modal-backdrop.show{
            display: flex;
            animation: modalFadeIn .2s ease-out;
        }

        .modal-card{
            width: 92%;
            max-width: 420px;
            background: linear-gradient(145deg,#020617,#020b1f);
            border-radius: 24px;
            padding: 18px 18px 14px;
            box-shadow: 0 24px 60px rgba(0,0,0,0.9);
            border:1px solid rgba(148,163,184,0.4);
            color: #e5e7eb;
            animation: modalSlideUp .22s ease-out;
        }

        .modal-header{
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:10px;
        }

        .modal-title{
            font-size:18px;
            font-weight:700;
        }

        .modal-close{
            border:none;
            background:transparent;
            color:#9ca3af;
            font-size:18px;
            cursor:pointer;
        }

        .modal-sub{
            font-size:12px;
            color:#9ca3af;
            margin-bottom:14px;
        }

        .modal-section{
            border-radius:18px;
            background:#020617;
            border:1px solid rgba(31,41,55,0.9);
            padding:10px 12px 8px;
            margin-bottom:10px;
        }

        .modal-section-title{
            font-size:13px;
            font-weight:600;
            color:#9ca3af;
            margin-bottom:6px;
        }

        .modal-row{
            display:flex;
            justify-content:space-between;
            font-size:13px;
            margin-bottom:4px;
        }

        .modal-total-row{
            border-top:1px solid rgba(55,65,81,0.8);
            margin-top:6px;
            padding-top:6px;
        }
        .modal-total-row .label{
            font-weight:700;
        }
        .modal-total-row .value{
            font-weight:700;
            color:#38bdf8;
        }

        .modal-actions{
            margin-top:10px;
            display:flex;
            flex-direction:column;
            gap:8px;
        }

        .modal-btn-primary{
            width:100%;
            border:none;
            border-radius:16px;
            padding:10px 12px;
            font-size:14px;
            font-weight:600;
            cursor:pointer;
            background:linear-gradient(135deg,#38bdf8,#2563eb);
            color:#f9fafb;
        }

        .modal-btn-secondary{
            width:100%;
            border:none;
            border-radius:16px;
            padding:9px 12px;
            font-size:14px;
            font-weight:500;
            cursor:pointer;
            background:#020617;
            color:#e5e7eb;
            border:1px solid rgba(75,85,99,0.9);
        }
    </style>
</head>
<body>

<div class="game-page">

    <?php include '../../include/header.php'; ?>
    <?php include '../../include/sidebar.php'; ?>

    <main class="game-main-container">

        <!-- HERO -->
        <section class="game-hero-wrap">
            <div class="game-hero-banner"></div>

            <div class="game-hero-card fullwidth">
                <div class="game-hero-inner">
                    <div class="hero-icon-wrap">
                        <img src="<?php echo htmlspecialchars($heroIcon); ?>" alt="<?php echo htmlspecialchars($gameName); ?>">
                    </div>
                    <div class="hero-main">
                        <div class="hero-title">
                            <?php echo htmlspecialchars($gameName); ?>
                        </div>
                        <div class="hero-sub">
                            <?php echo htmlspecialchars($publisher); ?>
                        </div>
                        <div class="hero-pills">
                            <div class="hero-pill">
                                <span class="hero-pill-dot dot-green"></span>
                                Proses pantas
                            </div>
                            <div class="hero-pill">
                                <span class="hero-pill-dot dot-blue"></span>
                                Support 24/7
                            </div>
                            <div class="hero-pill">
                                <span class="hero-pill-dot dot-yellow"></span>
                                Pembayaran selamat
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- TAB BAR -->
        <div class="tab-bar">
            <div class="tab-btn active" data-tab="tab-transaksi">Transaksi</div>
            <div class="tab-btn inactive" data-tab="tab-keterangan">Keterangan</div>
        </div>

        <div class="tab-content">
            <!-- TAB TRANSAKSI -->
            <div id="tab-transaksi" class="tab-pane active">

                <div class="steps-shell">

                    <!-- STEP 1: DATA AKUN -->
                    <section class="step-card">
                        <div class="step-header">
                            <div class="step-number">1</div>
                            <div class="step-title">Masukkan Data Akaun</div>
                        </div>

                        <div class="form-grid-2">
                            <div class="form-row">
                                <label for="user_id">ID (User ID)</label>
                                <input id="user_id" name="user_id" type="text"
                                       class="form-input"
                                       placeholder="Contoh: 123456789">
                            </div>

                            <?php if ($requireZoneId): ?>
                                <div class="form-row">
                                    <label for="zone_id">Zone ID</label>
                                    <input id="zone_id" name="zone_id" type="text"
                                           class="form-input"
                                           placeholder="Contoh: 1234">
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>

                    <!-- STEP 2: PILIH NOMINAL -->
                    <section class="step-card">
                        <div class="step-header">
                            <div class="step-number">2</div>
                            <div class="step-title">Pilih Nominal</div>
                        </div>

                        <div class="products-grid" id="productsGrid">
                            <?php foreach ($products as $p): ?>
                                <?php
                                    $pid   = (int)$p['id'];
                                    $pname = $p['product_name'];
                                    $picon = $p['icon'] ?: (BASE_URL . 'assets/img/icons/diamond-default.png');

                                    $resellerPrice = isset($p['reseller_price']) ? (float)$p['reseller_price'] : 0;
                                    $publicPrice   = (float)$p['public_price'];

                                    $displayPrice = ($isReseller && $resellerPrice > 0)
                                        ? $resellerPrice
                                        : $publicPrice;
                                ?>
                                <div class="product-card"
                                     data-id="<?php echo $pid; ?>"
                                     data-name="<?php echo htmlspecialchars($pname); ?>"
                                     data-price="<?php echo $displayPrice; ?>">

                                    <div class="product-card-inner">
                                        <div class="product-card-header">
                                            <div class="product-name-row">
                                                <div class="product-icon-wrap">
                                                    <img src="<?php echo htmlspecialchars($picon); ?>"
                                                         alt="<?php echo htmlspecialchars($pname); ?>">
                                                </div>
                                                <div class="product-name-text">
                                                    <div class="product-name">
                                                        <?php echo htmlspecialchars($pname); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="product-price-row">
                                                <span class="product-diamond-icon"></span>
                                                <span class="product-price">
                                                    <?php echo format_rm($displayPrice); ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div class="product-card-footer">
                                            <div class="product-badge">
                                                <div class="badge-icon">
                                                    <svg viewBox="0 0 24 24" fill="#111827">
                                                        <path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"></path>
                                                    </svg>
                                                </div>
                                                <div class="badge-text">
                                                    <span class="b1">Penghantaran</span>
                                                    <span class="b2">INSTANT</span>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>

                    <!-- STEP 3: MAKLUMAT KONTAK -->
                    <section class="step-card">
                        <div class="step-header">
                            <div class="step-number">3</div>
                            <div class="step-title">Maklumat Kontak</div>
                        </div>

                        <div class="form-row">
                            <label for="phone">Nombor Whatsapp</label>
                            <input id="phone" name="phone" type="tel"
                                   class="form-input"
                                   placeholder="Contoh: 60123456789">
                            <small>Kami akan hubungi jika perlukan pengesahan tambahan.</small>
                        </div>
                    </section>

                    <!-- STEP 4: PEMBAYARAN -->
                    <section class="step-card">
                        <div class="step-header">
                            <div class="step-number">4</div>
                            <div class="step-title">Pilih Kaedah Pembayaran</div>
                        </div>

                        <div class="payment-options" id="paymentOptions">
                            <div class="payment-card active" data-method="minzz_cash">
                                <div class="payment-card-left">
                                    <div class="payment-icon">
                                        ðŸ’Ž
                                    </div>
                                    <div>
                                        <div class="payment-name"><?php echo htmlspecialchars($minzzCashLabel); ?></div>
                                        <div class="payment-sub">
                                            Baki: <?php echo format_rm($walletAmount); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="payment-ribbon">BEST PRICE</div>
                            </div>
                        </div>
                    </section>

                </div><!-- /.steps-shell -->
                

            </div>

            <!-- TAB KETERANGAN -->
            <div id="tab-keterangan" class="tab-pane">
                <section class="step-card">
                    <div class="step-header">
                        <div class="step-number">i</div>
                        <div class="step-title">Keterangan</div>
                    </div>
                    <div class="desc-text">
                        <?php if ($gameDesc): ?>
                            <?php echo nl2br(htmlspecialchars($gameDesc)); ?>
                        <?php else: ?>
                            Topup <?php echo htmlspecialchars($gameName); ?> di <?php echo APP_NAME; ?>.
                            Proses pantas, harga mesra dan sokongan pelanggan setiap hari.
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        </div>

    </main>

    <!-- STICKY ORDER CARD -->
    <div class="order-sticky">
        <div class="order-card">
            <div class="order-top">
                <div>
                    <div class="order-title" id="orderTitleText">
                        Belum ada produk dipilih.
                    </div>
                    <div class="order-meta" id="orderMetaText">
                        Qty: 0
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:11px;">Minzz Cash:</div>
                    <div style="font-size:13px;font-weight:600;">
                        <?php echo format_rm($walletAmount); ?>
                    </div>
                </div>
            </div>

            <button type="button" id="orderBtn" class="order-btn">
                <span class="order-btn-icon"></span>
                <span>Buat Pesanan Sekarang</span>
            </button>

            <div class="order-warning" id="orderWarning" style="display:none;"></div>
        </div>
    </div>

    <!-- MODAL CONFIRMATION -->
    <div class="modal-backdrop" id="orderConfirmModal">
        <div class="modal-card">
            <div class="modal-header">
                <div class="modal-title">Pengesahan Pembelian</div>
                <button type="button" class="modal-close" id="modalCloseBtn">&times;</button>
            </div>
            <div class="modal-sub">
                Sila pastikan data akaun dan produk yang dipilih adalah betul sebelum meneruskan.
            </div>

            <div class="modal-section">
                <div class="modal-section-title">Butiran Produk</div>
                <div class="modal-row">
                    <span>ID</span>
                    <span id="modalUserIdText"></span>
                </div>
                <div class="modal-row">
                    <span>Item</span>
                    <span id="modalItemText"></span>
                </div>
                <div class="modal-row">
                    <span>Qty</span>
                    <span id="modalQtyText">1</span>
                </div>
            </div>

            <div class="modal-section">
                <div class="modal-section-title">Butiran Pembayaran</div>
                <div class="modal-row">
                    <span>Method</span>
                    <span id="modalMethodText"></span>
                </div>
                <div class="modal-row">
                    <span>Price</span>
                    <span id="modalPriceText"></span>
                </div>
                <div class="modal-row">
                    <span>Payment Fee</span>
                    <span id="modalFeeText">RM0.00</span>
                </div>
                <div class="modal-row modal-total-row">
                    <span class="label">Total</span>
                    <span class="value" id="modalTotalText"></span>
                </div>
            </div>

            <div class="modal-actions">
                <button type="button" class="modal-btn-primary" id="modalConfirmBtn">
                    Sahkan Pembelian
                </button>
                <button type="button" class="modal-btn-secondary" id="modalCancelBtn">
                    Batal
                </button>
            </div>
        </div>
    </div>

    <?php include '../../include/footer.php'; ?>

</div><!-- /.game-page -->

<script>
// TAB LOGIC
document.querySelectorAll('.tab-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
        const target = this.getAttribute('data-tab');
        document.querySelectorAll('.tab-btn').forEach(el=>{
            el.classList.remove('active'); el.classList.add('inactive');
        });
        this.classList.add('active');
        this.classList.remove('inactive');

        document.querySelectorAll('.tab-pane').forEach(pane=>{
            pane.classList.remove('active');
        });
        const targetPane = document.getElementById(target);
        if (targetPane) targetPane.classList.add('active');
    });
});

// PRODUCT SELECT
let selectedProductId   = null;
let selectedProductName = '';
let selectedProductPrice= 0;

const orderTitleEl = document.getElementById('orderTitleText');
const orderMetaEl  = document.getElementById('orderMetaText');

function refreshOrderBar(){
    if (!selectedProductId){
        orderTitleEl.textContent = 'Belum ada produk dipilih.';
        orderMetaEl.textContent  = 'Qty: 0';
    } else {
        orderTitleEl.textContent = selectedProductName;
        orderMetaEl.textContent  = 'Qty: 1 â€¢ Jumlah: ' + formatRM(selectedProductPrice);
    }
}

function formatRM(n){
    n = parseFloat(n || 0);
    return 'RM' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

document.querySelectorAll('.product-card').forEach(function(card){
    card.addEventListener('click', function(){
        document.querySelectorAll('.product-card').forEach(c=>c.classList.remove('selected'));
        this.classList.add('selected');

        selectedProductId    = this.getAttribute('data-id');
        selectedProductName  = this.getAttribute('data-name');
        selectedProductPrice = parseFloat(this.getAttribute('data-price') || '0');

        refreshOrderBar();
    });
});

// PAYMENT SELECT (hanya minzz_cash tapi keep logic)
let selectedMethod = 'minzz_cash';
document.querySelectorAll('[data-method]').forEach(function(card){
    card.addEventListener('click', function(){
        document.querySelectorAll('[data-method]').forEach(c=>c.classList.remove('active'));
        this.classList.add('active');
        selectedMethod = this.getAttribute('data-method');
    });
});

// ===== MODAL ELEMENTS =====
const modalBackdrop   = document.getElementById('orderConfirmModal');
const modalCloseBtn   = document.getElementById('modalCloseBtn');
const modalCancelBtn  = document.getElementById('modalCancelBtn');
const modalConfirmBtn = document.getElementById('modalConfirmBtn');

const modalUserIdText = document.getElementById('modalUserIdText');
const modalItemText   = document.getElementById('modalItemText');
const modalMethodText = document.getElementById('modalMethodText');
const modalPriceText  = document.getElementById('modalPriceText');
const modalTotalText  = document.getElementById('modalTotalText');

const orderWarning    = document.getElementById('orderWarning');

function openModal(){
    modalBackdrop.classList.add('show');
}
function closeModal(){
    modalBackdrop.classList.remove('show');
}

modalCloseBtn.addEventListener('click', closeModal);
modalCancelBtn.addEventListener('click', closeModal);

// ORDER BUTTON â€“ buka MODAL
document.getElementById('orderBtn').addEventListener('click', function(){
    const userIdInput  = document.getElementById('user_id').value.trim();
    const phone        = document.getElementById('phone').value.trim();
    const requireZone  = <?php echo $requireZoneId ? 'true' : 'false'; ?>;
    const zoneInput    = requireZone && document.getElementById('zone_id')
                            ? document.getElementById('zone_id').value.trim()
                            : '';

    orderWarning.style.display = 'none';

    let errorMsg = '';
    if (!userIdInput) errorMsg = 'Sila masukkan User ID.';
    else if (requireZone && !zoneInput) errorMsg = 'Sila masukkan Zone ID.';
    else if (!selectedProductId) errorMsg = 'Sila pilih sekurang-kurangnya satu produk.';
    else if (!phone) errorMsg = 'Sila isi nombor Whatsapp.';

    if (errorMsg){
        orderWarning.textContent = errorMsg;
        orderWarning.style.display = 'block';
        return;
    }

    // isi data ke dalam modal
    modalUserIdText.textContent = userIdInput;
    modalItemText.textContent   = selectedProductName;
    modalMethodText.textContent = (selectedMethod === 'minzz_cash') ? 'Minzz Cash' : selectedMethod;
    modalPriceText.textContent  = formatRM(selectedProductPrice);
    modalTotalText.textContent  = formatRM(selectedProductPrice); // fee 0

    openModal();
});

// BILA TEKAN SAHKAN â€“ submit ke server & redirect invoice
modalConfirmBtn.addEventListener('click', function(){
    const userIdInput  = document.getElementById('user_id').value.trim();
    const phone        = document.getElementById('phone').value.trim();
    const requireZone  = <?php echo $requireZoneId ? 'true' : 'false'; ?>;
    const zoneInput    = requireZone && document.getElementById('zone_id')
                            ? document.getElementById('zone_id').value.trim()
                            : '';


    const formData = new FormData();
    formData.append('game_slug', '<?php echo $gameSlug; ?>');
    formData.append('user_id', userIdInput);
    formData.append('zone_id', zoneInput);
    formData.append('phone', phone);
    formData.append('product_id', selectedProductId);
    formData.append('payment_method', selectedMethod);

    modalConfirmBtn.disabled = true;
    modalConfirmBtn.textContent = 'Memproses...';

    fetch('<?php echo BASE_URL; ?>submit_order.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        modalConfirmBtn.disabled = false;
        modalConfirmBtn.textContent = 'Sahkan Pembelian';

        if (!data || !data.success) {
            orderWarning.textContent = data && data.message ? data.message : 'Ralat tidak diketahui.';
            orderWarning.style.display = 'block';
            closeModal();
            return;
        }

        if (data.invoice_url){
            window.location.href = data.invoice_url;
        } else if (data.custom_order_id){
            window.location.href = '<?php echo BASE_URL; ?>invoice.php?order_id=' + encodeURIComponent(data.custom_order_id);
        } else if (data.transaction_id){
            window.location.href = '<?php echo BASE_URL; ?>invoice.php?order_id=' + encodeURIComponent(data.transaction_id);
        } else {
            window.location.href = '<?php echo BASE_URL; ?>dashboard.php';
        }
    })
    .catch(err => {
        console.error(err);
        modalConfirmBtn.disabled = false;
        modalConfirmBtn.textContent = 'Sahkan Pembelian';
        orderWarning.textContent = 'Ralat sambungan ke server. Cuba lagi.';
        orderWarning.style.display = 'block';
        closeModal();
    });
});
</script>

</body>
</html>