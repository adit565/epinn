<?php
// public/topup/submit_order.php
require_once '../../config/app.php';
require_once '../../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Hanya POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method tidak dibenarkan.'
    ]);
    exit;
}

// Pastikan user login
$sessionUserId = $_SESSION['user_id'] ?? null;
if (!$sessionUserId) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Sila log masuk dahulu sebelum membuat pesanan.'
    ]);
    exit;
}

/* ===============================
   AMBIL INPUT DARI FRONTEND
================================ */
$gameSlug   = trim($_POST['game_slug'] ?? '');
$productId  = (int)($_POST['product_id'] ?? 0);
$gameUserId = trim($_POST['user_id'] ?? '');    // ID dalam game
$zoneId     = trim($_POST['zone_id'] ?? '');
$phone      = trim($_POST['phone'] ?? '');
$payMethod  = $_POST['payment_method'] ?? 'minzz_cash'; // kita lock ke Minzz Cash

if ($gameSlug === '' || !$productId || $gameUserId === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Data tidak lengkap (game, produk atau User ID kosong).'
    ]);
    exit;
}

if ($phone === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Sila isi nombor Whatsapp.'
    ]);
    exit;
}

/* ===============================
   AMBIL USER + WALLET
================================ */
$stmt = $conn->prepare("
    SELECT id, role, balance, is_active
    FROM users
    WHERE id = ? LIMIT 1
");
$stmt->bind_param('i', $sessionUserId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user || (int)$user['is_active'] !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Akaun anda tidak aktif.'
    ]);
    exit;
}

$userRole   = $user['role'];
$userWallet = (float)$user['balance'];

/* ===============================
   AMBIL GAME
================================ */
$stmt = $conn->prepare("
    SELECT id, name
    FROM games
    WHERE slug = ? AND is_active = 1
    LIMIT 1
");
$stmt->bind_param('s', $gameSlug);
$stmt->execute();
$game = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$game) {
    echo json_encode([
        'success' => false,
        'message' => 'Game tidak ditemui.'
    ]);
    exit;
}

$gameId   = (int)$game['id'];
$gameName = $game['name'];

/* ===============================
   AMBIL PRODUK & HARGA
================================ */
$stmt = $conn->prepare("
    SELECT id, product_name, public_price, reseller_price, srv_code
    FROM products
    WHERE id = ? AND game_slug = ? AND is_active = 1
    LIMIT 1
");
$stmt->bind_param('is', $productId, $gameSlug);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    echo json_encode([
        'success' => false,
        'message' => 'Produk tidak ditemui.'
    ]);
    exit;
}

$productName   = $product['product_name'];
$publicPrice   = (float)$product['public_price'];
$resellerPrice = $product['reseller_price'] !== null ? (float)$product['reseller_price'] : null;
$srvCode       = $product['srv_code'];

// Harga ikut role
$isReseller = ($userRole === 'reseller');
$amount     = $isReseller && $resellerPrice !== null && $resellerPrice > 0
    ? $resellerPrice
    : $publicPrice;

// Check wallet cukup?
if ($userWallet < $amount) {
    echo json_encode([
        'success' => false,
        'message' => 'Baki Minzz Cash tidak mencukupi.',
        'current_balance' => $userWallet,
        'required'        => $amount
    ]);
    exit;
}

/* ===============================
   PAYMENT METHOD (MINZZ_CASH)
================================ */
$paymentMethodId = null;
$stmt = $conn->prepare("
    SELECT id FROM payment_methods
    WHERE code = 'MINZZ_CASH' AND is_active = 1
    LIMIT 1
");
$stmt->execute();
$resPM = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($resPM) {
    $paymentMethodId = (int)$resPM['id'];
} else {
    // fallback: id = 4 seperti screenshot kau
    $paymentMethodId = 4;
}

/* ===============================
   MULA TRANSACTION DB
================================ */
$conn->begin_transaction();

try {

    // Lock row user & check balance lagi (untuk keselamatan)
    $stmt = $conn->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
    $stmt->bind_param('i', $sessionUserId);
    $stmt->execute();
    $locked = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$locked || (float)$locked['balance'] < $amount) {
        $conn->rollback();
        echo json_encode([
            'success' => false,
            'message' => 'Baki Minzz Cash tidak mencukupi (semakan terkini).'
        ]);
        exit;
    }

    // Tolak balance
    $stmt = $conn->prepare("
        UPDATE users
        SET balance = balance - ?
        WHERE id = ?
    ");
    $stmt->bind_param('di', $amount, $sessionUserId);
    $stmt->execute();
    $stmt->close();

    // Generate custom order id MINZZ...
    $customOrderId = 'MINZZ' . date('YmdHis') . mt_rand(100, 999);

    // Simpan transaksi (status = processing dulu)
    $targetAccount = $gameUserId . ($zoneId !== '' ? ' (' . $zoneId . ')' : '');
    $qty           = 1;
    $status        = 'processing'; // nanti tukar success/failed lepas call API
    $externalRef   = null;
    $notes         = 'Order dihantar ke Gamevia, menunggu status.';

    $stmt = $conn->prepare("
        INSERT INTO transactions
            (custom_order_id, user_id, product_id, game_id, payment_method_id,
             target_account, qty, amount, public_price, reseller_price,
             status, external_ref, notes, created_at)
        VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param(
        'siiiisidddsss',
        $customOrderId,
        $sessionUserId,
        $productId,
        $gameId,
        $paymentMethodId,
        $targetAccount,
        $qty,
        $amount,
        $publicPrice,
        $resellerPrice,
        $status,
        $externalRef,
        $notes
    );
    $stmt->execute();
    $localTxId = $stmt->insert_id;
    $stmt->close();

    /* ===============================
       CALL GAMEVIA API (ORDER)
    ================================= */

    if (!defined('GAMEVIA_API_KEY')) {
        // Eloknya kau define dalam config/app.php
        throw new Exception('GAMEVIA_API_KEY tidak ditetapkan.');
    }

    $apiUrl  = 'https://api.gamevia.shop/v1/order.php';

    $payload = json_encode([
        'srv_code' => $srvCode,      // WAJIB ikut spec Gamevia
        'user_id'  => $gameUserId,   // WAJIB
        'zone_id'  => ($zoneId === '' ? '0' : $zoneId), // optional
        'no_hp'    => $phone         // optional tapi kita hantar juga
    ]);

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'x-api-key: ' . GAMEVIA_API_KEY
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        // Refund
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->bind_param('di', $amount, $sessionUserId);
        $stmt->execute();
        $stmt->close();

        // Update transaction jadi failed
        $status = 'failed';
        $notes  = 'cURL error: ' . $curlErr;

        $stmt = $conn->prepare("
            UPDATE transactions
            SET status = ?, notes = ?
            WHERE id = ?
        ");
        $stmt->bind_param('ssi', $status, $notes, $localTxId);
        $stmt->execute();
        $stmt->close();

        $conn->commit();

        echo json_encode([
            'success' => false,
            'message' => 'Ralat sambungan ke Gamevia: ' . $curlErr
        ]);
        exit;
    }

    $api = json_decode($response, true);

    if (!is_array($api)) {
        // JSON tak valid
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->bind_param('di', $amount, $sessionUserId);
        $stmt->execute();
        $stmt->close();

        $status = 'failed';
        $notes  = 'Respon Gamevia tidak sah: ' . substr($response, 0, 200);

        $stmt = $conn->prepare("
            UPDATE transactions
            SET status = ?, notes = ?
            WHERE id = ?
        ");
        $stmt->bind_param('ssi', $status, $notes, $localTxId);
        $stmt->execute();
        $stmt->close();

        $conn->commit();

        echo json_encode([
            'success' => false,
            'message' => 'Respon Gamevia tidak sah.'
        ]);
        exit;
    }

    // Kalau Gamevia kata gagal
    if (empty($api['success'])) {
        // Refund wallet
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->bind_param('di', $amount, $sessionUserId);
        $stmt->execute();
        $stmt->close();

        $status = 'failed';
        $notes  = 'Gamevia: ' . ($api['message'] ?? 'Unknown error');

        $stmt = $conn->prepare("
            UPDATE transactions
            SET status = ?, notes = ?
            WHERE id = ?
        ");
        $stmt->bind_param('ssi', $status, $notes, $localTxId);
        $stmt->execute();
        $stmt->close();

        $conn->commit();

        echo json_encode([
            'success' => false,
            'message' => $notes
        ]);
        exit;
    }

    // Gamevia success
    $status      = 'success';
    $externalRef = ($api['custom_order_id'] ?? '') . '|' . ($api['api_order_id'] ?? '');
    $notes       = 'Gamevia status: ' . ($api['status'] ?? 'Success');

    $stmt = $conn->prepare("
        UPDATE transactions
        SET status = ?, external_ref = ?, notes = ?
        WHERE id = ?
    ");
    $stmt->bind_param('sssi', $status, $externalRef, $notes, $localTxId);
    $stmt->execute();
    $stmt->close();

    $conn->commit();

    // URL invoice (guna custom_order_id MINZZ...)
    $base = rtrim(BASE_URL, '/'); // contoh: https://minzzshop.my.id/public
    $invoiceUrl = $base . '/invoice.php?order_id=' . urlencode($customOrderId);

    echo json_encode([
        'success'        => true,
        'message'        => 'Pesanan berjaya dibuat.',
        'transaction_id' => $customOrderId,
        'invoice_url'    => $invoiceUrl,
        'gamevia_raw'    => $api   // kalau nak debug boleh tengok di console
    ]);
    exit;

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Ralat server: ' . $e->getMessage()
    ]);
    exit;
}