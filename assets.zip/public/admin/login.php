<?php
// DEBUG sementara
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kalau dah login:
if (isset($_SESSION['user_id'])) {
    if (($_SESSION['role'] ?? '') === 'admin') {
        // admin yang dah login → direct ke dashboard
        header('Location: index.php');
    } else {
        // user biasa yang cuba buka admin login → balik home
        header('Location: ' . BASE_URL);
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Sila masukkan email dan kata laluan.';
    } else {
        // LOGIN KHAS ADMIN: guna email sahaja
        $sql = "SELECT id, name, email, password, role
                FROM users
                WHERE email = ?
                  AND role = 'admin'
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $error = 'Ralat sistem (prepare).';
        } else {
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $hash = $row['password'];
                $ok   = false;

                if (password_verify($password, $hash)) {
                    $ok = true;
                } elseif ($password === $hash) { // fallback kalau dulu plaintext
                    $ok = true;
                }

                if ($ok) {
                    $_SESSION['user_id']  = $row['id'];
                    $_SESSION['username'] = $row['name'] ?: $row['email'];
                    $_SESSION['role']     = $row['role'];

                    // ✅ lepas berjaya login → direct ke index.php (relative)
                    header('Location: index.php');
                    exit;
                } else {
                    $error = 'Kata laluan salah.';
                }
            } else {
                $error = 'Akaun admin tidak dijumpai untuk email ini.';
            }

            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

    <style>
        :root{
            --bg-main: #020617;
            --text-main: #ffffff;
            --text-muted: #9ca3af;
            --accent-blue: #2563eb;
        }

        *{ box-sizing: border-box; }

        body{
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: #020617;
            color: var(--text-main);
        }

        a{ color: #93c5fd; text-decoration: none; }

        .admin-auth-page{
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 14px;
        }

        .admin-auth-wrap{
            width: 100%;
            max-width: 360px;
        }

        .admin-logo-wrap{
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 18px;
            gap: 10px;
        }

        .admin-logo-circle{
            width: 38px;
            height: 38px;
            border-radius: 999px;
            background: #0b1120;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .admin-logo-circle img{
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .admin-logo-text{
            font-size: 16px;
            font-weight: 600;
        }

        .admin-card-title{
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 4px;
            text-align: center;
        }

        .admin-card-sub{
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 18px;
            text-align: center;
        }

        .auth-group{
            margin-bottom: 14px;
        }

        .auth-label{
            font-size: 12px;
            margin-bottom: 4px;
        }

        .auth-input{
            width: 100%;
            padding: 10px 12px;
            border-radius: 8px;
            border: 1px solid #1e293b;
            background: #0f172a;
            color: var(--text-main);
            font-size: 13px;
        }

        .auth-input:focus{
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 1px rgba(37,99,235,0.5);
        }

        .auth-submit-btn{
            width: 100%;
            padding: 11px 0;
            border-radius: 16px;
            border: none;
            font-size: 14px;
            font-weight: 600;
            background: var(--accent-blue);
            color: #ffffff;
            cursor: pointer;
            margin-top: 4px;
        }

        .auth-submit-btn:active{
            transform: translateY(1px);
        }

        .auth-error{
            background: rgba(248,113,113,0.12);
            border: 1px solid rgba(248,113,113,0.5);
            color: #fecaca;
            padding: 9px 10px;
            border-radius: 10px;
            font-size: 12px;
            margin-bottom: 14px;
        }

        .admin-back-link{
            margin-top: 14px;
            font-size: 12px;
            text-align: center;
            color: var(--text-muted);
        }
    </style>
</head>
<body>

<div class="admin-auth-page">
    <div class="admin-auth-wrap">

        <div class="admin-logo-wrap">
            <div class="admin-logo-circle">
                <!-- tukar ke icon kau -->
                <img src="<?php echo BASE_URL; ?>assets/img/logo-icon.png" alt="MinzzShop">
            </div>
            <div class="admin-logo-text">MinzzShop Admin</div>
        </div>

        <div class="admin-card-title">Admin Login</div>
        <div class="admin-card-sub">
            Log masuk menggunakan akaun admin.
        </div>

        <?php if ($error): ?>
            <div class="auth-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="post" action="">
            <div class="auth-group">
                <div class="auth-label">Email (Admin sahaja)</div>
                <input type="email" name="email" class="auth-input"
                       placeholder="admin@domain.com"
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
            </div>

            <div class="auth-group">
                <div class="auth-label">Kata Laluan</div>
                <input type="password" name="password" class="auth-input" placeholder="••••••••">
            </div>

            <button type="submit" class="auth-submit-btn">Log Masuk Admin</button>
        </form>

        <div class="admin-back-link">
            Kembali ke laman utama? <a href="<?php echo BASE_URL; ?>">Klik di sini</a>
        </div>

    </div>
</div>

</body>
</html>