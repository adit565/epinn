<?php
// public/admin/website.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// Hanya admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: login.php');
    exit;
}

/* =========================
   TARIKH RANGE
========================= */
$today      = date('Y-m-d');
$weekStart  = date('Y-m-d', strtotime('-6 days'));   // 7 hari terkini (termasuk hari ni)
$monthStart = date('Y-m-01');                       // 1 haribulan bulan ni

/* =========================
   HELPER QUERY COUNT
========================= */
function countByDateRange(mysqli $conn, string $table, string $dateCol, ?string $start, ?string $end = null): int {
    if ($start && $end) {
        $sql = "SELECT COUNT(*) AS c FROM {$table} WHERE {$dateCol} IS NOT NULL AND DATE({$dateCol}) BETWEEN ? AND ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $start, $end);
    } elseif ($start && !$end) {
        $sql = "SELECT COUNT(*) AS c FROM {$table} WHERE {$dateCol} IS NOT NULL AND DATE({$dateCol}) = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $start);
    } else {
        return 0;
    }
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return (int)($row['c'] ?? 0);
}

// USERS
$totalUsers      = $conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'] ?? 0;
$todayUsers      = countByDateRange($conn, 'users', 'created_at', $today);
$weekUsers       = countByDateRange($conn, 'users', 'created_at', $weekStart, $today);
$monthUsers      = countByDateRange($conn, 'users', 'created_at', $monthStart, $today);

// TRANSACTIONS = REQUESTS
$totalRequests   = 0;
$todayRequests   = 0;
$weekRequests    = 0;
$monthRequests   = 0;

if ($conn->query("SHOW TABLES LIKE 'transactions'")->num_rows > 0) {
    $res = $conn->query("SELECT COUNT(*) AS c FROM transactions");
    $totalRequests = $res ? ((int)$res->fetch_assoc()['c'] ?? 0) : 0;

    $todayRequests = countByDateRange($conn, 'transactions', 'created_at', $today);
    $weekRequests  = countByDateRange($conn, 'transactions', 'created_at', $weekStart, $today);
    $monthRequests = countByDateRange($conn, 'transactions', 'created_at', $monthStart, $today);
}

/* =========================
   WEBSITE INFO
========================= */
$serverIp   = $_SERVER['SERVER_ADDR'] ?? 'Unknown';
$domain     = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'Unknown');
$phpVersion = PHP_VERSION;
$dbStatus   = $conn->connect_errno ? 'DB Error' : 'Connected';
$dbStatusColor = $conn->connect_errno ? '#fca5a5' : '#4ade80';

// Anggap kalau sampai sini → website ONLINE
$siteStatus      = 'Online';
$siteStatusColor = '#4ade80';

$serverTime = date('d/m/Y H:i:s');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Website Status - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        :root{
            --bg:#020617;
            --card:#0b1120;
            --border:#1e293b;
            --muted:#94a3b8;
            --text:#ffffff;
            --blue:#2563eb;
            --blue-soft:#1d4ed8;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family:'Poppins',sans-serif;
            background:radial-gradient(circle at top,#0f172a 0,#020617 55%);
            color:var(--text);
        }
        .admin-main{
            max-width:1150px;
            margin:0 auto;
            padding:16px;
        }
        @media(min-width:900px){
            .admin-main{ margin-left:240px; }
        }

        .page-head{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            flex-wrap:wrap;
            gap:10px;
            margin-bottom:16px;
        }
        .page-title{
            font-size:20px;
            font-weight:600;
        }
        .page-sub{
            font-size:13px;
            color:var(--muted);
        }

        /* GRID */
        .grid{
            display:grid;
            grid-template-columns:repeat(1,minmax(0,1fr));
            gap:12px;
        }
        @media(min-width:768px){
            .grid-2{ grid-template-columns:repeat(2,minmax(0,1fr)); }
            .grid-3{ grid-template-columns:repeat(3,minmax(0,1fr)); }
        }

        .card{
            background:var(--card);
            border-radius:16px;
            border:1px solid var(--border);
            padding:12px 14px;
            box-shadow:0 14px 36px rgba(0,0,0,0.75);
        }

        .card-title{
            font-size:13px;
            color:var(--muted);
            margin-bottom:4px;
        }
        .card-value-big{
            font-size:24px;
            font-weight:600;
        }
        .card-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-end;
            gap:8px;
        }

        .small-label{
            font-size:11px;
            color:var(--muted);
        }
        .small-value{
            font-size:13px;
            font-weight:500;
        }

        .pill{
            display:inline-flex;
            align-items:center;
            gap:6px;
            padding:3px 10px;
            border-radius:999px;
            font-size:11px;
            background:rgba(148,163,184,0.12);
            color:#e5e7eb;
        }

        /* STATUS DOT */
        .dot{
            width:8px;
            height:8px;
            border-radius:999px;
            background:#4ade80;
        }

        /* SECTION TITLE */
        .section-title{
            margin:18px 0 8px;
            font-size:14px;
            font-weight:600;
        }

        .mono{
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono","Courier New",monospace;
        }
    </style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div>
            <div class="page-title">Website & Traffic</div>
            <div class="page-sub">Overview status website, users dan trafik permintaan (requests).</div>
        </div>
        <div class="pill">
            <span class="dot" style="background:<?php echo $siteStatusColor; ?>"></span>
            <span>Status: <?php echo htmlspecialchars($siteStatus); ?></span>
        </div>
    </div>

    <!-- USERS STATS -->
    <div class="section-title">Users</div>
    <div class="grid grid-4" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">
        <div class="card">
            <div class="card-title">Users Hari Ini</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$todayUsers; ?></div>
                <div class="small-label">Tarikh: <?php echo htmlspecialchars($today); ?></div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Users 7 Hari Terakhir</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$weekUsers; ?></div>
                <div class="small-label"><?php echo htmlspecialchars($weekStart); ?> → <?php echo htmlspecialchars($today); ?></div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Users Bulan Ini</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$monthUsers; ?></div>
                <div class="small-label">Dari: <?php echo htmlspecialchars($monthStart); ?></div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Total Users</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$totalUsers; ?></div>
                <div class="small-label">Sejak mula</div>
            </div>
        </div>
    </div>

    <!-- REQUESTS STATS -->
    <div class="section-title">Requests (Transaksi)</div>
    <div class="grid grid-4" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">
        <div class="card">
            <div class="card-title">Requests Hari Ini</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$todayRequests; ?></div>
                <div class="small-label">Tarikh: <?php echo htmlspecialchars($today); ?></div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Requests 7 Hari Terakhir</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$weekRequests; ?></div>
                <div class="small-label"><?php echo htmlspecialchars($weekStart); ?> → <?php echo htmlspecialchars($today); ?></div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Requests Bulan Ini</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$monthRequests; ?></div>
                <div class="small-label">Dari: <?php echo htmlspecialchars($monthStart); ?></div>
            </div>
        </div>
        <div class="card">
            <div class="card-title">Total Requests</div>
            <div class="card-row">
                <div class="card-value-big"><?php echo (int)$totalRequests; ?></div>
                <div class="small-label">Table: transactions</div>
            </div>
        </div>
    </div>

    <!-- SYSTEM INFO -->
    <div class="section-title">System Info</div>
    <div class="grid">
        <div class="card">
            <div class="card-row" style="margin-bottom:6px;">
                <div>
                    <div class="card-title">Domain</div>
                    <div class="small-value mono"><?php echo htmlspecialchars($domain); ?></div>
                </div>
                <div>
                    <div class="card-title">Server IP</div>
                    <div class="small-value mono"><?php echo htmlspecialchars($serverIp); ?></div>
                </div>
            </div>

            <div class="card-row" style="margin-bottom:6px;">
                <div>
                    <div class="card-title">PHP Version</div>
                    <div class="small-value mono"><?php echo htmlspecialchars($phpVersion); ?></div>
                </div>
                <div>
                    <div class="card-title">DB Status</div>
                    <div class="small-value" style="color:<?php echo $dbStatusColor; ?>">
                        <?php echo htmlspecialchars($dbStatus); ?>
                    </div>
                </div>
            </div>

            <div class="card-row">
                <div>
                    <div class="card-title">Server Time</div>
                    <div class="small-value mono"><?php echo htmlspecialchars($serverTime); ?></div>
                </div>
                <div>
                    <div class="card-title">Website Status</div>
                    <div class="small-value" style="color:<?php echo $siteStatusColor; ?>">
                        <?php echo htmlspecialchars($siteStatus); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div><!-- /.admin-main -->

</body>
</html>