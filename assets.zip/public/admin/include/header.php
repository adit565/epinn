<?php
// public/admin/include/header.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$baseUrl   = defined('BASE_URL') ? BASE_URL : '/';
$adminName = $_SESSION['username'] ?? 'Admin';
?>
<style>
    .admin-header-wrap{
        position: sticky;
        top: 0;
        z-index: 50;
        backdrop-filter: blur(14px);
        background: rgba(15,23,42,0.90);
        border-bottom: 1px solid rgba(148,163,184,0.35);
    }
    .admin-header-inner{
        max-width: 1100px;
        margin: 0 auto;
        padding: 10px 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
    }
    .admin-header-left{
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
    }
    .admin-header-logo-circle{
        width: 32px;
        height: 32px;
        border-radius: 999px;
        overflow: hidden;
        background: #020617;
        border: 1px solid rgba(96,165,250,0.9);
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .admin-header-logo-circle img{
        width: 90%;
        height: 90%;
        object-fit: contain;
        display: block;
    }
    .admin-header-title-wrap{
        display: flex;
        flex-direction: column;
        min-width: 0;
    }
    .admin-header-title{
        font-size: 14px;
        font-weight: 600;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .admin-header-subtitle{
        font-size: 11px;
        color: #9ca3af;
    }

    .admin-header-right{
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .admin-header-user{
        display: none;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: #e5e7eb;
    }
    .admin-header-user-avatar{
        width: 22px;
        height: 22px;
        border-radius: 999px;
        border: 1px solid rgba(148,163,184,0.7);
        background: radial-gradient(circle at top,#1d4ed8,#020617);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
    }

    @media(min-width: 640px){
        .admin-header-user{ display: flex; }
    }

    /* Hamburger kotak */
    .admin-header-menu-btn{
        width: 34px;
        height: 34px;
        border-radius: 10px;
        border: 1px solid rgba(148,163,184,0.6);
        background: radial-gradient(circle at top,#1e293b,#020617);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: transform .12s ease-out,
                    box-shadow .12s ease-out,
                    border-color .12s ease-out,
                    background .12s ease-out;
    }
    .admin-header-menu-btn:hover{
        border-color: rgba(96,165,250,0.9);
        box-shadow: 0 0 0 1px rgba(37,99,235,0.5);
    }
    .admin-header-menu-btn:active{
        transform: translateY(1px) scale(0.98);
    }
    .admin-header-menu-icon{
        width: 16px;
        height: 14px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .admin-header-menu-icon span{
        display: block;
        height: 2px;
        border-radius: 999px;
        background: #e5e7eb;
    }

    /* OPTIONAL: kalau nak main layout wrapper */
    .admin-layout{
        min-height: 100vh;
        background: #020617;
        color: #ffffff;
    }
</style>

<div class="admin-header-wrap">
    <div class="admin-header-inner">
        <div class="admin-header-left">
            <div class="admin-header-logo-circle">
                <!-- tukar ke icon kau sendiri -->
                <img src="<?php echo $baseUrl; ?>assets/img/logo-icon.png" alt="MinzzShop">
            </div>
            <div class="admin-header-title-wrap">
                <div class="admin-header-title">MinzzShop Admin</div>
                <div class="admin-header-subtitle">Panel kawalan</div>
            </div>
        </div>

        <div class="admin-header-right">
            <div class="admin-header-user">
                <div class="admin-header-user-avatar">
                    <?php echo strtoupper(substr($adminName,0,1)); ?>
                </div>
                <div><?php echo htmlspecialchars($adminName); ?></div>
            </div>

            <div class="admin-header-menu-btn" id="adminSidebarToggle" aria-label="Toggle sidebar">
                <div class="admin-header-menu-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('adminSidebarToggle');
    if (!btn) return;

    btn.addEventListener('click', function () {
        // toggle class pada body – sidebar boleh guna class ni
        document.body.classList.toggle('admin-sidebar-open');
    });
});
</script>