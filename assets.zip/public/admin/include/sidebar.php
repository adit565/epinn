<?php
// public/admin/include/sidebar.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$adminName = $_SESSION['name'] ?? 'Admin';
?>
<style>
    /* BACKDROP (mobile only) */
    .admin-sidebar-backdrop{
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.55);
        opacity: 0;
        pointer-events: none;
        transition: opacity .18s ease-out;
        z-index: 39;
    }
    .admin-sidebar-open .admin-sidebar-backdrop{
        opacity: 1;
        pointer-events: auto;
    }

    /* SIDEBAR PANEL */
    .admin-sidebar{
        position: fixed;
        top: 0;
        left: 0;
        width: 240px;
        height: 100vh;
        background: #0a0f1f;
        border-right: 1px solid rgba(148,163,184,0.25);
        box-shadow: 6px 0 24px rgba(0,0,0,0.8);
        transform: translateX(-100%);
        transition: transform .22s ease-out;
        z-index: 40;
        padding: 14px 12px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .admin-sidebar-open .admin-sidebar{
        transform: translateX(0);
    }

    /* Desktop */
    @media(min-width:900px){
        .admin-sidebar{
            transform: translateX(0);
            position: fixed;
        }
        .admin-sidebar-backdrop{
            display: none;
        }
    }

    .admin-sidebar-header{
        display: flex;
        align-items: center;
        gap: 10px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(148,163,184,0.2);
    }
    .admin-sidebar-logo{
        width: 38px;
        height: 38px;
        border-radius: 999px;
        background: #020617;
        border: 1px solid #3b82f6;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }
    .admin-sidebar-logo img{
        width: 90%;
        height: 90%;
        object-fit: contain;
    }
    .admin-sidebar-title{
        font-size: 14px;
        font-weight: 600;
        color: #e5e7eb;
    }
    .admin-sidebar-subtitle{
        font-size: 11px;
        color: #9ca3af;
    }

    .admin-sidebar-user{
        font-size: 12px;
        color: #cbd5e1;
        padding-bottom: 6px;
        border-bottom: 1px solid rgba(148,163,184,0.2);
    }

    .admin-sidebar-menu{
        list-style: none;
        padding: 0;
        margin: 10px 0;
        flex: 1;
    }
    .admin-sidebar-menu li{
        margin-bottom: 6px;
    }
    .admin-sidebar-link{
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px;
        border-radius: 10px;
        font-size: 13px;
        text-decoration: none;
        color: #e5e7eb;
        transition: background .12s ease-out, padding-left .12s;
    }
    .admin-sidebar-link:hover{
        background: rgba(148,163,184,0.15);
        padding-left: 14px;
    }
    .admin-sidebar-link svg{
        width: 18px;
        height: 18px;
    }

    .admin-sidebar-footer{
        margin-top: auto;
        padding-top: 8px;
        font-size: 11px;
        color: #64748b;
        border-top: 1px solid rgba(148,163,184,0.25);
        text-align: center;
    }
</style>

<!-- BACKDROP -->
<div class="admin-sidebar-backdrop"
     onclick="document.body.classList.remove('admin-sidebar-open');">
</div>

<!-- SIDEBAR -->
<div class="admin-sidebar">

    <div class="admin-sidebar-header">
        <div class="admin-sidebar-logo">
            <img src="../assets/img/logo-icon.png" alt="MinzzShop">
        </div>
        <div>
            <div class="admin-sidebar-title">MinzzShop Admin</div>
            <div class="admin-sidebar-subtitle">Panel Kawalan</div>
        </div>
    </div>

    <div class="admin-sidebar-user">
        Log masuk sebagai <strong><?php echo htmlspecialchars($adminName); ?></strong>
    </div>

    <ul class="admin-sidebar-menu">

        <li>
            <a class="admin-sidebar-link" href="index.php">
                <svg fill="none" stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <path d="M3 13h6v8H3zM9 3h6v18H9zM15 9h6v12h-6z"/>
                </svg>
                Dashboard
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="games.php">
                <svg fill="none" stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <path d="M6 20l3-8-3-8h4l3 8-3 8H6zM14 4h4v16h-4"/>
                </svg>
                Games
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="products.php">
                <svg fill="none" stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <path d="M4 7l8-4 8 4v10l-8 4-8-4z"/>
                    <path d="M4 7l8 4 8-4"/>
                    <path d="M12 11v10"/>
                </svg>
                Products
            </a>
        </li>

        <!-- ✅ PROVIDER MENU (ADDED) -->
        <li>
            <a class="admin-sidebar-link" href="provider.php">
                <svg viewBox="0 0 24 24" fill="none"
                     stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 7h16" />
                    <path d="M4 12h16" />
                    <path d="M4 17h16" />
                    <path d="M7 7v10" />
                    <path d="M17 7v10" />
                </svg>
                Provider
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="banners.php">
                <svg fill="none" stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <path d="M5 4h14v9l-4-2-3 2-3-2-4 2z"/>
                    <path d="M5 20h14"/>
                </svg>
                Banners
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="transactions.php">
                <svg fill="none" stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <rect x="3" y="4" width="18" height="14" rx="2"/>
                    <path d="M7 9h5M7 13h3M15 13h2"/>
                </svg>
                Transaksi
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="site-settings.php">
                <svg viewBox="0 0 24 24" fill="none"
                     stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3" />
                    <path d="M19.4 15a1.8 1.8 0 0 0 .3 1.9l.1.1a1 1 0 0 1-1.4 1.4l-.1-.1a1.8 1.8 0 0 0-1.9-.3 1.8 1.8 0 0 0-1.1 1.6V20a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-.2a1.8 1.8 0 0 0-1.1-1.6 1.8 1.8 0 0 0-1.9.3l-.1.1a1 1 0 0 1-1.4-1.4l.1-.1a1.8 1.8 0 0 0 .3-1.9 1.8 1.8 0 0 0-1.6-1.1H4a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h.2a1.8 1.8 0 0 0 1.6-1.1 1.8 1.8 0 0 0-.3-1.9l-.1-.1A1 1 0 0 1 6.8 5l.1.1a1.8 1.8 0 0 0 1.9.3A1.8 1.8 0 0 0 9.9 3.8V4a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v.2a1.8 1.8 0 0 0 1.1 1.6 1.8 1.8 0 0 0 1.9-.3l.1-.1A1 1 0 1 1 20 6.8l-.1.1a1.8 1.8 0 0 0-.3 1.9 1.8 1.8 0 0 0 1.6 1.1H21a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1h-.2a1.8 1.8 0 0 0-1.4 1.1z"/>
                </svg>
                Site Settings
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="<?php echo $baseUrl; ?>website.php">
                <svg viewBox="0 0 24 24" fill="none" stroke="#e5e7eb" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="4" width="18" height="14" rx="2"/>
                    <path d="M3 9h18"/>
                </svg>
                Website
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="users.php">
                <svg fill="none" stroke="#e5e7eb" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <circle cx="9" cy="8" r="3"/>
                    <path d="M4 20c0-3 2-5 5-5"/>
                    <circle cx="17" cy="9" r="2.5"/>
                    <path d="M16 20c0-2 1.3-3.5 3-4"/>
                </svg>
                Users
            </a>
        </li>

        <li>
            <a class="admin-sidebar-link" href="../logout.php" style="color:#fca5a5;">
                <svg fill="none" stroke="#fca5a5" stroke-width="1.7"
                     stroke-linecap="round" stroke-linejoin="round"
                     viewBox="0 0 24 24">
                    <path d="M10 5H5v14h5"/>
                    <path d="M15 9l3 3-3 3"/>
                    <path d="M8 12h10"/>
                </svg>
                Logout
            </a>
        </li>

    </ul>

    <div class="admin-sidebar-footer">
        © <?php echo date("Y"); ?> MinzzShop
    </div>

</div>