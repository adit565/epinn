<?php
// public/admin/file_manager.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// ==== AUTH ADMIN SAHAJA ====
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ==============================
   ROOT FILE MANAGER (PROJECT ROOT)
================================ */
$ROOT_PATH = realpath(__DIR__ . '/../../'); // contoh: /var/www/html
if ($ROOT_PATH === false) {
    die("Root path tidak dijumpai.");
}

/**
 * Resolve path supaya tak boleh keluar dari ROOT_PATH
 */
function fm_resolve_path($root, $rel)
{
    $rel = trim($rel);
    if ($rel === '' || $rel === '.' || $rel === '/') {
        return $root;
    }

    // Buang leading slash
    $rel = ltrim($rel, '/');

    $full = realpath($root . DIRECTORY_SEPARATOR . $rel);
    if ($full === false) {
        return false;
    }

    // Pastikan masih dalam root
    if (strpos($full, $root) !== 0) {
        return false;
    }

    return $full;
}

/**
 * Dapatkan path relatif untuk display / link
 */
function fm_rel_path($root, $full)
{
    if (strpos($full, $root) !== 0) {
        return '';
    }
    $rel = substr($full, strlen($root));
    return ltrim($rel, DIRECTORY_SEPARATOR);
}

/**
 * Check sama ada extension ini text-based
 */
function fm_is_text_file($path)
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $textExts = ['php','html','htm','css','js','txt','json','xml','md','ini','env','log'];
    if (in_array($ext, $textExts, true)) {
        return true;
    }

    // fallback: kalau tak ada extension, anggap text
    if ($ext === '') return true;

    return false;
}

/* ==============================
   HANDLE SAVE FILE (POST)
================================ */
$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_file') {
    $pParam = $_POST['p'] ?? '';
    $targetFile = fm_resolve_path($ROOT_PATH, $pParam);

    if ($targetFile === false || !is_file($targetFile)) {
        $error = 'File tidak sah atau tidak dijumpai.';
    } else {
        // optional: hadkan size editing (contoh 1MB)
        $size = filesize($targetFile);
        if ($size !== false && $size > 1024 * 1024) { // > 1MB
            $error = 'File terlalu besar untuk diedit melalui browser (>1MB).';
        } else {
            $newContent = $_POST['file_content'] ?? '';

            // backup sebelum tulis
            $backupDir = $ROOT_PATH . '/backups_filemanager';
            if (!is_dir($backupDir)) {
                @mkdir($backupDir, 0777, true);
            }

            $relPath = fm_rel_path($ROOT_PATH, $targetFile);
            $safeName = str_replace(['/', '\\'], '_', $relPath);
            $backupPath = $backupDir . '/backup_' . $safeName . '_' . date('Ymd_His') . '.bak';
            @copy($targetFile, $backupPath);

            // tulis file
            $bytes = @file_put_contents($targetFile, $newContent);
            if ($bytes === false) {
                $error = 'Gagal menyimpan file. Semak permission folder/server.';
            } else {
                $message = 'File berjaya disimpan. (' . $bytes . ' bytes)';
            }
        }
    }

    // Pastikan kita kekal di file yang sama selepas save
    $_GET['p'] = $pParam;
}

/* ==============================
   TENTUKAN TARGET (DIR / FILE)
================================ */
$p = $_GET['p'] ?? '';
$targetPath = fm_resolve_path($ROOT_PATH, $p);

// kalau invalid -> fallback ke root
if ($targetPath === false) {
    $targetPath = $ROOT_PATH;
    $p = '';
}

$mode = 'dir';
if (is_dir($targetPath)) {
    $mode = 'dir';
} elseif (is_file($targetPath)) {
    $mode = 'file';
} else {
    $targetPath = $ROOT_PATH;
    $mode = 'dir';
    $p = '';
}

// untuk breadcrumb
$currentRel = fm_rel_path($ROOT_PATH, $targetPath);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>File Manager - <?php echo APP_NAME; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        :root{
            --bg:#020617;
            --card:#020617;
            --border:#1e293b;
            --muted:#94a3b8;
            --text:#ffffff;
            --blue:#2563eb;
            --blue-soft:#1d4ed8;
            --danger:#ef4444;
            --success:#22c55e;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family:'Poppins',sans-serif;
            background:var(--bg);
            color:var(--text);
        }

        .admin-main{
            max-width:1100px;
            margin:0 auto;
            padding:16px;
        }
        @media(min-width:900px){
            .admin-main{ margin-left:240px; }
        }

        .page-head{
            margin-bottom:14px;
        }
        .page-title{
            font-size:20px;
            font-weight:600;
        }
        .page-sub{
            font-size:13px;
            color:var(--muted);
        }

        .breadcrumb{
            display:flex;
            flex-wrap:wrap;
            gap:6px;
            font-size:12px;
            margin-top:8px;
            align-items:center;
        }
        .crumb{
            padding:3px 7px;
            border-radius:999px;
            border:1px solid rgba(148,163,184,0.4);
            background:#020617;
            cursor:pointer;
        }
        .crumb span{
            color:#e5e7eb;
        }
        .crumb-current{
            background:#1e293b;
            border-color:#4b5563;
        }
        .crumb a{
            color:inherit;
            text-decoration:none;
        }

        .file-layout{
            display:grid;
            grid-template-columns: minmax(0, 1.1fr) minmax(0, 1.4fr);
            gap:12px;
            margin-top:12px;
        }
        @media(max-width:800px){
            .file-layout{
                grid-template-columns: 1fr;
            }
        }

        .card{
            background:var(--card);
            border-radius:16px;
            border:1px solid var(--border);
            padding:10px;
            box-shadow:0 18px 40px rgba(0,0,0,0.85);
        }

        .card-title{
            font-size:14px;
            font-weight:500;
            margin-bottom:6px;
        }
        .card-sub{
            font-size:11px;
            color:var(--muted);
            margin-bottom:8px;
        }

        .alert{
            padding:8px 10px;
            border-radius:10px;
            font-size:12px;
            margin-bottom:8px;
        }
        .alert-success{
            background:rgba(34,197,94,0.1);
            border:1px solid rgba(34,197,94,0.5);
            color:#bbf7d0;
        }
        .alert-danger{
            background:rgba(239,68,68,0.1);
            border:1px solid rgba(239,68,68,0.5);
            color:#fecaca;
        }

        .file-list{
            max-height:450px;
            overflow:auto;
            border-radius:12px;
            border:1px solid #111827;
            background:#020617;
        }

        .file-row{
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:7px 10px;
            font-size:12px;
            border-bottom:1px solid #0f172a;
        }
        .file-row:last-child{
            border-bottom:none;
        }
        .file-left{
            display:flex;
            align-items:center;
            gap:8px;
            min-width:0;
        }
        .file-icon{
            width:22px;
            height:22px;
            border-radius:6px;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:13px;
        }
        .icon-dir{
            background:rgba(37,99,235,0.18);
            color:#bfdbfe;
        }
        .icon-file{
            background:rgba(148,163,184,0.18);
            color:#e5e7eb;
        }
        .file-name{
            white-space:nowrap;
            overflow:hidden;
            text-overflow:ellipsis;
        }
        .file-right{
            text-align:right;
            font-size:11px;
            color:var(--muted);
            flex-shrink:0;
        }
        .file-row a{
            text-decoration:none;
            color:inherit;
        }

        .tag-small{
            display:inline-block;
            padding:2px 6px;
            border-radius:999px;
            border:1px solid #0f172a;
            font-size:10px;
            color:#cbd5f5;
        }

        .editor-textarea{
            width:100%;
            min-height:380px;
            border-radius:12px;
            border:1px solid #111827;
            background:#020617;
            color:#e5e7eb;
            font-family:"SF Mono", Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            font-size:12px;
            padding:10px;
            line-height:1.5;
            resize:vertical;
            outline:none;
            box-shadow:inset 0 0 0 1px rgba(15,23,42,0.85);
        }

        .editor-footer{
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:10px;
            margin-top:8px;
            font-size:11px;
            color:var(--muted);
            flex-wrap:wrap;
        }

        .btn-primary{
            padding:7px 16px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,var(--blue),var(--blue-soft));
            color:#fff;
            font-size:12px;
            cursor:pointer;
            box-shadow:0 8px 20px rgba(37,99,235,0.6);
        }
        .btn-primary:disabled{
            opacity:0.6;
            cursor:not-allowed;
        }
    </style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div class="page-title">File Manager</div>
        <div class="page-sub">
            Browse & edit file dalam project root. 
            <strong>Guna dengan sangat hati-hati – sebarang silap boleh rosakkan website.</strong>
        </div>

        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <?php
            // root crumb
            $crumbs = [];
            $crumbs[] = [
                'label' => 'root',
                'path'  => ''
            ];
            if ($currentRel !== '') {
                $parts = explode('/', $currentRel);
                $acc = '';
                foreach ($parts as $part) {
                    if ($part === '') continue;
                    $acc = ($acc === '') ? $part : $acc . '/' . $part;
                    $crumbs[] = [
                        'label' => $part,
                        'path'  => $acc
                    ];
                }
            }

            $lastIndex = count($crumbs) - 1;
            foreach ($crumbs as $i => $c):
                $isCurrent = ($i === $lastIndex);
            ?>
                <div class="crumb <?php echo $isCurrent ? 'crumb-current' : ''; ?>">
                    <?php if ($isCurrent): ?>
                        <span><?php echo htmlspecialchars($c['label']); ?></span>
                    <?php else: ?>
                        <a href="?p=<?php echo urlencode($c['path']); ?>">
                            <span><?php echo htmlspecialchars($c['label']); ?></span>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="file-layout">

        <!-- ========== KIRI: LIST FOLDER / FILE ========== -->
        <div class="card">
            <div class="card-title">Explorer</div>
            <div class="card-sub">
                Lokasi: <code><?php echo htmlspecialchars($targetPath); ?></code>
            </div>

            <div class="file-list">
                <?php
                if ($mode === 'dir') {
                    // parent link kalau bukan root
                    if ($targetPath !== $ROOT_PATH) {
                        $parent = dirname($targetPath);
                        $parentRel = fm_rel_path($ROOT_PATH, $parent);
                        ?>
                        <div class="file-row">
                            <div class="file-left">
                                <div class="file-icon icon-dir">⬆</div>
                                <div class="file-name">
                                    <a href="?p=<?php echo urlencode($parentRel); ?>">.. (Parent)</a>
                                </div>
                            </div>
                            <div class="file-right"></div>
                        </div>
                        <?php
                    }

                    $items = scandir($targetPath);
                    $dirs  = [];
                    $files = [];

                    foreach ($items as $item) {
                        if ($item === '.' || $item === '..') continue;
                        $full = $targetPath . DIRECTORY_SEPARATOR . $item;
                        $real = realpath($full);
                        if ($real === false || strpos($real, $ROOT_PATH) !== 0) {
                            continue;
                        }
                        if (is_dir($real)) $dirs[] = $item;
                        else $files[] = $item;
                    }

                    sort($dirs, SORT_NATURAL | SORT_FLAG_CASE);
                    sort($files, SORT_NATURAL | SORT_FLAG_CASE);

                    foreach ($dirs as $d):
                        $rel = fm_rel_path($ROOT_PATH, $targetPath . DIRECTORY_SEPARATOR . $d);
                    ?>
                        <div class="file-row">
                            <div class="file-left">
                                <div class="file-icon icon-dir">📁</div>
                                <div class="file-name">
                                    <a href="?p=<?php echo urlencode($rel); ?>">
                                        <?php echo htmlspecialchars($d); ?>
                                    </a>
                                </div>
                            </div>
                            <div class="file-right">
                                <span class="tag-small">Folder</span>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php foreach ($files as $f):
                        $full = $targetPath . DIRECTORY_SEPARATOR . $f;
                        $rel  = fm_rel_path($ROOT_PATH, $full);
                        $size = filesize($full);
                        $sizeText = $size !== false ? number_format($size / 1024, 1) . ' KB' : '-';
                        $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
                    ?>
                        <div class="file-row">
                            <div class="file-left">
                                <div class="file-icon icon-file">📄</div>
                                <div class="file-name">
                                    <a href="?p=<?php echo urlencode($rel); ?>">
                                        <?php echo htmlspecialchars($f); ?>
                                    </a>
                                </div>
                            </div>
                            <div class="file-right">
                                <div><?php echo htmlspecialchars($sizeText); ?></div>
                                <div><?php echo $ext ? htmlspecialchars($ext) : '<span style="opacity:0.5;">noext</span>'; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (empty($dirs) && empty($files)): ?>
                        <div class="file-row">
                            <div class="file-left">
                                <div class="file-name" style="color:var(--muted);">
                                    Folder ini kosong.
                                </div>
                            </div>
                            <div class="file-right"></div>
                        </div>
                    <?php endif; ?>

                <?php } else { // mode = file ?>

                    <?php
                    $rel = fm_rel_path($ROOT_PATH, $targetPath);
                    $fileSize = filesize($targetPath);
                    $sizeText = $fileSize !== false ? number_format($fileSize / 1024, 1) . ' KB' : '-';
                    $ext = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
                    ?>
                    <div class="file-row">
                        <div class="file-left">
                            <div class="file-icon icon-file">📄</div>
                            <div class="file-name">
                                <?php echo htmlspecialchars(basename($targetPath)); ?>
                            </div>
                        </div>
                        <div class="file-right">
                            <div><?php echo htmlspecialchars($sizeText); ?></div>
                            <div><?php echo $ext ? htmlspecialchars($ext) : 'noext'; ?></div>
                        </div>
                    </div>

                    <div class="file-row">
                        <div class="file-left">
                            <div class="file-name">
                                Relatif: <code><?php echo htmlspecialchars($rel); ?></code>
                            </div>
                        </div>
                        <div class="file-right">
                            <?php
                            $mtime = filemtime($targetPath);
                            if ($mtime) {
                                echo 'Updated: ' . date('d/m/Y H:i', $mtime);
                            }
                            ?>
                        </div>
                    </div>

                    <div class="file-row">
                        <div class="file-left">
                            <span class="tag-small">
                                <?php echo fm_is_text_file($targetPath) ? 'Text file (boleh edit)' : 'Mungkin binary / bukan text'; ?>
                            </span>
                        </div>
                        <div class="file-right"></div>
                    </div>

                <?php } ?>
            </div>
        </div>

        <!-- ========== KANAN: EDITOR / INFO ========== -->
        <div class="card">
            <div class="card-title">Editor</div>
            <div class="card-sub">
                <?php if ($mode === 'dir'): ?>
                    Pilih file di sebelah kiri untuk edit kandungan.
                <?php else: ?>
                    Edit kandungan file yang dipilih. Backup auto akan dibuat setiap kali simpan.
                <?php endif; ?>
            </div>

            <?php if ($mode === 'file'): ?>
                <?php
                $fileSize  = filesize($targetPath);
                $isText    = fm_is_text_file($targetPath);
                $tooBig    = ($fileSize !== false && $fileSize > 1024 * 1024); // >1MB
                ?>

                <?php if (!$isText): ?>
                    <div class="alert alert-danger">
                        File ini nampaknya <strong>bukan text / mungkin binary</strong> (contoh .png, .jpg, .zip).
                        Demi keselamatan, editor text dimatikan.
                    </div>
                <?php elseif ($tooBig): ?>
                    <div class="alert alert-danger">
                        Saiz file &gt; 1MB. Editor dimatikan untuk elak lag / timeout.<br>
                        Kalau perlu edit, gunakan akses direct server (FTP / SSH).
                    </div>
                <?php endif; ?>

                <?php
                $fileContent = '';
                if ($isText && !$tooBig && is_readable($targetPath)) {
                    $fileContent = file_get_contents($targetPath);
                    if ($fileContent === false) {
                        $fileContent = "// Gagal membaca isi file.";
                    }
                }
                ?>

                <?php if ($isText && !$tooBig): ?>
                    <form method="post" id="fileEditForm">
                        <input type="hidden" name="action" value="save_file">
                        <input type="hidden" name="p" value="<?php echo htmlspecialchars(fm_rel_path($ROOT_PATH, $targetPath)); ?>">

                        <textarea name="file_content" class="editor-textarea"
                                  spellcheck="false"><?php echo htmlspecialchars($fileContent); ?></textarea>

                        <div class="editor-footer">
                            <div>
                                Saiz: <?php echo $fileSize !== false ? number_format($fileSize/1024,1).' KB' : '?'; ?> ·
                                Lokasi: <code><?php echo htmlspecialchars(fm_rel_path($ROOT_PATH, $targetPath)); ?></code>
                            </div>
                            <button type="submit" class="btn-primary" id="btnSave">Simpan Perubahan</button>
                        </div>
                    </form>
                <?php else: ?>
                    <div style="font-size:12px;color:var(--muted);">
                        Tiada preview editor untuk file ini.<br>
                        Extension: <strong><?php echo htmlspecialchars($ext ?? ''); ?></strong><br>
                        Saiz: <?php echo $fileSize !== false ? number_format($fileSize/1024,1).' KB' : '?'; ?>
                    </div>
                <?php endif; ?>

            <?php else: ?>
                <div style="font-size:12px;color:var(--muted);">
                    File manager ini membenarkan:
                    <ul style="margin-top:4px;padding-left:18px;">
                        <li>Browse semua folder & file di project root.</li>
                        <li>Edit file text (php, html, css, js, txt, dll) terus dari browser.</li>
                        <li>Backup setiap kali simpan di <code>/backups_filemanager</code>.</li>
                    </ul>
                    <strong>Tip:</strong> elakkan edit file sistem sensitif (contoh config/database) kecuali betul-betul perlu.
                </div>
            <?php endif; ?>
        </div>

    </div>

</div>

<script>
// Optional: confirm sebelum submit
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('fileEditForm');
    const btn  = document.getElementById('btnSave');
    if (form && btn) {
        form.addEventListener('submit', function (e) {
            if (!confirm('Simpan perubahan pada file ini? Pastikan tiada syntax error.')) {
                e.preventDefault();
            } else {
                btn.disabled = true;
                btn.textContent = 'Menyimpan...';
            }
        });
    }
});
</script>

</body>
</html>