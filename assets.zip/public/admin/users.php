<?php
// public/admin/users.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// AUTH ADMIN
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ============================================================
   HELPER: FETCH USER BY ID (WITHOUT PASSWORD)
============================================================ */
function getUserById($conn, $id) {
    $stmt = $conn->prepare("
        SELECT id, name, email, phone, balance, role, is_active, created_at
        FROM users
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res  = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();
    return $user;
}

/* ============================================================
   AJAX: SAVE USER (ADD / EDIT)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_user') {
    header('Content-Type: application/json');

    $id        = (int)($_POST['id'] ?? 0);
    $name      = trim($_POST['name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $phone     = trim($_POST['phone'] ?? '');
    $role      = trim($_POST['role'] ?? 'public');
    $password  = trim($_POST['password'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if ($name === '' || $email === '') {
        echo json_encode([
            'success' => false,
            'message' => 'Nama & email wajib diisi.'
        ]);
        exit;
    }

    $allowedRoles = ['admin','reseller','public'];
    if (!in_array($role, $allowedRoles, true)) {
        $role = 'public';
    }

    if ($id > 0) {
        // UPDATE user
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("
                UPDATE users
                SET name=?, email=?, phone=?, role=?, is_active=?, password=?
                WHERE id=?
            ");
            $stmt->bind_param(
                "ssssisi",
                $name, $email, $phone, $role, $is_active, $hash, $id
            );
        } else {
            $stmt = $conn->prepare("
                UPDATE users
                SET name=?, email=?, phone=?, role=?, is_active=?
                WHERE id=?
            ");
            $stmt->bind_param(
                "ssssii",
                $name, $email, $phone, $role, $is_active, $id
            );
        }
        $stmt->execute();
        $stmt->close();
        $newId = $id;
    } else {
        // INSERT user baru – password wajib
        if ($password === '') {
            echo json_encode([
                'success' => false,
                'message' => 'Password wajib untuk user baru.'
            ]);
            exit;
        }
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("
            INSERT INTO users (name, email, phone, balance, password, role, is_active)
            VALUES (?, ?, ?, 0, ?, ?, ?)
        ");
        $stmt->bind_param(
            "sssssi",
            $name, $email, $phone, $hash, $role, $is_active
        );
        $stmt->execute();
        $newId = $stmt->insert_id;
        $stmt->close();
    }

    $user = getUserById($conn, $newId);

    echo json_encode([
        'success' => true,
        'message' => 'User berjaya disimpan.',
        'user'    => $user
    ]);
    exit;
}

/* ============================================================
   AJAX: UPDATE BALANCE (ADD / DEDUCT)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'balance') {
    header('Content-Type: application/json');

    $id    = (int)($_POST['id'] ?? 0);
    $mode  = $_POST['mode'] ?? 'add'; // add / deduct
    $amount = (float)($_POST['amount'] ?? 0);

    if ($id <= 0 || $amount <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'ID user & jumlah sah diperlukan.'
        ]);
        exit;
    }

    // Ambil balance semasa
    $stmt = $conn->prepare("SELECT balance FROM users WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();

    if (!$row) {
        echo json_encode([
            'success' => false,
            'message' => 'User tidak dijumpai.'
        ]);
        exit;
    }

    $currentBalance = (float)$row['balance'];
    $newBalance = $currentBalance;

    if ($mode === 'add') {
        $newBalance = $currentBalance + $amount;
    } else {
        // deduct
        if ($amount > $currentBalance) {
            echo json_encode([
                'success' => false,
                'message' => 'Jumlah tolak melebihi baki semasa.'
            ]);
            exit;
        }
        $newBalance = $currentBalance - $amount;
    }

    $stmt = $conn->prepare("UPDATE users SET balance=? WHERE id=?");
    $stmt->bind_param("di", $newBalance, $id);
    $stmt->execute();
    $stmt->close();

    $user = getUserById($conn, $id);

    echo json_encode([
        'success' => true,
        'message' => 'Balance berjaya dikemaskini.',
        'user'    => $user
    ]);
    exit;
}

/* ============================================================
   AJAX: DELETE USER
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_user') {
    header('Content-Type: application/json');

    $id = (int)($_POST['id'] ?? 0);

    if ($id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'ID user tidak sah.'
        ]);
        exit;
    }

    // Jangan bagi admin delete diri sendiri
    if ($id === (int)($_SESSION['user_id'] ?? 0)) {
        echo json_encode([
            'success' => false,
            'message' => 'Tak boleh delete akaun yang sedang login.'
        ]);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected < 1) {
        echo json_encode([
            'success' => false,
            'message' => 'User tidak dijumpai / gagal delete.'
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'User berjaya dipadam.'
    ]);
    exit;
}

/* ============================================================
   LOAD LIST USERS (UNTUK TABLE)
============================================================ */
$users = [];
$res = $conn->query("
    SELECT id, name, email, phone, balance, role, is_active, created_at
    FROM users
    ORDER BY id DESC
");
while ($row = $res->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Users - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    :root{
        --bg:#020617;
        --card:#0a0f1f;
        --border:#1e293b;
        --muted:#94a3b8;
        --text:#ffffff;
        --blue:#2563eb;
        --blue-soft:#1d4ed8;
    }
    *{ box-sizing:border-box; }
    body{
        margin:0;
        font-family:'Poppins',sans-serif;
        background:var(--bg);
        color:var(--text);
    }

    .admin-main{
        max-width:1100px;
        margin:0 auto;
        padding:16px;
    }
    @media(min-width:900px){
        .admin-main{ margin-left:240px; }
    }

    .page-head{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:8px;
        flex-wrap:wrap;
        margin-bottom:16px;
    }
    .page-title{
        font-size:20px;
        font-weight:600;
    }
    .page-sub{
        font-size:13px;
        color:var(--muted);
    }

    .btn-primary{
        padding:8px 14px;
        border-radius:999px;
        border:none;
        background:linear-gradient(135deg,var(--blue),var(--blue-soft));
        color:#fff;
        font-size:13px;
        cursor:pointer;
        box-shadow:0 8px 20px rgba(37,99,235,0.6);
    }

    .users-table-wrap{
        margin-top:4px;
        background:var(--card);
        border-radius:16px;
        border:1px solid var(--border);
        padding:10px;
        overflow-x:auto;
    }
    table{
        width:100%;
        border-collapse:collapse;
        min-width:780px;
        font-size:12px;
    }
    th, td{
        padding:8px 6px;
        border-bottom:1px solid var(--border);
        text-align:left;
    }
    th{
        text-transform:uppercase;
        font-size:11px;
        color:var(--muted);
    }

    .user-main{
        display:flex;
        align-items:center;
        gap:10px;
    }
    .avatar{
        width:34px;
        height:34px;
        border-radius:999px;
        background:#0f172a;
        border:1px solid #1f2937;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:14px;
        font-weight:600;
        color:#e5e7eb;
        text-transform:uppercase;
    }
    .user-name{
        font-size:13px;
        font-weight:600;
        max-width:160px;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }
    .user-email{
        font-size:11px;
        color:var(--muted);
        max-width:220px;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }

    .badge-role{
        display:inline-block;
        padding:2px 8px;
        border-radius:999px;
        font-size:10px;
    }
    .badge-role-admin{
        background:rgba(37,99,235,0.18);
        color:#bfdbfe;
    }
    .badge-role-reseller{
        background:rgba(234,179,8,0.18);
        color:#fde68a;
    }
    .badge-role-public{
        background:rgba(148,163,184,0.18);
        color:#e5e7eb;
    }

    .badge-active{
        display:inline-block;
        padding:2px 8px;
        border-radius:999px;
        font-size:10px;
        background:rgba(16,185,129,0.15);
        color:#4ade80;
    }
    .badge-inactive{
        display:inline-block;
        padding:2px 8px;
        border-radius:999px;
        font-size:10px;
        background:rgba(239,68,68,0.15);
        color:#fca5a5;
    }

    .balance-text{
        font-weight:600;
        font-size:12px;
    }
    .balance-sub{
        font-size:11px;
        color:var(--muted);
    }

    .btn-sm{
        padding:5px 8px;
        border-radius:999px;
        border:1px solid var(--border);
        background:#0f172a;
        color:#e5e7eb;
        font-size:11px;
        cursor:pointer;
        margin-right:4px;
        margin-bottom:4px;
    }
    .btn-danger{
        border-color:#b91c1c;
        color:#fecaca;
    }

    /* MODALS */
    .modal-backdrop{
        position:fixed;
        inset:0;
        background:rgba(0,0,0,0.7);
        display:none;
        align-items:center;
        justify-content:center;
        z-index:100;
    }
    .modal-backdrop.show{ display:flex; }

    .modal{
        width:100%;
        max-width:420px;
        background:#020617;
        border-radius:18px;
        border:1px solid var(--border);
        padding:16px 16px 18px;
        box-shadow:0 25px 60px rgba(0,0,0,0.95);
    }
    .modal-title{
        margin:0 0 10px;
        font-size:16px;
        font-weight:500;
    }
    .form-group{ margin-bottom:10px; }
    .form-label{
        display:block;
        font-size:12px;
        margin-bottom:4px;
    }
    .form-input, .form-select{
        width:100%;
        border-radius:10px;
        border:1px solid #1f2937;
        background:#0f172a;
        color:#e5e7eb;
        font-size:13px;
        padding:7px 9px;
        outline:none;
    }
    .form-check{
        display:flex;
        align-items:center;
        gap:6px;
        font-size:12px;
    }
</style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div>
            <div class="page-title">Users</div>
            <div class="page-sub">Tambah user, urus balance, tukar role & delete akaun.</div>
        </div>
        <button class="btn-primary" onclick="openUserModal()">+ Tambah User</button>
    </div>

    <div class="users-table-wrap">
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Balance</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Daftar</th>
                    <th width="220">Actions</th>
                </tr>
            </thead>
            <tbody id="usersTbody">
                <?php foreach ($users as $u): ?>
                    <?php
                        $initial = strtoupper(mb_substr($u['name'] ?: $u['email'], 0, 1));
                        $roleClass = 'badge-role-public';
                        if ($u['role'] === 'admin') $roleClass = 'badge-role-admin';
                        elseif ($u['role'] === 'reseller') $roleClass = 'badge-role-reseller';

                        $balanceFormatted = 'RM ' . number_format((float)$u['balance'], 2, '.', ',');
                    ?>
                    <tr id="user-row-<?php echo (int)$u['id']; ?>">
                        <td>
                            <div class="user-main">
                                <div class="avatar"><?php echo htmlspecialchars($initial); ?></div>
                                <div>
                                    <div class="user-name"><?php echo htmlspecialchars($u['name']); ?></div>
                                    <div class="user-email"><?php echo htmlspecialchars($u['email']); ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="balance-text"><?php echo $balanceFormatted; ?></div>
                            <div class="balance-sub">Phone: <?php echo htmlspecialchars($u['phone'] ?: '-'); ?></div>
                        </td>
                        <td>
                            <span class="badge-role <?php echo $roleClass; ?>">
                                <?php echo htmlspecialchars($u['role']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($u['is_active']): ?>
                                <span class="badge-active">Active</span>
                            <?php else: ?>
                                <span class="badge-inactive">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                                echo !empty($u['created_at'])
                                    ? date('d/m/Y', strtotime($u['created_at']))
                                    : '-';
                            ?>
                        </td>
                        <td>
                            <button class="btn-sm"
                                    onclick='openUserModal(<?php echo json_encode($u, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>)'>
                                Edit
                            </button>
                            <button class="btn-sm"
                                    onclick='openBalanceModal(<?php echo json_encode($u, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>, "add")'>
                                + Balance
                            </button>
                            <button class="btn-sm"
                                    onclick='openBalanceModal(<?php echo json_encode($u, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>, "deduct")'>
                                - Balance
                            </button>
                            <button class="btn-sm btn-danger"
                                    onclick="deleteUser(<?php echo (int)$u['id']; ?>)">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- MODAL USER -->
<div class="modal-backdrop" id="userModalBackdrop">
    <div class="modal">
        <h3 class="modal-title" id="userModalTitle">Tambah User</h3>

        <form id="userForm">
            <input type="hidden" name="id" id="userId">
            <input type="hidden" name="action" value="save_user">

            <div class="form-group">
                <label class="form-label">Nama</label>
                <input type="text" class="form-input" name="name" id="userName" required>
            </div>

            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" class="form-input" name="email" id="userEmail" required>
            </div>

            <div class="form-group">
                <label class="form-label">No Telefon</label>
                <input type="text" class="form-input" name="phone" id="userPhone">
            </div>

            <div class="form-group">
                <label class="form-label">Role</label>
                <select class="form-select" name="role" id="userRole">
                    <option value="public">Public</option>
                    <option value="reseller">Reseller</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" class="form-input" name="password" id="userPassword"
                       placeholder="Biarkan kosong untuk kekalkan password (edit)">
            </div>

            <div class="form-group form-check">
                <input type="checkbox" name="is_active" id="userActive" checked>
                <label for="userActive">Active</label>
            </div>

            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
                <button type="button" class="btn-sm" onclick="closeUserModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL BALANCE -->
<div class="modal-backdrop" id="balanceModalBackdrop">
    <div class="modal">
        <h3 class="modal-title" id="balanceModalTitle">Update Balance</h3>

        <form id="balanceForm">
            <input type="hidden" name="action" value="balance">
            <input type="hidden" name="id" id="balanceUserId">
            <input type="hidden" name="mode" id="balanceMode">

            <div class="form-group">
                <label class="form-label">User</label>
                <div id="balanceUserInfo" style="font-size:13px;color:#e5e7eb;"></div>
            </div>

            <div class="form-group">
                <label class="form-label">Jumlah (RM)</label>
                <input type="number" step="0.01" min="0" class="form-input" name="amount" id="balanceAmount" required>
            </div>

            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
                <button type="button" class="btn-sm" onclick="closeBalanceModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<script>
const usersTbody           = document.getElementById('usersTbody');

/* USER MODAL */
const userModalBackdrop    = document.getElementById('userModalBackdrop');
const userForm             = document.getElementById('userForm');
const userModalTitle       = document.getElementById('userModalTitle');
const fieldUserId          = document.getElementById('userId');
const fieldUserName        = document.getElementById('userName');
const fieldUserEmail       = document.getElementById('userEmail');
const fieldUserPhone       = document.getElementById('userPhone');
const fieldUserRole        = document.getElementById('userRole');
const fieldUserPassword    = document.getElementById('userPassword');
const fieldUserActive      = document.getElementById('userActive');

/* BALANCE MODAL */
const balanceModalBackdrop = document.getElementById('balanceModalBackdrop');
const balanceModalTitle    = document.getElementById('balanceModalTitle');
const balanceUserId        = document.getElementById('balanceUserId');
const balanceMode          = document.getElementById('balanceMode');
const balanceAmount        = document.getElementById('balanceAmount');
const balanceUserInfo      = document.getElementById('balanceUserInfo');
const balanceForm          = document.getElementById('balanceForm');

/* ========== USER MODAL ========== */
function openUserModal(user){
    if (user) {
        userModalTitle.textContent = 'Edit User';
        fieldUserId.value       = user.id;
        fieldUserName.value     = user.name ?? '';
        fieldUserEmail.value    = user.email ?? '';
        fieldUserPhone.value    = user.phone ?? '';
        fieldUserRole.value     = user.role ?? 'public';
        fieldUserPassword.value = '';
        fieldUserActive.checked = parseInt(user.is_active) === 1;
    } else {
        userModalTitle.textContent = 'Tambah User';
        fieldUserId.value       = '';
        fieldUserName.value     = '';
        fieldUserEmail.value    = '';
        fieldUserPhone.value    = '';
        fieldUserRole.value     = 'public';
        fieldUserPassword.value = '';
        fieldUserActive.checked = true;
    }
    userModalBackdrop.classList.add('show');
}
function closeUserModal(){
    userModalBackdrop.classList.remove('show');
}

userForm.addEventListener('submit', async function(e){
    e.preventDefault();
    const formData = new FormData(userForm);

    const res  = await fetch('users.php', { method:'POST', body:formData });
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        console.error('RESPON SERVER:', text);
        alert(text);
        return;
    }

    if (!data.success) {
        alert(data.message || 'Gagal simpan user.');
        return;
    }

    upsertUserRow(data.user);
    closeUserModal();
});

/* ========== BALANCE MODAL ========== */
function openBalanceModal(user, mode){
    balanceUserId.value  = user.id;
    balanceMode.value    = mode;
    balanceAmount.value  = '';
    const bal = parseFloat(user.balance || 0);
    const balText = 'Balance semasa: RM ' + bal.toFixed(2);
    balanceUserInfo.innerHTML = `<strong>${escapeHtml(user.name || user.email)}</strong><br><span style="font-size:11px;color:#94a3b8;">${balText}</span>`;
    balanceModalTitle.textContent = mode === 'add' ? 'Tambah Balance' : 'Tolak Balance';
    balanceModalBackdrop.classList.add('show');
}
function closeBalanceModal(){
    balanceModalBackdrop.classList.remove('show');
}

balanceForm.addEventListener('submit', async function(e){
    e.preventDefault();
    const formData = new FormData(balanceForm);

    const res  = await fetch('users.php', { method:'POST', body:formData });
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        console.error('RESPON SERVER (balance):', text);
        alert(text);
        return;
    }

    if (!data.success) {
        alert(data.message || 'Gagal update balance.');
        return;
    }

    upsertUserRow(data.user);
    closeBalanceModal();
});

/* ========== DELETE USER ========== */
async function deleteUser(id){
    if (!confirm('Betul nak delete user ini? Tindakan ini tidak boleh diundurkan.')) return;

    const formData = new FormData();
    formData.append('action','delete_user');
    formData.append('id', id);

    const res  = await fetch('users.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        console.error('RESPON SERVER (delete):', text);
        alert(text);
        return;
    }

    if (!data.success) {
        alert(data.message || 'Gagal delete user.');
        return;
    }

    const row = document.getElementById('user-row-'+id);
    if (row) row.remove();
}

/* ========== UPDATE / INSERT ROW TANPA REFRESH ========== */
function upsertUserRow(u){
    const rowId = 'user-row-' + u.id;
    let row = document.getElementById(rowId);

    const initial = (u.name || u.email || '?').charAt(0).toUpperCase();
    let roleClass = 'badge-role-public';
    if (u.role === 'admin') roleClass = 'badge-role-admin';
    else if (u.role === 'reseller') roleClass = 'badge-role-reseller';

    const balance = parseFloat(u.balance || 0);
    const balanceText = 'RM ' + balance.toFixed(2);

    const activeBadge = parseInt(u.is_active) === 1
        ? "<span class='badge-active'>Active</span>"
        : "<span class='badge-inactive'>Inactive</span>";

    const created = u.created_at ? formatDate(u.created_at) : '-';

    const rowHtml = `
        <td>
            <div class="user-main">
                <div class="avatar">${escapeHtml(initial)}</div>
                <div>
                    <div class="user-name">${escapeHtml(u.name || '')}</div>
                    <div class="user-email">${escapeHtml(u.email || '')}</div>
                </div>
            </div>
        </td>
        <td>
            <div class="balance-text">${balanceText}</div>
            <div class="balance-sub">Phone: ${escapeHtml(u.phone || '-')}</div>
        </td>
        <td>
            <span class="badge-role ${roleClass}">
                ${escapeHtml(u.role || 'public')}
            </span>
        </td>
        <td>${activeBadge}</td>
        <td>${created}</td>
        <td>
            <button class="btn-sm" onclick='openUserModal(${JSON.stringify(u)})'>Edit</button>
            <button class="btn-sm" onclick='openBalanceModal(${JSON.stringify(u)}, "add")'>+ Balance</button>
            <button class="btn-sm" onclick='openBalanceModal(${JSON.stringify(u)}, "deduct")'>- Balance</button>
            <button class="btn-sm btn-danger" onclick="deleteUser(${u.id})">Delete</button>
        </td>
    `;

    if (row) {
        row.innerHTML = rowHtml;
    } else {
        row = document.createElement('tr');
        row.id = rowId;
        row.innerHTML = rowHtml;
        usersTbody.prepend(row);
    }
}

/* Helpers */
function formatDate(str){
    const d = new Date(str);
    if (isNaN(d.getTime())) return '-';
    const dd = ('0'+d.getDate()).slice(-2);
    const mm = ('0'+(d.getMonth()+1)).slice(-2);
    const yy = d.getFullYear();
    return dd + '/' + mm + '/' + yy;
}
function escapeHtml(s){
    return (s || '').replace(/[&<>"']/g, function(m){
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]);
    });
}
</script>

</body>
</html>