<?php
// public/admin/products.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// AUTH ADMIN
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ============================================================
   AUTO CREATE TABLE: game_markups (UNTUK SIMPAN MARKUP %)
   - guna row game_slug = '__GLOBAL__' untuk markup semua game
============================================================ */
$conn->query("
CREATE TABLE IF NOT EXISTS game_markups (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    game_slug VARCHAR(100) NOT NULL UNIQUE,
    public_pct DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    reseller_pct DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// ensure global row exist
$stmt = $conn->prepare("SELECT id FROM game_markups WHERE game_slug='__GLOBAL__' LIMIT 1");
$stmt->execute();
$existsGlobal = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$existsGlobal) {
    $stmt = $conn->prepare("INSERT INTO game_markups (game_slug, public_pct, reseller_pct) VALUES ('__GLOBAL__', 0, 0)");
    $stmt->execute();
    $stmt->close();
}

/* ============================================================
   HELPERS: MARKUP LOAD + GET
============================================================ */
function loadMarkups($conn) {
    $out = [
        'global' => ['public_pct'=>0.00,'reseller_pct'=>0.00],
        'games'  => [] // slug => ['public_pct'=>..,'reseller_pct'=>..]
    ];
    $res = $conn->query("SELECT game_slug, public_pct, reseller_pct FROM game_markups");
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $slug = $r['game_slug'];
            $pub  = (float)$r['public_pct'];
            $resP = (float)$r['reseller_pct'];
            if ($slug === '__GLOBAL__') {
                $out['global'] = ['public_pct'=>$pub,'reseller_pct'=>$resP];
            } else {
                $out['games'][$slug] = ['public_pct'=>$pub,'reseller_pct'=>$resP];
            }
        }
    }
    return $out;
}

function getMarkupForSlug($markupSettings, $slug) {
    $slug = trim((string)$slug);
    if ($slug !== '' && isset($markupSettings['games'][$slug])) {
        return $markupSettings['games'][$slug];
    }
    return $markupSettings['global'] ?? ['public_pct'=>0.00,'reseller_pct'=>0.00];
}

/* ============================================================
   HELPER: FETCH PRODUCT BY ID (JOIN GAMES)
============================================================ */
function getProductById($conn, $id) {
    $stmt = $conn->prepare("
        SELECT 
            p.id, p.game_id, p.product_name, p.icon, 
            p.public_price, p.reseller_price,
            p.game_slug, p.srv_code, p.is_active, p.sort_order, p.created_at,
            g.name AS game_name
        FROM products p
        LEFT JOIN games g ON p.game_id = g.id
        WHERE p.id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row;
}

/* ============================================================
   AJAX: SAVE MARKUP (GLOBAL / PER SLUG)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_markup') {
    header('Content-Type: application/json');

    $scope = trim($_POST['scope'] ?? 'global'); // global / slug
    $slug  = trim($_POST['game_slug'] ?? '');
    $publicPct   = (float)($_POST['public_pct'] ?? 0);
    $resellerPct = (float)($_POST['reseller_pct'] ?? 0);

    if ($publicPct < 0) $publicPct = 0;
    if ($resellerPct < 0) $resellerPct = 0;

    $targetSlug = '__GLOBAL__';
    if ($scope === 'slug') {
        if ($slug === '') {
            echo json_encode(['success'=>false,'message'=>'Sila pilih game_slug.']);
            exit;
        }
        $targetSlug = $slug;
    }

    // upsert
    $stmt = $conn->prepare("
        INSERT INTO game_markups (game_slug, public_pct, reseller_pct)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE public_pct=VALUES(public_pct), reseller_pct=VALUES(reseller_pct)
    ");
    $stmt->bind_param("sdd", $targetSlug, $publicPct, $resellerPct);
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
        exit;
    }
    $stmt->close();

    $settings = loadMarkups($conn);

    echo json_encode([
        'success' => true,
        'message' => 'Markup berjaya disimpan.',
        'markups' => $settings
    ]);
    exit;
}

/* ============================================================
   AJAX: SAVE PRODUCT (ADD / EDIT)
   - optional auto-markup dari Base Price
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_product') {
    header('Content-Type: application/json');

    $id            = (int)($_POST['id'] ?? 0);
    $game_id       = (int)($_POST['game_id'] ?? 0);
    $product_name  = trim($_POST['product_name'] ?? '');
    $icon          = trim($_POST['icon'] ?? '');
    $public_price  = (float)($_POST['public_price'] ?? 0);
    $reseller_price= (float)($_POST['reseller_price'] ?? 0);
    $game_slug     = trim($_POST['game_slug'] ?? '');
    $srv_code      = trim($_POST['srv_code'] ?? '');
    $is_active     = isset($_POST['is_active']) ? 1 : 0;
    $sort_order    = (int)($_POST['sort_order'] ?? 0);

    // optional (auto markup)
    $apply_markup  = isset($_POST['apply_markup']) ? 1 : 0;
    $base_price    = (float)($_POST['base_price'] ?? 0);

    if ($product_name === '' || $game_id <= 0) {
        echo json_encode(['success'=>false,'message'=>'Nama produk & game wajib diisi.']);
        exit;
    }
    if ($game_slug === '') {
        echo json_encode(['success'=>false,'message'=>'game_slug wajib diisi (auto ikut game atau isi manual).']);
        exit;
    }

    // auto markup if enabled and base_price valid
    if ($apply_markup && $base_price > 0) {
        $markupSettings = loadMarkups($conn);
        $m = getMarkupForSlug($markupSettings, $game_slug);
        $publicPct   = (float)($m['public_pct'] ?? 0);
        $resellerPct = (float)($m['reseller_pct'] ?? 0);

        $reseller_price = round($base_price * (1 + ($resellerPct / 100)), 2);
        $public_price   = round($base_price * (1 + ($publicPct / 100)), 2);
    }

    if ($id > 0) {
        // UPDATE
        $stmt = $conn->prepare("
            UPDATE products
            SET game_id=?, product_name=?, icon=?, 
                public_price=?, reseller_price=?, 
                game_slug=?, srv_code=?, is_active=?, sort_order=?
            WHERE id=?
        ");
        $stmt->bind_param(
            "issddssiii",
            $game_id, $product_name, $icon,
            $public_price, $reseller_price,
            $game_slug, $srv_code, $is_active, $sort_order, $id
        );
        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close();
            echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
            exit;
        }
        $stmt->close();
        $newId = $id;
    } else {
        // INSERT
        $stmt = $conn->prepare("
            INSERT INTO products
            (game_id, product_name, icon, public_price, reseller_price, game_slug, srv_code, is_active, sort_order)
            VALUES (?,?,?,?,?,?,?,?,?)
        ");
        $stmt->bind_param(
            "issddssii",
            $game_id, $product_name, $icon,
            $public_price, $reseller_price,
            $game_slug, $srv_code, $is_active, $sort_order
        );
        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close();
            echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
            exit;
        }
        $newId = $stmt->insert_id;
        $stmt->close();
    }

    $product = getProductById($conn, $newId);

    echo json_encode([
        'success' => true,
        'message' => 'Produk berjaya disimpan.',
        'product' => $product
    ]);
    exit;
}

/* ============================================================
   AJAX: DELETE PRODUCT
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_product') {
    header('Content-Type: application/json');

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success'=>false,'message'=>'ID produk tidak sah.']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
        exit;
    }
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected < 1) {
        echo json_encode(['success'=>false,'message'=>'Produk tidak dijumpai / gagal delete.']);
        exit;
    }

    echo json_encode(['success'=>true,'message'=>'Produk berjaya dipadam.']);
    exit;
}

/* ============================================================
   LOAD GAMES (UNTUK SELECT & FILTER)
============================================================ */
$games = [];
$resGames = $conn->query("
    SELECT id, name, slug 
    FROM games 
    WHERE is_active = 1 
    ORDER BY name ASC
");
if ($resGames && $resGames->num_rows > 0) {
    while ($row = $resGames->fetch_assoc()) $games[] = $row;
}

/* ============================================================
   LOAD MARKUP SETTINGS (UNTUK UI)
============================================================ */
$markupSettings = loadMarkups($conn);

/* ============================================================
   LOAD PRODUCTS LIST
============================================================ */
$products = [];
$resProd = $conn->query("
    SELECT 
        p.id, p.game_id, p.product_name, p.icon,
        p.public_price, p.reseller_price,
        p.game_slug, p.srv_code, p.is_active, p.sort_order, p.created_at,
        g.name AS game_name
    FROM products p
    LEFT JOIN games g ON p.game_id = g.id
    ORDER BY p.sort_order ASC, p.id DESC
");
if ($resProd && $resProd->num_rows > 0) {
    while ($row = $resProd->fetch_assoc()) $products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Products - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    :root{
        --bg:#020617;
        --card:#0b1120;
        --border:#1e293b;
        --muted:#94a3b8;
        --text:#ffffff;
        --blue:#2563eb;
        --blue-soft:#1d4ed8;
        --green:#10b981;
        --amber:#f59e0b;
    }
    *{ box-sizing:border-box; }
    body{ margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }

    .admin-main{ max-width:1150px; margin:0 auto; padding:16px; }
    @media(min-width:900px){ .admin-main{ margin-left:240px; } }

    .page-head{
        display:flex; align-items:flex-start; justify-content:space-between;
        gap:10px; flex-wrap:wrap; margin-bottom:14px;
    }
    .page-title{ font-size:20px; font-weight:600; }
    .page-sub{ font-size:13px; color:var(--muted); }

    .btn-primary{
        padding:8px 14px; border-radius:999px; border:none;
        background:linear-gradient(135deg,var(--blue),var(--blue-soft));
        color:#fff; font-size:13px; cursor:pointer;
        box-shadow:0 8px 22px rgba(37,99,235,0.75);
    }

    /* BAR */
    .filter-bar{
        display:flex; flex-wrap:wrap; gap:8px; align-items:center;
        margin-bottom:12px;
    }
    .search-input, .select-filter{
        border-radius:999px;
        padding:7px 12px;
        border:1px solid var(--border);
        background:#020617;
        color:var(--text);
        font-size:13px;
        outline:none;
    }
    .search-input{ flex:1; min-width:160px; }
    .select-filter{ min-width:160px; }

    /* MARKUP BOX */
    .markup-box{
        background:rgba(37,99,235,0.08);
        border:1px solid rgba(37,99,235,0.35);
        border-radius:16px;
        padding:12px;
        margin-bottom:12px;
        display:flex;
        gap:10px;
        align-items:flex-end;
        flex-wrap:wrap;
    }
    .markup-title{ font-weight:600; font-size:13px; }
    .markup-help{ font-size:11px; color:var(--muted); margin-top:2px; }
    .mk-col{ min-width:200px; flex:1; }
    .mk-input, .mk-select{
        width:100%;
        border-radius:12px;
        border:1px solid var(--border);
        background:#0f172a;
        color:#e5e7eb;
        font-size:13px;
        padding:8px 10px;
        outline:none;
    }
    .btn-sm{
        padding:6px 10px;
        border-radius:999px;
        border:1px solid var(--border);
        background:#0f172a;
        color:#e5e7eb;
        font-size:12px;
        cursor:pointer;
        margin-right:4px;
        margin-bottom:4px;
        white-space:nowrap;
    }
    .btn-danger{ border-color:#b91c1c; color:#fecaca; }
    .btn-green{
        border:none;
        background:rgba(16,185,129,0.18);
        color:#86efac;
    }
    .mini-pill{
        display:inline-block;
        padding:3px 8px;
        border-radius:999px;
        font-size:11px;
        border:1px solid rgba(148,163,184,0.35);
        background:rgba(2,6,23,0.55);
        color:#e5e7eb;
    }

    /* TABLE */
    .products-table-wrap{
        background:var(--card);
        border-radius:16px;
        border:1px solid var(--border);
        padding:10px;
        overflow-x:auto;
    }
    table{ width:100%; border-collapse:collapse; min-width:980px; font-size:12px; }
    th, td{ padding:8px 6px; border-bottom:1px solid var(--border); text-align:left; vertical-align:top; }
    th{ font-size:11px; color:var(--muted); text-transform:uppercase; font-weight:500; }

    .prod-main{ display:flex; align-items:center; gap:10px; }
    .prod-thumb{
        width:52px; height:52px; border-radius:14px; overflow:hidden;
        background:#020617; border:1px solid #1f2937; flex-shrink:0;
    }
    .prod-thumb img{ width:100%; height:100%; object-fit:cover; }
    .prod-name{
        font-size:13px; font-weight:600; max-width:220px;
        white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
    }
    .prod-game{
        font-size:11px; color:var(--muted); max-width:240px;
        white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
    }
    .price-text{ font-size:12px; font-weight:600; }
    .price-sub{ font-size:11px; color:var(--muted); }
    .srv-text{ font-size:11px; color:var(--muted); word-break:break-all; }

    .badge-active{
        display:inline-block; padding:2px 8px; border-radius:999px;
        font-size:10px; background:rgba(16,185,129,0.15); color:#4ade80;
    }
    .badge-inactive{
        display:inline-block; padding:2px 8px; border-radius:999px;
        font-size:10px; background:rgba(239,68,68,0.15); color:#fca5a5;
    }

    /* MODAL */
    .modal-backdrop{
        position:fixed; inset:0; background:rgba(0,0,0,0.7);
        display:none; align-items:center; justify-content:center; z-index:100;
    }
    .modal-backdrop.show{ display:flex; }

    .modal{
        width:100%; max-width:520px; background:#020617;
        border-radius:18px; border:1px solid var(--border);
        padding:16px 16px 18px;
        box-shadow:0 25px 60px rgba(0,0,0,0.95);
    }
    .modal-title{ margin:0 0 10px; font-size:16px; font-weight:500; }
    .form-group{ margin-bottom:10px; }
    .form-label{ display:block; font-size:12px; margin-bottom:4px; }
    .form-input, .form-select, .form-textarea{
        width:100%; border-radius:10px; border:1px solid #1f2937;
        background:#0f172a; color:#e5e7eb; font-size:13px;
        padding:7px 9px; outline:none;
    }
    .form-textarea{ min-height:60px; resize:vertical; }
    .form-check{ display:flex; align-items:center; gap:6px; font-size:12px; }
    .modal-footer{ display:flex; justify-content:flex-end; gap:8px; margin-top:12px; }

    .calc-box{
        margin-top:10px;
        padding:10px;
        border-radius:14px;
        border:1px solid rgba(148,163,184,0.25);
        background:rgba(148,163,184,0.06);
    }
    .calc-title{ font-size:12px; font-weight:600; margin-bottom:6px; }
    .calc-grid{ display:grid; grid-template-columns:1fr 1fr; gap:8px; }
    @media(max-width:520px){ .calc-grid{ grid-template-columns:1fr; } }
    .calc-note{ font-size:11px; color:var(--muted); margin-top:6px; }
</style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div>
            <div class="page-title">Products</div>
            <div class="page-sub">Manage denom / produk topup mengikut game + auto markup.</div>
        </div>
        <button class="btn-primary" onclick="openProductModal()">+ Tambah Produk</button>
    </div>

    <!-- MARKUP MANAGER BOX -->
    <div class="markup-box">
        <div class="mk-col" style="min-width:260px;">
            <div class="markup-title">Markup Manager</div>
            <div class="markup-help">
                Set <span class="mini-pill">Public Markup</span> & <span class="mini-pill">Reseller Markup</span>
                sama ada untuk <strong>All Games</strong> atau ikut <strong>game_slug</strong>.
            </div>
        </div>

        <div class="mk-col" style="min-width:240px;">
            <label class="form-label" style="margin:0 0 4px;">Target</label>
            <select id="markupTarget" class="mk-select">
                <option value="__GLOBAL__">All Games (Global)</option>
                <?php foreach ($games as $g): ?>
                    <option value="<?php echo htmlspecialchars($g['slug'], ENT_QUOTES); ?>">
                        <?php echo htmlspecialchars($g['name']); ?> (<?php echo htmlspecialchars($g['slug']); ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mk-col" style="min-width:200px;">
            <label class="form-label" style="margin:0 0 4px;">Public Markup (%)</label>
            <input id="markupPublicPctBox" class="mk-input" type="number" step="0.01" min="0" placeholder="Public Markup % (cth 20)">
        </div>

        <div class="mk-col" style="min-width:220px;">
            <label class="form-label" style="margin:0 0 4px;">Reseller Markup (%)</label>
            <input id="markupResellerPctBox" class="mk-input" type="number" step="0.01" min="0" placeholder="Reseller Markup % (cth 10)">
        </div>

        <div>
            <button class="btn-sm btn-green" onclick="saveMarkupBox()">Simpan Markup</button>
            <button class="btn-sm" onclick="fillMarkupBoxFromTarget()">Reset ikut target</button>
        </div>
    </div>

    <!-- SEARCH & FILTER -->
    <div class="filter-bar">
        <input type="text" id="searchInput" class="search-input" placeholder="Cari produk / game / slug / srv code...">
        <select id="filterGame" class="select-filter">
            <option value="">Semua Game</option>
            <?php foreach ($games as $g): ?>
                <option value="<?php echo (int)$g['id']; ?>"><?php echo htmlspecialchars($g['name']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- TABLE PRODUCTS -->
    <div class="products-table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Slug / Code</th>
                    <th>Status</th>
                    <th>Sort</th>
                    <th width="210">Actions</th>
                </tr>
            </thead>
            <tbody id="productsTbody">
                <?php foreach ($products as $p): ?>
                    <?php
                        $icon = $p['icon'] ?: BASE_URL . 'assets/img/games/default.png';
                        $publicFmt   = 'RM ' . number_format((float)$p['public_price'], 2, '.', ',');
                        $resellerFmt = 'RM ' . number_format((float)$p['reseller_price'], 2, '.', ',');
                        $gameName    = $p['game_name'] ?: '-';

                        $m = getMarkupForSlug($markupSettings, $p['game_slug'] ?? '');
                        $mPub = (float)($m['public_pct'] ?? 0);
                        $mRes = (float)($m['reseller_pct'] ?? 0);
                    ?>
                    <tr id="product-row-<?php echo (int)$p['id']; ?>"
                        data-game-id="<?php echo (int)$p['game_id']; ?>"
                        data-search="<?php echo htmlspecialchars(
                            strtolower($p['product_name'].' '.$gameName.' '.$p['game_slug'].' '.$p['srv_code']),
                            ENT_QUOTES
                        ); ?>">
                        <td>
                            <div class="prod-main">
                                <div class="prod-thumb">
                                    <img src="<?php echo htmlspecialchars($icon); ?>"
                                         alt="<?php echo htmlspecialchars($p['product_name']); ?>">
                                </div>
                                <div>
                                    <div class="prod-name"><?php echo htmlspecialchars($p['product_name']); ?></div>
                                    <div class="prod-game">
                                        <?php echo htmlspecialchars($gameName); ?>
                                        <?php if (!empty($p['game_slug'])): ?>
                                            · <span style="opacity:0.9;"><?php echo htmlspecialchars($p['game_slug']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="price-text"><?php echo $publicFmt; ?></div>
                            <div class="price-sub">Reseller: <?php echo $resellerFmt; ?></div>
                            <div class="price-sub">Public Markup: <?php echo number_format($mPub, 2); ?>%</div>
                            <div class="price-sub">Reseller Markup: <?php echo number_format($mRes, 2); ?>%</div>
                        </td>
                        <td>
                            <?php if (!empty($p['srv_code'])): ?>
                                <div class="srv-text">Code: <?php echo htmlspecialchars($p['srv_code']); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($p['is_active']): ?>
                                <span class="badge-active">Active</span>
                            <?php else: ?>
                                <span class="badge-inactive">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo (int)$p['sort_order']; ?></td>
                        <td>
                            <button class="btn-sm"
                                onclick='openProductModal(<?php echo json_encode($p, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>)'>
                                Edit
                            </button>
                            <button class="btn-sm"
                                onclick='copyProduct(<?php echo json_encode($p, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>)'>
                                Copy
                            </button>
                            <button class="btn-sm btn-danger"
                                onclick="deleteProduct(<?php echo (int)$p['id']; ?>)">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- MODAL ADD/EDIT PRODUCT -->
<div class="modal-backdrop" id="productModalBackdrop">
    <div class="modal">
        <h3 class="modal-title" id="productModalTitle">Tambah Produk</h3>

        <form id="productForm">
            <input type="hidden" name="action" value="save_product">
            <input type="hidden" name="id" id="productId">

            <div class="form-group">
                <label class="form-label">Game</label>
                <select class="form-select" name="game_id" id="productGameId" required>
                    <option value="">-- Pilih Game --</option>
                    <?php foreach ($games as $g): ?>
                        <option value="<?php echo (int)$g['id']; ?>"
                                data-game-slug="<?php echo htmlspecialchars($g['slug'], ENT_QUOTES); ?>">
                            <?php echo htmlspecialchars($g['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div style="font-size:11px;color:var(--muted);margin-top:2px;">
                    game_slug boleh auto ikut game terpilih.
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Nama Produk</label>
                <input type="text" class="form-input" name="product_name" id="productName" required>
            </div>

            <div class="form-group">
                <label class="form-label">URL Icon</label>
                <input type="text" class="form-input" name="icon" id="productIcon">
            </div>

            <div class="form-group">
                <label class="form-label">game_slug</label>
                <input type="text" class="form-input" name="game_slug" id="productGameSlug" required>
            </div>

            <!-- AUTO MARKUP CALCULATOR -->
            <div class="calc-box">
                <div class="calc-title">Auto Markup (Base Price → Public & Reseller)</div>
                <div class="calc-grid">
                    <div>
                        <label class="form-label">Base Price (RM)</label>
                        <input type="number" step="0.01" min="0" class="form-input" name="base_price" id="productBasePrice" placeholder="cth 5.00">
                    </div>
                    <div style="display:flex;align-items:flex-end;">
                        <label class="form-check" style="margin:0;">
                            <input type="checkbox" name="apply_markup" id="applyMarkup" checked>
                            <span>Apply auto markup</span>
                        </label>
                    </div>

                    <div>
                        <label class="form-label">Public Markup (%)</label>
                        <input type="number" step="0.01" min="0" class="form-input" id="productPublicMarkupPct" placeholder="auto ikut Markup Manager">
                    </div>
                    <div>
                        <label class="form-label">Reseller Markup (%)</label>
                        <input type="number" step="0.01" min="0" class="form-input" id="productResellerMarkupPct" placeholder="auto ikut Markup Manager">
                    </div>
                </div>

                <div class="calc-note">
                    Bila <strong>Apply auto markup</strong> ON dan Base Price diisi, sistem auto kira <strong>Public Price</strong> & <strong>Reseller Price</strong>.
                </div>
            </div>

            <div class="form-group" style="margin-top:10px;">
                <label class="form-label">Harga Public (RM)</label>
                <input type="number" step="0.01" min="0" class="form-input" name="public_price" id="productPublicPrice" required>
            </div>

            <div class="form-group">
                <label class="form-label">Harga Reseller (RM)</label>
                <input type="number" step="0.01" min="0" class="form-input" name="reseller_price" id="productResellerPrice">
            </div>

            <div class="form-group">
                <label class="form-label">Srv Code</label>
                <input type="text" class="form-input" name="srv_code" id="productSrvCode">
            </div>

            <div class="form-group">
                <label class="form-label">Sort Order</label>
                <input type="number" class="form-input" name="sort_order" id="productSortOrder" value="0">
            </div>

            <div class="form-group form-check">
                <input type="checkbox" name="is_active" id="productIsActive" checked>
                <label for="productIsActive">Active</label>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn-sm" onclick="closeProductModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<script>
/* =========================
   STATE: MARKUP SETTINGS FROM SERVER
========================= */
let MARKUPS = <?php echo json_encode($markupSettings, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>;

function getMarkupForSlug(slug){
    slug = (slug || '').trim();
    if (slug && MARKUPS && MARKUPS.games && MARKUPS.games[slug]) {
        return MARKUPS.games[slug];
    }
    return (MARKUPS && MARKUPS.global) ? MARKUPS.global : {public_pct:0, reseller_pct:0};
}

/* =========================
   ELEMENTS
========================= */
const productsTbody        = document.getElementById('productsTbody');
const searchInput          = document.getElementById('searchInput');
const filterGame           = document.getElementById('filterGame');

/* Markup Manager */
const markupTarget         = document.getElementById('markupTarget');
const markupPublicPctBox   = document.getElementById('markupPublicPctBox');
const markupResellerPctBox = document.getElementById('markupResellerPctBox');

/* Modal */
const productModalBackdrop = document.getElementById('productModalBackdrop');
const productForm          = document.getElementById('productForm');
const productModalTitle    = document.getElementById('productModalTitle');

const fieldId              = document.getElementById('productId');
const fieldGameId          = document.getElementById('productGameId');
const fieldName            = document.getElementById('productName');
const fieldIcon            = document.getElementById('productIcon');
const fieldGameSlug        = document.getElementById('productGameSlug');
const fieldSrvCode         = document.getElementById('productSrvCode');
const fieldSortOrder       = document.getElementById('productSortOrder');
const fieldIsActive        = document.getElementById('productIsActive');
const fieldPublicPrice     = document.getElementById('productPublicPrice');
const fieldResellerPrice   = document.getElementById('productResellerPrice');

/* Auto markup calc */
const basePriceEl          = document.getElementById('productBasePrice');
const applyMarkupEl        = document.getElementById('applyMarkup');
const pubMarkupPctEl       = document.getElementById('productPublicMarkupPct');
const resMarkupPctEl       = document.getElementById('productResellerMarkupPct');

/* =========================
   INIT: Markup Manager Box
========================= */
function fillMarkupBoxFromTarget(){
    const val = markupTarget.value;
    let m;
    if (val === '__GLOBAL__') m = (MARKUPS && MARKUPS.global) ? MARKUPS.global : {public_pct:0,reseller_pct:0};
    else m = (MARKUPS && MARKUPS.games && MARKUPS.games[val]) ? MARKUPS.games[val] : (MARKUPS.global || {public_pct:0,reseller_pct:0});

    markupPublicPctBox.value   = (parseFloat(m.public_pct || 0)).toFixed(2);
    markupResellerPctBox.value = (parseFloat(m.reseller_pct || 0)).toFixed(2);
}
markupTarget.addEventListener('change', fillMarkupBoxFromTarget);
fillMarkupBoxFromTarget();

async function saveMarkupBox(){
    const target = markupTarget.value;
    const publicPct   = parseFloat(markupPublicPctBox.value || 0);
    const resellerPct = parseFloat(markupResellerPctBox.value || 0);

    const fd = new FormData();
    fd.append('action','save_markup');

    if (target === '__GLOBAL__') {
        fd.append('scope','global');
        fd.append('game_slug','');
    } else {
        fd.append('scope','slug');
        fd.append('game_slug', target);
    }
    fd.append('public_pct', isNaN(publicPct) ? 0 : publicPct);
    fd.append('reseller_pct', isNaN(resellerPct) ? 0 : resellerPct);

    const res  = await fetch('products.php', { method:'POST', body: fd });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); }
    catch(e){ console.error('RESPON SERVER (save_markup):', text); alert(text); return; }

    if (!data.success) { alert(data.message || 'Gagal simpan markup.'); return; }

    MARKUPS = data.markups || MARKUPS;
    fillMarkupBoxFromTarget();
    // kalau modal tengah buka, refresh % auto
    refreshModalMarkupPct();
    alert(data.message || 'Markup disimpan.');
}

/* =========================
   SEARCH + FILTER
========================= */
searchInput.addEventListener('input', applyFilters);
filterGame.addEventListener('change', applyFilters);

function applyFilters(){
    const text = searchInput.value.trim().toLowerCase();
    const gameId = filterGame.value;

    const rows = productsTbody.querySelectorAll('tr');
    rows.forEach(row => {
        const rowText = (row.getAttribute('data-search') || '').toLowerCase();
        const rowGameId = row.getAttribute('data-game-id') || '';

        let show = true;
        if (text && rowText.indexOf(text) === -1) show = false;
        if (gameId && rowGameId !== gameId) show = false;

        row.style.display = show ? '' : 'none';
    });
}

/* =========================
   MODAL: OPEN / CLOSE
========================= */
function refreshModalMarkupPct(){
    const slug = (fieldGameSlug.value || '').trim();
    const m = getMarkupForSlug(slug);

    pubMarkupPctEl.value = (parseFloat(m.public_pct || 0)).toFixed(2);
    resMarkupPctEl.value = (parseFloat(m.reseller_pct || 0)).toFixed(2);

    // recalc if base exists
    autoCalcPrices();
}

function openProductModal(p){
    if (p) {
        productModalTitle.textContent = 'Edit Produk';
        fieldId.value           = p.id;
        fieldName.value         = p.product_name || '';
        fieldIcon.value         = p.icon || '';
        fieldGameSlug.value     = p.game_slug || '';
        fieldSrvCode.value      = p.srv_code || '';
        fieldSortOrder.value    = p.sort_order || 0;
        fieldIsActive.checked   = parseInt(p.is_active) === 1;
        fieldGameId.value       = p.game_id || '';

        fieldPublicPrice.value  = p.public_price || '';
        fieldResellerPrice.value= p.reseller_price || '';

        // base price try derive (optional)
        basePriceEl.value = '';
        applyMarkupEl.checked = true;
    } else {
        productModalTitle.textContent = 'Tambah Produk';
        fieldId.value           = '';
        fieldName.value         = '';
        fieldIcon.value         = '';
        fieldGameSlug.value     = '';
        fieldSrvCode.value      = '';
        fieldSortOrder.value    = 0;
        fieldIsActive.checked   = true;
        fieldGameId.value       = '';

        basePriceEl.value = '';
        applyMarkupEl.checked = true;

        fieldPublicPrice.value  = '';
        fieldResellerPrice.value= '';
    }

    refreshModalMarkupPct();
    productModalBackdrop.classList.add('show');
}

function copyProduct(p){
    openProductModal({ ...p, id: '' });
    productModalTitle.textContent = 'Copy Produk (New)';
}

function closeProductModal(){
    productModalBackdrop.classList.remove('show');
}

/* Auto isi game_slug bila pilih game */
fieldGameId.addEventListener('change', function(){
    const opt = fieldGameId.options[fieldGameId.selectedIndex];
    if (!opt) return;
    const slug = opt.getAttribute('data-game-slug') || '';
    if (slug) fieldGameSlug.value = slug; // auto overwrite supaya ikut game
    refreshModalMarkupPct();
});

fieldGameSlug.addEventListener('input', refreshModalMarkupPct);

/* =========================
   AUTO CALC PRICES
========================= */
function autoCalcPrices(){
    if (!applyMarkupEl.checked) return;

    const base = parseFloat(basePriceEl.value || 0);
    if (!base || base <= 0) return;

    const pubPct = parseFloat(pubMarkupPctEl.value || 0);
    const resPct = parseFloat(resMarkupPctEl.value || 0);

    const reseller = base * (1 + (isNaN(resPct) ? 0 : resPct)/100);
    const pub      = base * (1 + (isNaN(pubPct) ? 0 : pubPct)/100);

    fieldResellerPrice.value = reseller.toFixed(2);
    fieldPublicPrice.value   = pub.toFixed(2);
}

basePriceEl.addEventListener('input', autoCalcPrices);
applyMarkupEl.addEventListener('change', autoCalcPrices);
pubMarkupPctEl.addEventListener('input', autoCalcPrices);
resMarkupPctEl.addEventListener('input', autoCalcPrices);

/* =========================
   AJAX SAVE PRODUCT
========================= */
productForm.addEventListener('submit', async function(e){
    e.preventDefault();

    const formData = new FormData(productForm);

    const res  = await fetch('products.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch (e) { console.error('RESPON SERVER (products):', text); alert(text); return; }

    if (!data.success) { alert(data.message || 'Gagal simpan produk.'); return; }

    upsertProductRow(data.product);
    closeProductModal();
});

/* =========================
   DELETE PRODUCT
========================= */
async function deleteProduct(id){
    if (!confirm('Betul nak delete produk ini?')) return;

    const formData = new FormData();
    formData.append('action', 'delete_product');
    formData.append('id', id);

    const res  = await fetch('products.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch (e) { console.error('RESPON SERVER (delete product):', text); alert(text); return; }

    if (!data.success) { alert(data.message || 'Gagal delete produk.'); return; }

    const row = document.getElementById('product-row-'+id);
    if (row) row.remove();
}

/* =========================
   UPSERT ROW (ADD/EDIT) TANPA REFRESH
========================= */
function upsertProductRow(p){
    const rowId = 'product-row-' + p.id;
    let row = document.getElementById(rowId);

    const icon = p.icon || '<?php echo BASE_URL; ?>assets/img/games/default.png';
    const gameName = p.game_name || '-';
    const publicPrice = parseFloat(p.public_price || 0);
    const resellerPrice = parseFloat(p.reseller_price || 0);

    const publicFmt   = 'RM ' + publicPrice.toFixed(2);
    const resellerFmt = 'RM ' + resellerPrice.toFixed(2);

    const m = getMarkupForSlug((p.game_slug || '').trim());
    const mPub = parseFloat(m.public_pct || 0).toFixed(2);
    const mRes = parseFloat(m.reseller_pct || 0).toFixed(2);

    const activeBadge = parseInt(p.is_active) === 1
        ? "<span class='badge-active'>Active</span>"
        : "<span class='badge-inactive'>Inactive</span>";

    const searchText = (p.product_name + ' ' + gameName + ' ' + (p.game_slug || '') + ' ' + (p.srv_code || '')).toLowerCase();

    const rowHtml = `
        <td>
            <div class="prod-main">
                <div class="prod-thumb">
                    <img src="${escapeHtml(icon)}" alt="${escapeHtml(p.product_name || '')}">
                </div>
                <div>
                    <div class="prod-name">${escapeHtml(p.product_name || '')}</div>
                    <div class="prod-game">
                        ${escapeHtml(gameName)}
                        ${p.game_slug ? ' · <span style="opacity:0.9;">'+escapeHtml(p.game_slug)+'</span>' : ''}
                    </div>
                </div>
            </div>
        </td>
        <td>
            <div class="price-text">${publicFmt}</div>
            <div class="price-sub">Reseller: ${resellerFmt}</div>
            <div class="price-sub">Public Markup: ${mPub}%</div>
            <div class="price-sub">Reseller Markup: ${mRes}%</div>
        </td>
        <td>
            ${p.srv_code ? '<div class="srv-text">Code: '+escapeHtml(p.srv_code)+'</div>' : ''}
        </td>
        <td>${activeBadge}</td>
        <td>${parseInt(p.sort_order || 0)}</td>
        <td>
            <button class="btn-sm" onclick='openProductModal(${JSON.stringify(p)})'>Edit</button>
            <button class="btn-sm" onclick='copyProduct(${JSON.stringify(p)})'>Copy</button>
            <button class="btn-sm btn-danger" onclick="deleteProduct(${p.id})">Delete</button>
        </td>
    `;

    if (row) {
        row.innerHTML = rowHtml;
        row.setAttribute('data-game-id', p.game_id || '');
        row.setAttribute('data-search', escapeHtml(searchText));
    } else {
        row = document.createElement('tr');
        row.id = rowId;
        row.setAttribute('data-game-id', p.game_id || '');
        row.setAttribute('data-search', escapeHtml(searchText));
        row.innerHTML = rowHtml;
        productsTbody.prepend(row);
    }

    applyFilters();
}

/* HELPERS */
function escapeHtml(s){
    return (s || '').toString().replace(/[&<>"']/g, function(m){
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]);
    });
}
</script>

</body>
</html>