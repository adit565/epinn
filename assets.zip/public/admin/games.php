<?php
// public/admin/games.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// AUTH ADMIN
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ============================================================
   CATEGORY OPTIONS (MESTI MATCH ENUM DB)
============================================================ */
$categoryOptions = [
    'Top Up' => 'Top Up',
    'Mobile Legends Services' => 'Mobile Legends Services',
    'Vilog' => 'Vilog',
    // tambah ikut ENUM db kalau ada
];

/* ============================================================
   HELPER: FETCH GAME BY ID
============================================================ */
function getGameById($conn, $id) {
    $stmt = $conn->prepare("
        SELECT id, slug, name, category, publisher, icon, path, description,
               require_zone_id, is_active, created_at
        FROM games
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $id);

    if (!$stmt->execute()) {
        $stmt->close();
        return null;
    }

    $game = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $game;
}

/* ============================================================
   HELPER: CHECK DUPLICATE SLUG
============================================================ */
function slugExists($conn, $slug, $exceptId = 0) {
    if ($exceptId > 0) {
        $stmt = $conn->prepare("SELECT id FROM games WHERE slug=? AND id<>? LIMIT 1");
        $stmt->bind_param("si", $slug, $exceptId);
    } else {
        $stmt = $conn->prepare("SELECT id FROM games WHERE slug=? LIMIT 1");
        $stmt->bind_param("s", $slug);
    }
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return (bool)$row;
}

/* ============================================================
   AJAX: SAVE GAME (ADD / EDIT)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_game') {
    header('Content-Type: application/json');

    $id              = (int)($_POST['id'] ?? 0);
    $name            = trim($_POST['name'] ?? '');
    $slug            = strtolower(trim($_POST['slug'] ?? ''));
    $category        = trim($_POST['category'] ?? 'Top Up');
    $publisher       = trim($_POST['publisher'] ?? '');
    $icon            = trim($_POST['icon'] ?? '');
    $path            = trim($_POST['path'] ?? '');
    $description     = trim($_POST['description'] ?? '');
    $require_zone_id = isset($_POST['require_zone_id']) ? 1 : 0;
    $is_active       = isset($_POST['is_active']) ? 1 : 0;

    if ($name === '' || $slug === '' || $path === '') {
        echo json_encode(['success'=>false,'message'=>'Nama, slug dan path wajib diisi.']);
        exit;
    }

    // Validate category
    global $categoryOptions;
    if (!isset($categoryOptions[$category])) {
        $category = 'Top Up';
    }

    // Ensure unique slug
    if (slugExists($conn, $slug, $id)) {
        echo json_encode(['success'=>false,'message'=>'Slug sudah wujud. Sila guna slug lain.']);
        exit;
    }

    if ($id > 0) {
        $stmt = $conn->prepare("
            UPDATE games
            SET slug=?, name=?, category=?, publisher=?, icon=?, path=?,
                description=?, require_zone_id=?, is_active=?
            WHERE id=?
        ");
        $stmt->bind_param(
            "sssssssiii",
            $slug, $name, $category, $publisher, $icon, $path,
            $description, $require_zone_id, $is_active, $id
        );
        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close();
            echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
            exit;
        }
        $stmt->close();
        $newId = $id;
    } else {
        $stmt = $conn->prepare("
            INSERT INTO games (slug, name, category, publisher, icon, path, description, require_zone_id, is_active)
            VALUES (?,?,?,?,?,?,?,?,?)
        ");
        $stmt->bind_param(
            "sssssssii",
            $slug, $name, $category, $publisher, $icon, $path,
            $description, $require_zone_id, $is_active
        );
        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close();
            echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
            exit;
        }
        $newId = $stmt->insert_id;
        $stmt->close();
    }

    $game = getGameById($conn, $newId);

    echo json_encode([
        'success' => true,
        'message' => 'Game berjaya disimpan.',
        'game'    => $game
    ]);
    exit;
}

/* ============================================================
   AJAX: COPY GAME
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'copy_game') {
    header('Content-Type: application/json');

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success'=>false,'message'=>'ID tidak sah.']);
        exit;
    }

    $g = getGameById($conn, $id);
    if (!$g) {
        echo json_encode(['success'=>false,'message'=>'Game tidak dijumpai.']);
        exit;
    }

    $baseSlug = ($g['slug'] ?: 'game') . '-copy';
    $newSlug  = $baseSlug;
    $i = 2;
    while (slugExists($conn, $newSlug)) {
        $newSlug = $baseSlug . '-' . $i;
        $i++;
        if ($i > 99) break;
    }

    $newName = ($g['name'] ?: 'Game') . ' (Copy)';

    $stmt = $conn->prepare("
        INSERT INTO games (slug, name, category, publisher, icon, path, description, require_zone_id, is_active)
        VALUES (?,?,?,?,?,?,?,?,?)
    ");
    $stmt->bind_param(
        "sssssssii",
        $newSlug,
        $newName,
        $g['category'],
        $g['publisher'],
        $g['icon'],
        $g['path'],
        $g['description'],
        (int)$g['require_zone_id'],
        (int)$g['is_active']
    );
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
        exit;
    }
    $newId = $stmt->insert_id;
    $stmt->close();

    $newGame = getGameById($conn, $newId);

    echo json_encode([
        'success' => true,
        'message' => 'Game berjaya di-copy.',
        'game'    => $newGame
    ]);
    exit;
}

/* ============================================================
   AJAX: DELETE GAME
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_game') {
    header('Content-Type: application/json');

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success'=>false,'message'=>'ID tidak sah.']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM games WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $id);

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        echo json_encode(['success'=>false,'message'=>'DB error: '.$err]);
        exit;
    }

    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected < 1) {
        echo json_encode(['success'=>false,'message'=>'Game tidak dijumpai / gagal delete.']);
        exit;
    }

    echo json_encode(['success'=>true,'message'=>'Game berjaya dipadam.']);
    exit;
}

/* ============================================================
   LOAD LIST GAMES
============================================================ */
$games = [];
$res = $conn->query("
    SELECT id, slug, name, category, publisher, icon, path, description,
           require_zone_id, is_active, created_at
    FROM games
    ORDER BY id DESC
");
while ($row = $res->fetch_assoc()) $games[] = $row;

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Games - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
:root{
    --bg:#020617;
    --card:#0a0f1f;
    --border:#1e293b;
    --muted:#94a3b8;
    --text:#ffffff;
    --blue:#2563eb;
    --blue-soft:#1d4ed8;
}
*{ box-sizing:border-box; }
body{ margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }

.admin-main{ max-width:1100px; margin:0 auto; padding:16px; }
@media(min-width:900px){ .admin-main{ margin-left:240px; } }

.page-head{ display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:16px; }
.page-title{ font-size:20px; font-weight:600; }
.page-sub{ font-size:13px; color:var(--muted); }

.btn-primary{
    padding:8px 14px; border-radius:999px; border:none;
    background:linear-gradient(135deg,var(--blue),var(--blue-soft));
    color:#fff; font-size:13px; cursor:pointer;
    box-shadow:0 8px 20px rgba(37,99,235,0.6);
}
.btn-sm{
    padding:5px 8px; border-radius:999px;
    border:1px solid var(--border);
    background:#0f172a; color:#e5e7eb;
    font-size:11px; cursor:pointer;
    margin-right:4px; margin-bottom:4px;
}
.btn-danger{ border-color:#b91c1c; color:#fecaca; }

.games-table-wrap{ margin-top:4px; background:var(--card); border-radius:16px; border:1px solid var(--border); padding:10px; overflow-x:auto; }
table{ width:100%; border-collapse:collapse; min-width:980px; font-size:12px; }
th, td{ padding:8px 6px; border-bottom:1px solid var(--border); text-align:left; vertical-align:top; }
th{ text-transform:uppercase; font-size:11px; color:var(--muted); }

.game-main{ display:flex; align-items:center; gap:10px; }
.thumb{
    width:44px; height:44px; border-radius:12px; overflow:hidden;
    background:#0f172a; border:1px solid #1f2937; flex-shrink:0;
}
.thumb img{ width:100%; height:100%; object-fit:cover; }
.g-name{ font-size:13px; font-weight:600; max-width:180px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.g-slug{ font-size:11px; color:var(--muted); max-width:220px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.help{ font-size:11px; color:var(--muted); margin-top:3px; }

.pill{
    display:inline-block; padding:2px 8px; border-radius:999px;
    background:#020617; border:1px solid rgba(148,163,184,0.5);
    font-size:10px; color:#e5e7eb;
}
.badge-active{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:10px; background:rgba(16,185,129,0.15); color:#4ade80; }
.badge-inactive{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:10px; background:rgba(239,68,68,0.15); color:#fca5a5; }
.badge-zone{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:10px; background:rgba(37,99,235,0.18); color:#bfdbfe; margin-top:4px; }

/* MODAL */
.modal-backdrop{ position:fixed; inset:0; background:rgba(0,0,0,0.7); display:none; align-items:center; justify-content:center; z-index:100; }
.modal-backdrop.show{ display:flex; }
.modal{ width:100%; max-width:420px; background:#020617; border-radius:18px; border:1px solid var(--border); padding:16px 16px 18px; box-shadow:0 25px 60px rgba(0,0,0,0.95); }
.modal-title{ margin:0 0 10px; font-size:16px; font-weight:500; }
.form-group{ margin-bottom:10px; }
.form-label{ display:block; font-size:12px; margin-bottom:4px; }
.form-input, textarea, select{
    width:100%; border-radius:10px; border:1px solid #1f2937;
    background:#0f172a; color:#e5e7eb; font-size:13px;
    padding:7px 9px; outline:none;
}
textarea{ min-height:90px; }
.form-check{ display:flex; align-items:center; gap:6px; font-size:12px; }
.preview{ width:86px; height:86px; border-radius:16px; overflow:hidden; background:#000; border:1px solid #1f2937; margin-bottom:6px; }
.preview img{ width:100%; height:100%; object-fit:cover; }
</style>
</head>
<body>

<?php
// INI YANG BETUL UNTUK STRUCTURE KAU ✅
require_once __DIR__ . '/include/sidebar.php';
require_once __DIR__ . '/include/header.php';
?>

<div class="admin-main">
    <div class="page-head">
        <div>
            <div class="page-title">Games</div>
            <div class="page-sub">Tambah game, edit, copy & delete tanpa reload.</div>
        </div>
        <button class="btn-primary" onclick="openGameModal()">+ Tambah Game</button>
    </div>

    <div class="games-table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Game</th>
                    <th>Category</th>
                    <th>Path</th>
                    <th>Status</th>
                    <th>Daftar</th>
                    <th width="260">Actions</th>
                </tr>
            </thead>
            <tbody id="gamesTbody">
                <?php foreach ($games as $g): ?>
                    <?php
                        $icon = $g['icon'] ?: (BASE_URL.'assets/img/games/default.png');
                        $created = !empty($g['created_at']) ? date('d/m/Y', strtotime($g['created_at'])) : '-';
                    ?>
                    <tr id="game-row-<?php echo (int)$g['id']; ?>">
                        <td>
                            <div class="game-main">
                                <div class="thumb">
                                    <img src="<?php echo htmlspecialchars($icon); ?>" alt="">
                                </div>
                                <div>
                                    <div class="g-name"><?php echo htmlspecialchars($g['name']); ?></div>
                                    <div class="g-slug"><?php echo htmlspecialchars($g['slug']); ?></div>
                                    <?php if (!empty($g['publisher'])): ?>
                                        <div class="help"><?php echo htmlspecialchars($g['publisher']); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($g['require_zone_id'])): ?>
                                        <div class="badge-zone">Perlu Zone ID</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td><span class="pill"><?php echo htmlspecialchars($g['category'] ?? 'Top Up'); ?></span></td>
                        <td>
                            <div style="font-weight:600;"><?php echo htmlspecialchars($g['path']); ?></div>
                            <?php if (!empty($g['description'])): ?>
                                <div class="help" style="max-width:340px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                    <?php echo htmlspecialchars($g['description']); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($g['is_active'])): ?>
                                <span class="badge-active">Active</span>
                            <?php else: ?>
                                <span class="badge-inactive">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $created; ?></td>
                        <td>
                            <button class="btn-sm"
                                onclick='openGameModal(<?php echo json_encode($g, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>)'>
                                Edit
                            </button>
                            <button class="btn-sm" onclick="copyGame(<?php echo (int)$g['id']; ?>)">Copy</button>
                            <button class="btn-sm btn-danger" onclick="deleteGame(<?php echo (int)$g['id']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- MODAL -->
<div class="modal-backdrop" id="gameModalBackdrop">
    <div class="modal">
        <h3 class="modal-title" id="gameModalTitle">Tambah Game</h3>

        <form id="gameForm">
            <input type="hidden" name="action" value="save_game">
            <input type="hidden" name="id" id="gameId">

            <div class="form-group">
                <div class="form-label">Preview Icon</div>
                <div class="preview">
                    <img id="iconPreview" src="<?php echo htmlspecialchars(BASE_URL.'assets/img/games/default.png'); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">URL Icon</label>
                <input type="text" class="form-input" name="icon" id="gameIcon">
            </div>

            <div class="form-group">
                <label class="form-label">Nama Game</label>
                <input type="text" class="form-input" name="name" id="gameName" required>
            </div>

            <div class="form-group">
                <label class="form-label">Slug</label>
                <input type="text" class="form-input" name="slug" id="gameSlug" required>
            </div>

            <div class="form-group">
                <label class="form-label">Path</label>
                <input type="text" class="form-input" name="path" id="gamePath" required>
            </div>

            <div class="form-group">
                <label class="form-label">Category</label>
                <select class="form-input" name="category" id="gameCategory">
                    <?php foreach ($categoryOptions as $k => $label): ?>
                        <option value="<?php echo htmlspecialchars($k); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Publisher</label>
                <input type="text" class="form-input" name="publisher" id="gamePublisher">
            </div>

            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-input" name="description" id="gameDescription"></textarea>
            </div>

            <div class="form-group form-check">
                <input type="checkbox" name="require_zone_id" id="gameRequireZone" checked>
                <label for="gameRequireZone">Perlu Zone ID</label>
            </div>

            <div class="form-group form-check">
                <input type="checkbox" name="is_active" id="gameActive" checked>
                <label for="gameActive">Active</label>
            </div>

            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
                <button type="button" class="btn-sm" onclick="closeGameModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<script>
const gamesTbody = document.getElementById('gamesTbody');

const gameModalBackdrop = document.getElementById('gameModalBackdrop');
const gameModalTitle    = document.getElementById('gameModalTitle');
const gameForm          = document.getElementById('gameForm');

const gameId            = document.getElementById('gameId');
const gameName          = document.getElementById('gameName');
const gameSlug          = document.getElementById('gameSlug');
const gamePath          = document.getElementById('gamePath');
const gameCategory      = document.getElementById('gameCategory');
const gamePublisher     = document.getElementById('gamePublisher');
const gameIcon          = document.getElementById('gameIcon');
const gameDescription   = document.getElementById('gameDescription');
const gameRequireZone   = document.getElementById('gameRequireZone');
const gameActive        = document.getElementById('gameActive');
const iconPreview       = document.getElementById('iconPreview');

const DEFAULT_ICON = "<?php echo htmlspecialchars(BASE_URL.'assets/img/games/default.png'); ?>";

function openGameModal(g){
    if (g) {
        gameModalTitle.textContent = 'Edit Game';
        gameId.value = g.id ?? '';
        gameName.value = g.name ?? '';
        gameSlug.value = g.slug ?? '';
        gamePath.value = g.path ?? '';
        gameCategory.value = g.category ?? 'Top Up';
        gamePublisher.value = g.publisher ?? '';
        gameIcon.value = g.icon ?? '';
        gameDescription.value = g.description ?? '';
        gameRequireZone.checked = parseInt(g.require_zone_id || 0) === 1;
        gameActive.checked = parseInt(g.is_active || 0) === 1;
        iconPreview.src = (g.icon && String(g.icon).trim()) ? g.icon : DEFAULT_ICON;
    } else {
        gameModalTitle.textContent = 'Tambah Game';
        gameId.value = '';
        gameName.value = '';
        gameSlug.value = '';
        gamePath.value = '';
        gameCategory.value = 'Top Up';
        gamePublisher.value = '';
        gameIcon.value = '';
        gameDescription.value = '';
        gameRequireZone.checked = true;
        gameActive.checked = true;
        iconPreview.src = DEFAULT_ICON;
    }
    gameModalBackdrop.classList.add('show');
}
function closeGameModal(){
    gameModalBackdrop.classList.remove('show');
}

gameIcon.addEventListener('input', function(){
    const v = (this.value || '').trim();
    iconPreview.src = v ? v : DEFAULT_ICON;
});

/* SAVE */
gameForm.addEventListener('submit', async function(e){
    e.preventDefault();
    const formData = new FormData(gameForm);

    const res  = await fetch('games.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){ console.error(text); alert(text); return; }

    if (!data.success) { alert(data.message || 'Gagal simpan game.'); return; }

    upsertGameRow(data.game, true);
    closeGameModal();
});

/* COPY */
async function copyGame(id){
    if (!confirm('Copy game ini sebagai game baru?')) return;

    const formData = new FormData();
    formData.append('action', 'copy_game');
    formData.append('id', id);

    const res  = await fetch('games.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){ console.error(text); alert(text); return; }

    if (!data.success) { alert(data.message || 'Gagal copy game.'); return; }

    upsertGameRow(data.game, true);
}

/* DELETE */
async function deleteGame(id){
    if (!confirm('Betul nak delete game ini?')) return;

    const formData = new FormData();
    formData.append('action','delete_game');
    formData.append('id', id);

    const res  = await fetch('games.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){ console.error(text); alert(text); return; }

    if (!data.success) { alert(data.message || 'Gagal delete game.'); return; }

    const row = document.getElementById('game-row-'+id);
    if (row) row.remove();
}

/* UPSERT ROW */
function upsertGameRow(g, prepend=false){
    if (!g) return;

    const rowId = 'game-row-' + g.id;
    let row = document.getElementById(rowId);

    const icon = (g.icon && String(g.icon).trim()) ? g.icon : DEFAULT_ICON;

    const statusBadge = parseInt(g.is_active || 0) === 1
        ? "<span class='badge-active'>Active</span>"
        : "<span class='badge-inactive'>Inactive</span>";

    const zoneBadge = parseInt(g.require_zone_id || 0) === 1
        ? "<div class='badge-zone'>Perlu Zone ID</div>"
        : "";

    const pubHtml = g.publisher ? `<div class="help">${escapeHtml(g.publisher)}</div>` : '';
    const descHtml = g.description ? `<div class="help" style="max-width:340px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(g.description)}</div>` : '';

    const created = g.created_at ? formatDate(g.created_at) : '-';

    const gJson = JSON.stringify(g).replace(/</g, "\\u003c");

    const rowHtml = `
        <td>
            <div class="game-main">
                <div class="thumb"><img src="${escapeHtml(icon)}" alt=""></div>
                <div>
                    <div class="g-name">${escapeHtml(g.name || '')}</div>
                    <div class="g-slug">${escapeHtml(g.slug || '')}</div>
                    ${pubHtml}
                    ${zoneBadge}
                </div>
            </div>
        </td>
        <td><span class="pill">${escapeHtml(g.category || 'Top Up')}</span></td>
        <td>
            <div style="font-weight:600;">${escapeHtml(g.path || '')}</div>
            ${descHtml}
        </td>
        <td>${statusBadge}</td>
        <td>${created}</td>
        <td>
            <button class="btn-sm" onclick='openGameModal(${gJson})'>Edit</button>
            <button class="btn-sm" onclick="copyGame(${g.id})">Copy</button>
            <button class="btn-sm btn-danger" onclick="deleteGame(${g.id})">Delete</button>
        </td>
    `;

    if (row) {
        row.innerHTML = rowHtml;
    } else {
        row = document.createElement('tr');
        row.id = rowId;
        row.innerHTML = rowHtml;
        if (prepend) gamesTbody.prepend(row);
        else gamesTbody.appendChild(row);
    }
}

function formatDate(str){
    const d = new Date(str);
    if (isNaN(d.getTime())) return '-';
    const dd = ('0'+d.getDate()).slice(-2);
    const mm = ('0'+(d.getMonth()+1)).slice(-2);
    const yy = d.getFullYear();
    return dd + '/' + mm + '/' + yy;
}
function escapeHtml(s){
    return (s || '').replace(/[&<>"']/g, function(m){
        return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]);
    });
}
</script>

</body>
</html>