<?php
// public/admin/provider.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// AUTH ADMIN
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ============================================================
   CONFIG: GAMEVIA ENDPOINTS
   (Aku buat fallback auto: cuba .php dulu, kalau 404 cuba tanpa .php)
============================================================ */
define('GAMEVIA_BASE', 'https://api.gamevia.shop/v1/');
$ENDPOINTS = [
    'check_account' => ['check-account.php', 'check-account'],
    'check_games'   => ['check-games', 'check-games.php'],
    'get_products'  => ['get-products', 'get-products.php'],
];

/* ============================================================
   DB: detect optional provider columns in products table
   (kalau kau dah tambah provider_price/provider_is_active, code akan auto guna)
============================================================ */
function dbHasColumn(mysqli $conn, string $table, string $column): bool {
    $stmt = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $stmt->bind_param("ss", $table, $column);
    $stmt->execute();
    $ok = (bool)$stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $ok;
}

$HAS_PROVIDER_PRICE  = dbHasColumn($conn, 'products', 'provider_price');
$HAS_PROVIDER_ACTIVE = dbHasColumn($conn, 'products', 'provider_is_active');

/* ============================================================
   HELPERS: Local games
============================================================ */
function getLocalGameById(mysqli $conn, int $id): ?array {
    $stmt = $conn->prepare("SELECT id, slug, name FROM games WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}
function getLocalGameBySlug(mysqli $conn, string $slug): ?array {
    $stmt = $conn->prepare("SELECT id, slug, name FROM games WHERE slug=? LIMIT 1");
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}

/* ============================================================
   HELPER: Provider request with fallback endpoints
============================================================ */
function gameviaRequest(string $key, array $payload = []): array {
    global $ENDPOINTS;

    $apiKey = defined('GAMEVIA_API_KEY') ? GAMEVIA_API_KEY : '';
    if (!$apiKey) {
        return ['success'=>false,'message'=>'GAMEVIA_API_KEY belum define dalam config/app.php'];
    }

    $clientIp = $_SERVER['SERVER_ADDR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    $headers = [
        'Content-Type: application/json',
        'x-api-key: ' . $apiKey,
        'x-client-ip: ' . $clientIp,
    ];

    $raw = '';
    $lastHttp = 0;
    $lastErr  = '';

    $tries = $ENDPOINTS[$key] ?? [];
    foreach ($tries as $ep) {
        $url = GAMEVIA_BASE . $ep;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_SLASHES));

        $resp = curl_exec($ch);
        $err  = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $raw = $resp;
        $lastHttp = $http;
        $lastErr  = $err;

        if ($err) {
            continue;
        }

        // kalau 404, cuba endpoint fallback seterusnya
        if ($http === 404) {
            continue;
        }

        $data = json_decode($resp, true);
        if (!is_array($data)) {
            return [
                'success'=>false,
                'message'=>'Response bukan JSON valid.',
                'http_code'=>$http,
                'raw'=>$resp,
                '_sent_ip'=>$clientIp,
                '_endpoint'=>$url,
            ];
        }

        $data['_http_code'] = $http;
        $data['_sent_ip']   = $clientIp;
        $data['_endpoint']  = $url;
        return $data;
    }

    return [
        'success'=>false,
        'message'=> $lastErr ? ('cURL error: '.$lastErr) : 'Endpoint tidak dijumpai / 404.',
        'http_code'=>$lastHttp,
        'raw'=>$raw,
        '_sent_ip'=>$clientIp,
    ];
}

/* ============================================================
   AJAX: fetch api games
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'fetch_api_games') {
    header('Content-Type: application/json');
    $data = gameviaRequest('check_games', new stdClass() ? [] : []); // {} json
    echo json_encode($data);
    exit;
}

/* ============================================================
   AJAX: fetch api products by api slug + check exist in DB for target slug
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'fetch_api_products') {
    header('Content-Type: application/json');

    $api_slug = trim($_POST['api_slug'] ?? '');
    $target_game_id = (int)($_POST['target_game_id'] ?? 0);

    if ($api_slug === '') {
        echo json_encode(['success'=>false,'message'=>'api_slug diperlukan.']);
        exit;
    }

    // decide target local slug
    $targetLocal = null;
    if ($target_game_id > 0) {
        $targetLocal = getLocalGameById($GLOBALS['conn'], $target_game_id);
        if (!$targetLocal) {
            echo json_encode(['success'=>false,'message'=>'Target game local tidak dijumpai.']);
            exit;
        }
    } else {
        $targetLocal = getLocalGameBySlug($GLOBALS['conn'], $api_slug);
        // boleh jadi null (tak wujud local)
    }

    $targetSlug = $targetLocal['slug'] ?? $api_slug;
    $targetGameId = (int)($targetLocal['id'] ?? 0);

    $resp = gameviaRequest('get_products', ['slug' => $api_slug]);
    if (empty($resp['success'])) {
        echo json_encode($resp);
        exit;
    }

    $products = $resp['products'] ?? [];
    $out = [];

    // batch check existing by srv_code
    $srvCodes = [];
    foreach ($products as $p) {
        if (!empty($p['srv_code'])) $srvCodes[] = (string)$p['srv_code'];
    }
    $existsMap = [];

    if ($srvCodes) {
        // make placeholders
        $placeholders = implode(',', array_fill(0, count($srvCodes), '?'));
        $types = str_repeat('s', count($srvCodes) + 1);

        $sql = "SELECT srv_code, id FROM products WHERE game_slug=? AND srv_code IN ($placeholders)";
        $stmt = $GLOBALS['conn']->prepare($sql);

        $params = array_merge([$targetSlug], $srvCodes);
        // bind_param dynamic
        $bindNames = [];
        $bindNames[] = $types;
        foreach ($params as $k => $v) $bindNames[] = &$params[$k];
        call_user_func_array([$stmt, 'bind_param'], $bindNames);

        $stmt->execute();
        $rs = $stmt->get_result();
        while ($r = $rs->fetch_assoc()) {
            $existsMap[(string)$r['srv_code']] = (int)$r['id'];
        }
        $stmt->close();
    }

    foreach ($products as $p) {
        $srv = (string)($p['srv_code'] ?? '');
        $out[] = [
            'name'      => (string)($p['name'] ?? ''),
            'srv_code'  => $srv,
            'vprice'    => (float)($p['vprice'] ?? 0),
            'image'     => (string)($p['image'] ?? ''),
            'game'      => (string)($p['game'] ?? $api_slug),
            'game_name' => (string)($p['game_name'] ?? ''),
            'exists'    => isset($existsMap[$srv]),
            'exists_id' => $existsMap[$srv] ?? 0,
        ];
    }

    echo json_encode([
        'success' => true,
        'api_slug' => $api_slug,
        'target' => [
            'target_game_id' => $targetGameId,
            'target_slug'    => $targetSlug,
            'target_name'    => $targetLocal['name'] ?? '(local game belum wujud)',
            'local_exists'   => (bool)$targetLocal,
        ],
        'count' => count($out),
        'products' => $out,
    ]);
    exit;
}

/* ============================================================
   AJAX: bulk add (selected/all) to target local game
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'bulk_add') {
    header('Content-Type: application/json');

    global $HAS_PROVIDER_PRICE, $HAS_PROVIDER_ACTIVE;

    $api_slug = trim($_POST['api_slug'] ?? '');
    $target_game_id = (int)($_POST['target_game_id'] ?? 0);
    $mode = trim($_POST['mode'] ?? 'selected'); // selected | all
    $selected = $_POST['selected'] ?? []; // array of srv_code
    if (!is_array($selected)) $selected = [];

    $resellerMarkup = (float)($_POST['reseller_markup'] ?? 0);
    $publicMarkup   = (float)($_POST['public_markup'] ?? 0);

    if ($api_slug === '') {
        echo json_encode(['success'=>false,'message'=>'api_slug diperlukan.']);
        exit;
    }

    // determine target local game
    $localGame = null;
    if ($target_game_id > 0) {
        $localGame = getLocalGameById($conn, $target_game_id);
        if (!$localGame) {
            echo json_encode(['success'=>false,'message'=>'Target game local tidak dijumpai.']);
            exit;
        }
    } else {
        $localGame = getLocalGameBySlug($conn, $api_slug);
        if (!$localGame) {
            echo json_encode(['success'=>false,'message'=>"Game local slug '$api_slug' belum wujud. Pilih Target Game Local."]);
            exit;
        }
    }

    $gameId     = (int)$localGame['id'];
    $targetSlug = (string)$localGame['slug'];

    $resp = gameviaRequest('get_products', ['slug'=>$api_slug]);
    if (empty($resp['success'])) {
        echo json_encode($resp);
        exit;
    }

    $apiProducts = $resp['products'] ?? [];
    if (!$apiProducts) {
        echo json_encode(['success'=>false,'message'=>'Tiada produk dari API.']);
        exit;
    }

    // filter products
    $pick = [];
    foreach ($apiProducts as $p) {
        $srv = (string)($p['srv_code'] ?? '');
        if ($srv === '') continue;

        if ($mode === 'all') {
            $pick[] = $p;
        } else {
            if (in_array($srv, $selected, true)) $pick[] = $p;
        }
    }

    if (!$pick) {
        echo json_encode(['success'=>false,'message'=>'Tiada produk dipilih untuk di-add.']);
        exit;
    }

    $added = 0;
    $updated = 0;

    foreach ($pick as $p) {
        $name = trim((string)($p['name'] ?? ''));
        $srv  = trim((string)($p['srv_code'] ?? ''));
        $vprice = (float)($p['vprice'] ?? 0);
        $img = trim((string)($p['image'] ?? ''));

        // apply markup
        $resellerPrice = $vprice * (1 + ($resellerMarkup / 100));
        $publicPrice   = $resellerPrice * (1 + ($publicMarkup / 100));

        $resellerPrice = round($resellerPrice, 2);
        $publicPrice   = round($publicPrice, 2);

        // check existing by (game_slug,targetSlug + srv_code)
        $stmt = $conn->prepare("SELECT id FROM products WHERE game_slug=? AND srv_code=? LIMIT 1");
        $stmt->bind_param("ss", $targetSlug, $srv);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $providerPrice = $vprice;
        $providerActive = 1;

        if ($row) {
            $pid = (int)$row['id'];

            if ($HAS_PROVIDER_PRICE && $HAS_PROVIDER_ACTIVE) {
                $stmt = $conn->prepare("
                    UPDATE products
                    SET game_id=?, product_name=?, icon=?,
                        public_price=?, reseller_price=?,
                        game_slug=?, srv_code=?, is_active=1, sort_order=0,
                        provider_price=?, provider_is_active=?
                    WHERE id=?
                ");
                $stmt->bind_param(
                    "issddsssdi i",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    $providerPrice, $providerActive,
                    $pid
                );
            } elseif ($HAS_PROVIDER_PRICE) {
                $stmt = $conn->prepare("
                    UPDATE products
                    SET game_id=?, product_name=?, icon=?,
                        public_price=?, reseller_price=?,
                        game_slug=?, srv_code=?, is_active=1, sort_order=0,
                        provider_price=?
                    WHERE id=?
                ");
                $stmt->bind_param(
                    "issddsssdi",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    $providerPrice,
                    $pid
                );
            } elseif ($HAS_PROVIDER_ACTIVE) {
                $stmt = $conn->prepare("
                    UPDATE products
                    SET game_id=?, product_name=?, icon=?,
                        public_price=?, reseller_price=?,
                        game_slug=?, srv_code=?, is_active=1, sort_order=0,
                        provider_is_active=?
                    WHERE id=?
                ");
                $stmt->bind_param(
                    "issddsssii",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    $providerActive,
                    $pid
                );
            } else {
                $stmt = $conn->prepare("
                    UPDATE products
                    SET game_id=?, product_name=?, icon=?,
                        public_price=?, reseller_price=?,
                        game_slug=?, srv_code=?, is_active=1, sort_order=0
                    WHERE id=?
                ");
                $stmt->bind_param(
                    "issddsss i",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    $pid
                );
            }

            $ok = $stmt->execute();
            $stmt->close();
            if ($ok) $updated++;
        } else {
            if ($HAS_PROVIDER_PRICE && $HAS_PROVIDER_ACTIVE) {
                $stmt = $conn->prepare("
                    INSERT INTO products
                    (game_id, product_name, icon, public_price, reseller_price, game_slug, srv_code, is_active, sort_order, provider_price, provider_is_active)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ");
                $stmt->bind_param(
                    "issddssiid i",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    $providerActive, 0,
                    $providerPrice, $providerActive
                );
            } elseif ($HAS_PROVIDER_PRICE) {
                $stmt = $conn->prepare("
                    INSERT INTO products
                    (game_id, product_name, icon, public_price, reseller_price, game_slug, srv_code, is_active, sort_order, provider_price)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                ");
                $stmt->bind_param(
                    "issddssiid",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    1, 0,
                    $providerPrice
                );
            } elseif ($HAS_PROVIDER_ACTIVE) {
                $stmt = $conn->prepare("
                    INSERT INTO products
                    (game_id, product_name, icon, public_price, reseller_price, game_slug, srv_code, is_active, sort_order, provider_is_active)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                ");
                $stmt->bind_param(
                    "issddssiii",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    1, 0,
                    $providerActive
                );
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO products
                    (game_id, product_name, icon, public_price, reseller_price, game_slug, srv_code, is_active, sort_order)
                    VALUES (?,?,?,?,?,?,?,?,?)
                ");
                $stmt->bind_param(
                    "issddssii",
                    $gameId, $name, $img,
                    $publicPrice, $resellerPrice,
                    $targetSlug, $srv,
                    1, 0
                );
            }

            $ok = $stmt->execute();
            $stmt->close();
            if ($ok) $added++;
        }
    }

    echo json_encode([
        'success'=>true,
        'message'=>"Bulk sync selesai. Added: $added, Updated: $updated",
        'added'=>$added,
        'updated'=>$updated,
        'target'=>[
            'game_id'=>$gameId,
            'slug'=>$targetSlug,
            'name'=>$localGame['name'] ?? ''
        ]
    ]);
    exit;
}

/* ============================================================
   LOAD LOCAL GAMES (for dropdown)
============================================================ */
$localGames = [];
$resLocal = $conn->query("SELECT id, name, slug FROM games ORDER BY name ASC");
if ($resLocal) {
    while ($r = $resLocal->fetch_assoc()) $localGames[] = $r;
}

/* ============================================================
   PAGE LOAD: check account (display only)
============================================================ */
$accountData = gameviaRequest('check_account', []);
$accountOk   = !empty($accountData['success']);
$account     = $accountOk ? ($accountData['account'] ?? []) : [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Provider - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
:root{
    --bg:#020617; --card:#0a0f1f; --border:#1e293b; --muted:#94a3b8; --text:#ffffff;
    --blue:#2563eb; --blue-soft:#1d4ed8; --green:#10b981; --red:#ef4444;
}
*{ box-sizing:border-box; }
body{ margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }

.admin-main{ max-width:1200px; margin:0 auto; padding:16px; }
@media(min-width:900px){ .admin-main{ margin-left:240px; } }

.page-head{ display:flex; align-items:flex-start; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-bottom:14px; }
.page-title{ font-size:20px; font-weight:600; }
.page-sub{ font-size:13px; color:var(--muted); }

.btn-primary{
    padding:8px 14px; border-radius:999px; border:none;
    background:linear-gradient(135deg,var(--blue),var(--blue-soft));
    color:#fff; font-size:13px; cursor:pointer;
    box-shadow:0 8px 20px rgba(37,99,235,0.6);
}
.btn-sm{
    padding:6px 10px; border-radius:999px;
    border:1px solid var(--border);
    background:#0f172a; color:#e5e7eb;
    font-size:12px; cursor:pointer;
}
.btn-danger{ border-color:#b91c1c; color:#fecaca; }

.grid{ display:grid; grid-template-columns: 1fr; gap:12px; }
.card{ background:var(--card); border:1px solid var(--border); border-radius:16px; padding:14px; }
.card-title{ font-size:14px; font-weight:600; margin:0 0 8px; }
.muted{ color:var(--muted); font-size:12px; }

.badge{ display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; border:1px solid var(--border); background:#0f172a; }
.badge-ok{ background:rgba(16,185,129,0.12); border-color:rgba(16,185,129,0.35); color:#86efac; }
.badge-bad{ background:rgba(239,68,68,0.12); border-color:rgba(239,68,68,0.35); color:#fecaca; }

.kv{ display:grid; grid-template-columns: 160px 1fr; gap:8px; font-size:13px; margin-top:10px; }
.k{ color:var(--muted); }
.v{ color:#e5e7eb; font-weight:500; word-break:break-word; }
hr.sep{ border:none; border-top:1px solid var(--border); margin:12px 0; }

.form-row{ display:flex; flex-wrap:wrap; gap:10px; align-items:end; }
.form-group{ display:flex; flex-direction:column; gap:6px; }
.form-label{ font-size:12px; color:var(--muted); }
.form-input{
    border-radius:999px; padding:8px 12px;
    border:1px solid var(--border);
    background:#020617; color:#fff; outline:none;
    font-size:13px;
}

.table-wrap{ background:var(--card); border:1px solid var(--border); border-radius:16px; overflow-x:auto; }
table{ width:100%; border-collapse:collapse; min-width:980px; font-size:12px; }
th,td{ padding:8px 6px; border-bottom:1px solid var(--border); text-align:left; vertical-align:top; }
th{ font-size:11px; color:var(--muted); text-transform:uppercase; font-weight:500; }

.pill{ display:inline-block; padding:2px 8px; border-radius:999px; border:1px solid var(--border); background:#020617; font-size:10px; color:#e5e7eb; }
.badge-active{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:10px; background:rgba(16,185,129,0.15); color:#4ade80; }
.badge-inactive{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:10px; background:rgba(239,68,68,0.15); color:#fca5a5; }

.thumb{ width:44px; height:44px; border-radius:12px; overflow:hidden; background:#0f172a; border:1px solid #1f2937; }
.thumb img{ width:100%; height:100%; object-fit:cover; }

.notice{
    background:#020617; border:1px solid var(--border);
    border-radius:12px; padding:10px; font-size:12px; color:#e5e7eb;
}
.codebox{
    background:#020617; border:1px solid var(--border); border-radius:12px;
    padding:10px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    font-size:12px; color:#e5e7eb; overflow:auto; max-height:220px;
}
</style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">
    <div class="page-head">
        <div>
            <div class="page-title">Provider (Gamevia)</div>
            <div class="page-sub">Filter game dari API → view product dalam table → bulk add ke slug game local.</div>
        </div>
        <button class="btn-primary" onclick="location.reload()">Refresh</button>
    </div>

    <div class="grid">
        <!-- ACCOUNT -->
        <div class="card">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;">
                <div>
                    <div class="card-title">Connection</div>
                    <div class="muted">Auto fallback endpoint (kalau .php 404, cuba tanpa .php)</div>
                </div>
                <?php if ($accountOk): ?>
                    <span class="badge badge-ok">Connected</span>
                <?php else: ?>
                    <span class="badge badge-bad">Not Connected</span>
                <?php endif; ?>
            </div>

            <hr class="sep">

            <?php if ($accountOk): ?>
                <div class="kv">
                    <div class="k">Username</div><div class="v"><?php echo htmlspecialchars($account['username'] ?? '-'); ?></div>
                    <div class="k">Email</div><div class="v"><?php echo htmlspecialchars($account['email'] ?? '-'); ?></div>
                    <div class="k">Phone</div><div class="v"><?php echo htmlspecialchars($account['phone'] ?? '-'); ?></div>
                    <div class="k">Balance</div><div class="v"><?php echo 'RM ' . number_format((float)($account['balance'] ?? 0), 2, '.', ','); ?></div>
                    <div class="k">Role</div><div class="v"><?php echo htmlspecialchars($account['role'] ?? '-'); ?></div>
                    <div class="k">KYC</div><div class="v"><?php echo htmlspecialchars($account['kyc_status'] ?? '-'); ?></div>
                </div>
                <hr class="sep">
                <div class="muted">
                    HTTP: <?php echo (int)($accountData['_http_code'] ?? 0); ?> ·
                    Sent IP: <b><?php echo htmlspecialchars($accountData['_sent_ip'] ?? '-'); ?></b> ·
                    Endpoint: <span class="pill"><?php echo htmlspecialchars($accountData['_endpoint'] ?? '-'); ?></span>
                </div>
            <?php else: ?>
                <div class="notice">
                    <b>Fail connect</b><br>
                    Message: <?php echo htmlspecialchars($accountData['message'] ?? 'Unknown'); ?><br><br>
                    <div class="muted">Raw (debug):</div>
                    <div class="codebox"><?php echo htmlspecialchars(json_encode($accountData, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- SYNC UI -->
        <div class="card">
            <div class="card-title">Sync Products</div>
            <div class="muted">Step: Load API games → pilih API slug → pilih target game local → load products → bulk add.</div>

            <hr class="sep">

            <div class="form-row" style="align-items:center;">
                <button class="btn-sm" id="btnLoadGames">Load API Games</button>

                <div class="form-group" style="min-width:220px;">
                    <div class="form-label">API Game Slug</div>
                    <select id="apiSlugSelect" class="form-input">
                        <option value="">-- pilih slug --</option>
                    </select>
                </div>

                <div class="form-group" style="min-width:320px;">
                    <div class="form-label">Target Game Local (DB games)</div>
                    <select id="targetLocalGame" class="form-input">
                        <option value="">-- default ikut API slug --</option>
                        <?php foreach ($localGames as $lg): ?>
                            <option value="<?php echo (int)$lg['id']; ?>">
                                <?php echo htmlspecialchars($lg['name'] . ' (' . $lg['slug'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button class="btn-sm" id="btnLoadProducts">Load Products</button>
            </div>

            <hr class="sep">

            <div class="form-row">
                <div class="form-group">
                    <div class="form-label">Reseller Markup (%)</div>
                    <input id="resellerMarkup" class="form-input" type="number" step="0.01" value="0" style="max-width:180px;">
                </div>
                <div class="form-group">
                    <div class="form-label">Public Markup (%)</div>
                    <input id="publicMarkup" class="form-input" type="number" step="0.01" value="0" style="max-width:180px;">
                </div>

                <button class="btn-sm" id="btnBulkSelected">Bulk Add (Selected)</button>
                <button class="btn-sm" id="btnBulkAll">Bulk Add (All)</button>

                <span class="muted" id="targetInfo" style="margin-left:auto;"></span>
            </div>
        </div>

        <!-- PRODUCTS TABLE -->
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th width="40"><input type="checkbox" id="checkAll"></th>
                        <th>Product</th>
                        <th>Srv Code</th>
                        <th>Provider Price</th>
                        <th>Preview Price (after markup)</th>
                        <th>Status DB</th>
                    </tr>
                </thead>
                <tbody id="providerTbody">
                    <tr><td colspan="6" class="muted" style="padding:14px;">Load API games dulu…</td></tr>
                </tbody>
            </table>
        </div>

    </div>
</div>

<script>
const btnLoadGames     = document.getElementById('btnLoadGames');
const btnLoadProducts  = document.getElementById('btnLoadProducts');
const apiSlugSelect    = document.getElementById('apiSlugSelect');
const targetLocalGame  = document.getElementById('targetLocalGame');
const providerTbody    = document.getElementById('providerTbody');
const checkAll         = document.getElementById('checkAll');

const resellerMarkupEl = document.getElementById('resellerMarkup');
const publicMarkupEl   = document.getElementById('publicMarkup');
const btnBulkSelected  = document.getElementById('btnBulkSelected');
const btnBulkAll       = document.getElementById('btnBulkAll');
const targetInfo       = document.getElementById('targetInfo');

let lastProducts = [];

btnLoadGames.addEventListener('click', loadApiGames);
btnLoadProducts.addEventListener('click', loadApiProducts);

checkAll.addEventListener('change', () => {
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = checkAll.checked);
});

resellerMarkupEl.addEventListener('input', renderProductsTable);
publicMarkupEl.addEventListener('input', renderProductsTable);

btnBulkSelected.addEventListener('click', () => doBulkAdd('selected'));
btnBulkAll.addEventListener('click', () => doBulkAdd('all'));

async function postForm(dataObj){
    const fd = new FormData();
    for (const k in dataObj) {
        const v = dataObj[k];
        if (Array.isArray(v)) {
            v.forEach(val => fd.append(k+'[]', val));
        } else {
            fd.append(k, v);
        }
    }

    const res = await fetch('provider.php', { method:'POST', body: fd });
    const text = await res.text();
    let json;
    try { json = JSON.parse(text); }
    catch(e){
        console.error('INVALID JSON:', text);
        alert('ERROR Invalid JSON from server\n\n' + text.slice(0, 600));
        return null;
    }
    return json;
}

async function loadApiGames(){
    providerTbody.innerHTML = `<tr><td colspan="6" class="muted" style="padding:14px;">Loading API games…</td></tr>`;
    apiSlugSelect.innerHTML = `<option value="">-- pilih slug --</option>`;

    const data = await postForm({ action:'fetch_api_games' });
    if (!data) return;

    if (!data.success) {
        providerTbody.innerHTML = `<tr><td colspan="6" style="padding:14px;color:#fecaca;">${escapeHtml(data.message || 'Gagal load games')}</td></tr>`;
        return;
    }

    const games = data.games || [];
    if (!games.length) {
        providerTbody.innerHTML = `<tr><td colspan="6" class="muted" style="padding:14px;">Tiada games dari API.</td></tr>`;
        return;
    }

    games.forEach(g => {
        const opt = document.createElement('option');
        opt.value = g.slug || '';
        opt.textContent = (g.name || g.slug) + ' (' + (g.slug||'') + ')';
        apiSlugSelect.appendChild(opt);
    });

    providerTbody.innerHTML = `<tr><td colspan="6" class="muted" style="padding:14px;">Pilih slug → klik Load Products.</td></tr>`;
}

async function loadApiProducts(){
    const slug = (apiSlugSelect.value || '').trim();
    if (!slug) { alert('Pilih API slug dulu.'); return; }

    providerTbody.innerHTML = `<tr><td colspan="6" class="muted" style="padding:14px;">Loading products untuk slug ${escapeHtml(slug)}…</td></tr>`;

    const data = await postForm({
        action:'fetch_api_products',
        api_slug: slug,
        target_game_id: targetLocalGame.value || 0
    });
    if (!data) return;

    if (!data.success) {
        providerTbody.innerHTML = `<tr><td colspan="6" style="padding:14px;color:#fecaca;">${escapeHtml(data.message || 'Gagal load products')}</td></tr>`;
        return;
    }

    lastProducts = data.products || [];
    const t = data.target || {};
    targetInfo.innerHTML =
        `Target: <b>${escapeHtml(t.target_name || '')}</b> · slug: <span class="pill">${escapeHtml(t.target_slug || '')}</span>` +
        (t.local_exists ? '' : ` · <span style="color:#fecaca;">(local game belum wujud)</span>`);

    renderProductsTable();
}

function renderProductsTable(){
    if (!lastProducts.length) {
        providerTbody.innerHTML = `<tr><td colspan="6" class="muted" style="padding:14px;">Tiada data.</td></tr>`;
        return;
    }

    const resellerMarkup = parseFloat(resellerMarkupEl.value || 0);
    const publicMarkup   = parseFloat(publicMarkupEl.value || 0);

    let html = '';
    lastProducts.forEach((p, idx) => {
        const vprice = parseFloat(p.vprice || 0);

        const reseller = round2(vprice * (1 + resellerMarkup/100));
        const pub      = round2(reseller * (1 + publicMarkup/100));

        const dbBadge = p.exists
            ? `<span class="badge-active">Exist (update)</span>`
            : `<span class="badge-inactive">New</span>`;

        const img = (p.image && p.image.trim()) ? p.image : '<?php echo htmlspecialchars(BASE_URL . "assets/img/games/default.png"); ?>';

        html += `
            <tr>
                <td><input class="row-check" type="checkbox" value="${escapeHtml(p.srv_code||'')}"></td>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="thumb"><img src="${escapeHtml(img)}" alt=""></div>
                        <div>
                            <div style="font-weight:600;">${escapeHtml(p.name||'')}</div>
                            <div class="muted" style="font-size:11px;">${escapeHtml(p.game_name || p.game || '')}</div>
                        </div>
                    </div>
                </td>
                <td><span class="pill">${escapeHtml(p.srv_code||'-')}</span></td>
                <td>RM ${vprice.toFixed(2)}</td>
                <td>
                    <div style="font-weight:600;">Public: RM ${pub.toFixed(2)}</div>
                    <div class="muted" style="font-size:11px;">Reseller: RM ${reseller.toFixed(2)}</div>
                </td>
                <td>${dbBadge}</td>
            </tr>
        `;
    });

    providerTbody.innerHTML = html;
    checkAll.checked = false;
}

async function doBulkAdd(mode){
    const slug = (apiSlugSelect.value || '').trim();
    if (!slug) { alert('Pilih API slug dulu.'); return; }

    let selected = [];
    if (mode === 'selected') {
        document.querySelectorAll('.row-check:checked').forEach(cb => selected.push(cb.value));
        if (!selected.length) { alert('Tick dulu produk yang nak add.'); return; }
    }

    if (!confirm(mode === 'all'
        ? 'Bulk add ALL products untuk slug ini?'
        : 'Bulk add SELECTED products?'
    )) return;

    const data = await postForm({
        action:'bulk_add',
        api_slug: slug,
        target_game_id: targetLocalGame.value || 0,
        mode: mode,
        selected: selected,
        reseller_markup: resellerMarkupEl.value || 0,
        public_markup: publicMarkupEl.value || 0
    });
    if (!data) return;

    if (!data.success) {
        alert(data.message || 'Bulk add gagal.');
        return;
    }

    alert(data.message || 'Done');
    // refresh table status
    await loadApiProducts();
}

function escapeHtml(s){
    return (s || '').toString().replace(/[&<>"']/g, m => ({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[m]));
}
function round2(n){ return Math.round((n + Number.EPSILON) * 100) / 100; }
</script>

</body>
</html>