<?php
// public/admin/site-settings.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Optional: bagi MySQL error terus keluar, senang debug
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// AUTH ADMIN
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

$successMsg = '';
$errorMsg   = '';

/* ============================================================
   LOAD CURRENT SETTINGS (ROW PERTAMA)
============================================================ */
$settings = [
    'id'               => null,
    'site_name'        => '',
    'site_description' => '',
    'logo_url'         => '',
    'favicon_url'      => '',
    'instagram'        => '',
    'tiktok'           => '',
    'whatsapp'         => '',
    'theme_color'      => '#2563eb', // default
    'is_active'        => 1,
];

$res = $conn->query("SELECT * FROM site_settings ORDER BY id ASC LIMIT 1");
if ($res && $res->num_rows > 0) {
    $settings = $res->fetch_assoc();
    if (empty($settings['theme_color'])) {
        $settings['theme_color'] = '#2563eb';
    }
}

/* ============================================================
   HANDLE SAVE
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_settings') {

    $site_name        = trim($_POST['site_name'] ?? '');
    $site_description = trim($_POST['site_description'] ?? '');
    $logo_url         = trim($_POST['logo_url'] ?? '');
    $favicon_url      = trim($_POST['favicon_url'] ?? '');
    $instagram        = trim($_POST['instagram'] ?? '');
    $tiktok           = trim($_POST['tiktok'] ?? '');
    $whatsapp         = trim($_POST['whatsapp'] ?? '');
    $theme_color      = trim($_POST['theme_color'] ?? '#2563eb');
    $is_active        = isset($_POST['is_active']) ? 1 : 0;

    // sanitize color (simple)
    if ($theme_color === '' || !preg_match('/^#([A-Fa-f0-9]{6})$/', $theme_color)) {
        $theme_color = '#2563eb';
    }

    if ($site_name === '') {
        $errorMsg = 'Nama website wajib diisi.';
    } else {

        // check dah ada row ke belum
        $resCheck = $conn->query("SELECT id FROM site_settings ORDER BY id ASC LIMIT 1");
        if ($resCheck && $resCheck->num_rows > 0) {
            // UPDATE
            $row = $resCheck->fetch_assoc();
            $id  = (int)$row['id'];

            $stmt = $conn->prepare("
                UPDATE site_settings
                SET site_name = ?,
                    site_description = ?,
                    logo_url = ?,
                    favicon_url = ?,
                    instagram = ?,
                    tiktok = ?,
                    whatsapp = ?,
                    theme_color = ?,
                    is_active = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            // 8 string + 2 int => "ssssssssii"
            $stmt->bind_param(
                "ssssssssii",
                $site_name,
                $site_description,
                $logo_url,
                $favicon_url,
                $instagram,
                $tiktok,
                $whatsapp,
                $theme_color,
                $is_active,
                $id
            );
            $stmt->execute();
            $stmt->close();
        } else {
            // INSERT
            $stmt = $conn->prepare("
                INSERT INTO site_settings
                    (site_name, site_description, logo_url, favicon_url,
                     instagram, tiktok, whatsapp, theme_color, is_active)
                VALUES (?,?,?,?,?,?,?,?,?)
            ");
            // 8 string + 1 int => "ssssssssi"
            $stmt->bind_param(
                "ssssssssi",
                $site_name,
                $site_description,
                $logo_url,
                $favicon_url,
                $instagram,
                $tiktok,
                $whatsapp,
                $theme_color,
                $is_active
            );
            $stmt->execute();
            $stmt->close();
        }

        $successMsg = 'Site settings berjaya dikemaskini.';

        // refresh $settings untuk isi form balik
        $res = $conn->query("SELECT * FROM site_settings ORDER BY id ASC LIMIT 1");
        if ($res && $res->num_rows > 0) {
            $settings = $res->fetch_assoc();
            if (empty($settings['theme_color'])) {
                $settings['theme_color'] = '#2563eb';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Site Settings - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
:root{
    --bg:#020617;
    --card:#020818;
    --border:#1e293b;
    --muted:#94a3b8;
    --text:#ffffff;
    --blue:#2563eb;
    --blue-soft:#1d4ed8;
}

*{ box-sizing:border-box; }
body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:var(--bg);
    color:var(--text);
}

.admin-main{
    max-width:900px;
    margin:0 auto;
    padding:16px;
}
@media(min-width:900px){
    .admin-main{ margin-left:240px; }
}

.page-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
    flex-wrap:wrap;
    margin-bottom:16px;
}
.page-title{
    font-size:20px;
    font-weight:600;
}
.page-sub{
    font-size:13px;
    color:var(--muted);
}

.card{
    background:var(--card);
    border-radius:16px;
    border:1px solid var(--border);
    padding:14px 14px 18px;
    box-shadow:0 18px 40px rgba(0,0,0,0.75);
}

.section-title{
    font-size:14px;
    font-weight:600;
    margin:10px 0 6px;
}

.form-row{
    display:flex;
    flex-direction:column;
    margin-bottom:10px;
}
.form-row label{
    font-size:12px;
    margin-bottom:4px;
}
.form-input, .form-textarea{
    width:100%;
    border-radius:10px;
    border:1px solid #1f2937;
    background:#020b1a;
    color:#e5e7eb;
    padding:7px 9px;
    font-size:13px;
    outline:none;
}
.form-textarea{
    min-height:80px;
    resize:vertical;
}

.grid-2{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:10px;
}
@media(max-width:600px){
    .grid-2{ grid-template-columns:1fr; }
}

.logo-preview{
    width:140px;
    height:46px;
    border-radius:10px;
    background:#020617;
    border:1px solid #1f2937;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-bottom:8px;
}
.logo-preview img{
    max-width:100%;
    max-height:100%;
    object-fit:contain;
}

.btn-primary{
    background:linear-gradient(135deg,var(--blue),var(--blue-soft));
    padding:8px 18px;
    border-radius:999px;
    border:none;
    color:#fff;
    font-size:13px;
    font-weight:500;
    cursor:pointer;
    box-shadow:0 8px 20px rgba(37,99,235,0.6);
}
.alert{
    border-radius:10px;
    padding:8px 10px;
    font-size:12px;
    margin-bottom:10px;
}
.alert-success{
    background:rgba(22,163,74,0.12);
    border:1px solid rgba(22,163,74,0.6);
    color:#bbf7d0;
}
.alert-error{
    background:rgba(239,68,68,0.12);
    border:1px solid rgba(239,68,68,0.7);
    color:#fecaca;
}

.badge-switch{
    display:flex;
    align-items:center;
    gap:6px;
    font-size:12px;
}

/* THEME SECTION */
.theme-wrap{
    border:1px solid rgba(148,163,184,0.25);
    background:#020617;
    border-radius:14px;
    padding:12px;
    margin-top:6px;
}
.theme-grid{
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap:10px;
}
@media(max-width:700px){
    .theme-grid{ grid-template-columns:1fr; }
}
.theme-controls{
    display:grid;
    grid-template-columns: 110px 1fr;
    gap:10px;
    align-items:center;
}
.theme-preview{
    border:1px solid rgba(148,163,184,0.25);
    background:#0b1224;
    border-radius:14px;
    padding:12px;
}
.preview-btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:9px 14px;
    border-radius:999px;
    border:none;
    color:#fff;
    font-size:13px;
    font-weight:600;
    cursor:default;
    user-select:none;
}
.preview-pill{
    display:inline-block;
    padding:3px 10px;
    border-radius:999px;
    font-size:11px;
    border:1px solid rgba(148,163,184,0.25);
    background:rgba(255,255,255,0.03);
    margin-left:8px;
}
.preview-line{
    margin-top:10px;
    padding:10px;
    border-radius:12px;
    border:1px dashed rgba(148,163,184,0.35);
    font-size:12px;
    color:#cbd5e1;
}

.palette{
    display:flex;
    flex-wrap:wrap;
    gap:8px;
    margin-top:10px;
}
.swatch{
    width:34px;
    height:34px;
    border-radius:12px;
    border:1px solid rgba(148,163,184,0.35);
    cursor:pointer;
    position:relative;
}
.swatch:hover{
    transform: translateY(-1px);
}
.swatch:active{
    transform: translateY(0px);
}
.swatch span{
    position:absolute;
    bottom:-18px;
    left:50%;
    transform:translateX(-50%);
    font-size:10px;
    color:#94a3b8;
    white-space:nowrap;
    display:none;
}
.swatch:hover span{ display:block; }

.small-help{ font-size:11px;color:#94a3b8;margin-top:4px; }
</style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div>
            <div class="page-title">Site Settings</div>
            <div class="page-sub">Ubah logo, nama website, deskripsi, link sosial media & theme color.</div>
        </div>
    </div>

    <div class="card">
        <?php if ($successMsg): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($successMsg); ?></div>
        <?php endif; ?>
        <?php if ($errorMsg): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($errorMsg); ?></div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="action" value="save_settings">

            <!-- GENERAL -->
            <div class="section-title">Umum</div>

            <div class="form-row">
                <label>Nama Website</label>
                <input type="text" name="site_name" class="form-input"
                       value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>" required>
            </div>

            <div class="form-row">
                <label>Deskripsi Ringkas / About (guna juga untuk footer)</label>
                <textarea name="site_description" class="form-textarea"><?php
                    echo htmlspecialchars($settings['site_description'] ?? '');
                ?></textarea>
            </div>

            <!-- THEME COLOR -->
            <div class="section-title">Theme Colour</div>

            <?php
                $currentTheme = $settings['theme_color'] ?? '#2563eb';
                if (!$currentTheme) $currentTheme = '#2563eb';
            ?>

            <div class="theme-wrap">
                <div class="theme-grid">
                    <!-- controls -->
                    <div>
                        <div class="form-row" style="margin-bottom:8px;">
                            <label>Theme Color (Hex)</label>
                            <input type="text" name="theme_color" id="themeHex" class="form-input"
                                   placeholder="#2563eb"
                                   value="<?php echo htmlspecialchars($currentTheme); ?>">
                            <div class="small-help">Format: <b>#RRGGBB</b> contoh: #2563eb</div>
                        </div>

                        <div class="theme-controls">
                            <div style="font-size:12px;color:#e5e7eb;">Picker</div>
                            <input type="color" id="themePicker" value="<?php echo htmlspecialchars($currentTheme); ?>"
                                   style="width:100%;height:42px;border-radius:12px;border:1px solid #1f2937;background:#020b1a; padding:4px;">
                        </div>

                        <div class="small-help" style="margin-top:10px;">Quick colors (klik untuk auto isi):</div>
                        <div class="palette" id="palette">
                            <!-- add as many as you want -->
                            <div class="swatch" data-color="#2563eb" style="background:#2563eb"><span>#2563eb</span></div>
                            <div class="swatch" data-color="#10b981" style="background:#10b981"><span>#10b981</span></div>
                            <div class="swatch" data-color="#f59e0b" style="background:#f59e0b"><span>#f59e0b</span></div>
                            <div class="swatch" data-color="#ef4444" style="background:#ef4444"><span>#ef4444</span></div>
                            <div class="swatch" data-color="#a855f7" style="background:#a855f7"><span>#a855f7</span></div>
                            <div class="swatch" data-color="#06b6d4" style="background:#06b6d4"><span>#06b6d4</span></div>
                            <div class="swatch" data-color="#22c55e" style="background:#22c55e"><span>#22c55e</span></div>
                            <div class="swatch" data-color="#0ea5e9" style="background:#0ea5e9"><span>#0ea5e9</span></div>
                            <div class="swatch" data-color="#e11d48" style="background:#e11d48"><span>#e11d48</span></div>
                            <div class="swatch" data-color="#111827" style="background:#111827"><span>#111827</span></div>
                        </div>
                    </div>

                    <!-- preview -->
                    <div class="theme-preview">
                        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                            <div class="preview-btn" id="previewBtn">Preview Button</div>
                            <span class="preview-pill" id="previewPill">Badge / Pill</span>
                        </div>
                        <div class="preview-line" id="previewLine">
                            Preview border/outline box — ini contoh section UI ikut theme.
                        </div>
                        <div class="small-help" style="margin-top:10px;">
                            Tip: Semua UI website guna variable CSS <code>--theme</code> nanti.
                        </div>
                    </div>
                </div>
            </div>

            <!-- LOGO & FAVICON -->
            <div class="section-title">Logo & Favicon</div>

            <div class="grid-2">
                <div class="form-row">
                    <label>Preview Logo</label>
                    <div class="logo-preview">
                        <img id="logoPreview"
                             src="<?php echo htmlspecialchars($settings['logo_url'] ?: BASE_URL.'assets/img/logo.png'); ?>"
                             alt="Logo">
                    </div>
                    <label>URL Logo (header & sidebar)</label>
                    <input type="text" name="logo_url" id="logoUrlField" class="form-input"
                           value="<?php echo htmlspecialchars($settings['logo_url'] ?? ''); ?>"
                           oninput="document.getElementById('logoPreview').src = this.value || '<?php echo BASE_URL; ?>assets/img/logo.png';">
                </div>

                <div class="form-row">
                    <label>URL Favicon (opsyenal)</label>
                    <input type="text" name="favicon_url" class="form-input"
                           placeholder="https://contoh.com/favicon.ico"
                           value="<?php echo htmlspecialchars($settings['favicon_url'] ?? ''); ?>">
                    <small style="font-size:11px;color:#9ca3af;">
                        Boleh guna .ico / .png kecil.
                    </small>
                </div>
            </div>

            <!-- SOCIAL -->
            <div class="section-title">Social Media</div>

            <div class="grid-2">
                <div class="form-row">
                    <label>Instagram URL</label>
                    <input type="text" name="instagram" class="form-input"
                           placeholder="https://instagram.com/..."
                           value="<?php echo htmlspecialchars($settings['instagram'] ?? ''); ?>">
                </div>
                <div class="form-row">
                    <label>TikTok URL</label>
                    <input type="text" name="tiktok" class="form-input"
                           placeholder="https://www.tiktok.com/@..."
                           value="<?php echo htmlspecialchars($settings['tiktok'] ?? ''); ?>">
                </div>
            </div>

            <div class="form-row">
                <label>WhatsApp URL</label>
                <input type="text" name="whatsapp" class="form-input"
                       placeholder="https://wa.me/60123456789"
                       value="<?php echo htmlspecialchars($settings['whatsapp'] ?? ''); ?>">
            </div>

            <!-- STATUS -->
            <div class="section-title">Status</div>
            <div class="form-row">
                <label class="badge-switch">
                    <input type="checkbox" name="is_active" value="1"
                           <?php echo (!isset($settings['is_active']) || (int)$settings['is_active'] === 1) ? 'checked' : ''; ?>>
                    <span>Aktifkan settings ini</span>
                </label>
            </div>

            <div style="margin-top:14px; text-align:right;">
                <button type="submit" class="btn-primary">Simpan Perubahan</button>
            </div>
        </form>
    </div>

</div>

<script>
const themeHex    = document.getElementById('themeHex');
const themePicker = document.getElementById('themePicker');

const previewBtn  = document.getElementById('previewBtn');
const previewPill = document.getElementById('previewPill');
const previewLine = document.getElementById('previewLine');

function isValidHexColor(v){
    return /^#([A-Fa-f0-9]{6})$/.test(v);
}

function applyThemePreview(color){
    // button gradient ringan
    previewBtn.style.background = `linear-gradient(135deg, ${color}, rgba(0,0,0,0.25))`;
    previewBtn.style.boxShadow  = `0 10px 24px ${color}55`;

    previewPill.style.borderColor = color + "66";
    previewPill.style.color       = "#e5e7eb";
    previewPill.style.background  = color + "18";

    previewLine.style.borderColor = color + "88";
}

function setThemeColor(color){
    themeHex.value = color;
    themePicker.value = color;
    applyThemePreview(color);
}

// init
setThemeColor(themeHex.value && isValidHexColor(themeHex.value) ? themeHex.value : '#2563eb');

themePicker.addEventListener('input', () => {
    setThemeColor(themePicker.value);
});

themeHex.addEventListener('input', () => {
    const v = themeHex.value.trim();
    if (isValidHexColor(v)) applyThemePreview(v);
});

// palette click
document.querySelectorAll('.swatch').forEach(el => {
    el.addEventListener('click', () => {
        const c = el.getAttribute('data-color');
        if (c) setThemeColor(c);
    });
});
</script>

</body>
</html>