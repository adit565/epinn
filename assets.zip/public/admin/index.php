<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login");
    exit;
}
if (($_SESSION['role'] ?? '') !== 'admin') {
    echo "<h2 style='color:white;text-align:center;margin-top:50px;'>Akses ditolak (Admin sahaja).</h2>";
    exit;
}

function safeCount($conn, $sql){
    try{
        $q = $conn->query($sql);
        if($q && $row = $q->fetch_assoc()) return (int)$row['c'];
    }catch(Throwable $e){}
    return 0;
}

$totUsers    = safeCount($conn, "SELECT COUNT(*) AS c FROM users");
$totGames    = safeCount($conn, "SELECT COUNT(*) AS c FROM games");
$totProducts = safeCount($conn, "SELECT COUNT(*) AS c FROM products");
$totTrans    = safeCount($conn, "SELECT COUNT(*) AS c FROM transactions");

/* ====== Transaksi terbaru ====== */
$latestTrans = [];
try{
    $sql = "SELECT t.id,
                   t.status,
                   t.amount,
                   t.created_at,
                   u.name AS user_name
            FROM transactions t
            LEFT JOIN users u ON u.id = t.user_id
            ORDER BY t.created_at DESC
            LIMIT 5";
    if ($q = $conn->query($sql)) {
        while($row = $q->fetch_assoc()){
            $latestTrans[] = $row;
        }
    }
}catch(Throwable $e){}

/* ====== User terbaru ====== */
$latestUsers = [];
try{
    $sql = "SELECT id, name, email, role, created_at
            FROM users
            ORDER BY created_at DESC
            LIMIT 5";
    if ($q = $conn->query($sql)) {
        while($row = $q->fetch_assoc()){
            $latestUsers[] = $row;
        }
    }
}catch(Throwable $e){}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    :root{
        --bg-main:#020617;
        --bg-box:#020617;
        --bg-card:#0b1220;
        --text-main:#ffffff;
        --text-muted:#9ca3af;
        --border:#1f2937;
        --blue:#2563eb;
    }
    *{box-sizing:border-box;}
    body{
        margin:0;
        font-family:'Poppins',sans-serif;
        background:var(--bg-main);
        color:var(--text-main);
    }

    .admin-main{
        max-width: 1100px;
        margin: 0 auto;
        padding: 16px;
    }
    @media(min-width:900px){
        .admin-main{
            margin-left: 230px; /* ruang sidebar */
        }
    }

    .page-title{
        font-size:22px;
        font-weight:600;
        margin-bottom:4px;
    }
    .page-sub{
        font-size:13px;
        color:var(--text-muted);
        margin-bottom:18px;
    }

    .stats-grid{
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:10px;
        margin-bottom:20px;
    }
    @media(min-width:768px){
        .stats-grid{
            grid-template-columns:repeat(4,minmax(0,1fr));
        }
    }
    .stat-card{
        padding:14px 16px;
        border-radius:16px;
        background:var(--bg-card);
        border:1px solid var(--border);
    }
    .stat-label{
        font-size:12px;
        color:var(--text-muted);
        margin-bottom:4px;
    }
    .stat-value{
        font-size:22px;
        font-weight:600;
    }

    .two-column{
        display:flex;
        flex-direction:column;
        gap:14px;
    }
    @media(min-width:900px){
        .two-column{
            flex-direction:row;
            align-items:flex-start;
        }
    }
    .panel{
        flex:1;
        background:var(--bg-card);
        border-radius:16px;
        border:1px solid var(--border);
        padding:14px 16px;
    }
    .panel-title{
        font-size:15px;
        font-weight:500;
        margin-bottom:8px;
    }
    .panel-sub{
        font-size:12px;
        color:var(--text-muted);
        margin-bottom:10px;
    }

    table{
        width:100%;
        border-collapse:collapse;
        font-size:12px;
    }
    th,td{
        padding:6px 4px;
        border-bottom:1px solid rgba(31,41,55,0.9);
        text-align:left;
        white-space:nowrap;
    }
    th{
        color:var(--text-muted);
        font-weight:500;
        font-size:11px;
    }
    tr:last-child td{
        border-bottom:none;
    }
    .badge{
        display:inline-block;
        padding:2px 7px;
        border-radius:999px;
        font-size:11px;
    }
    .badge-success{
        background:rgba(34,197,94,0.15);
        color:#4ade80;
    }
    .badge-pending{
        background:rgba(234,179,8,0.15);
        color:#facc15;
    }
    .badge-failed{
        background:rgba(248,113,113,0.15);
        color:#fca5a5;
    }
</style>
</head>
<body>

<?php include __DIR__ . '/include/sidebar.php'; ?>
<?php include __DIR__ . '/include/header.php'; ?>

<div class="admin-main">

    <div class="page-title">Dashboard Admin</div>
    <div class="page-sub">Selamat datang, <?php echo htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?>.</div>

    <!-- STATISTIK RINGKAS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-label">Total Users</div>
            <div class="stat-value"><?php echo $totUsers; ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Games</div>
            <div class="stat-value"><?php echo $totGames; ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Products</div>
            <div class="stat-value"><?php echo $totProducts; ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Total Transaksi</div>
            <div class="stat-value"><?php echo $totTrans; ?></div>
        </div>
    </div>

    <!-- 2 PANEL: TRANSAKSI & USERS -->
    <div class="two-column">
        <!-- Transaksi -->
        <div class="panel">
            <div class="panel-title">Transaksi Terbaru</div>
            <div class="panel-sub">5 transaksi terakhir dari sistem.</div>

            <?php if (count($latestTrans) === 0): ?>
                <div style="font-size:12px;color:var(--text-muted);">Belum ada transaksi.</div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Jumlah</th>
                                <th>Status</th>
                                <th>Tarikh</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($latestTrans as $t): ?>
                            <?php
                                $status = strtolower($t['status'] ?? '');
                                if ($status === 'success' || $status === 'paid') {
                                    $badgeClass = 'badge-success';
                                    $text = 'Berjaya';
                                } elseif ($status === 'pending') {
                                    $badgeClass = 'badge-pending';
                                    $text = 'Pending';
                                } else {
                                    $badgeClass = 'badge-failed';
                                    $text = $status ?: 'Unknown';
                                }

                                $amount = isset($t['amount']) ? number_format((float)$t['amount'], 2) : '-';
                                $date   = !empty($t['created_at']) ? date('d/m H:i', strtotime($t['created_at'])) : '-';
                            ?>
                            <tr>
                                <td>#<?php echo (int)$t['id']; ?></td>
                                <td><?php echo htmlspecialchars($t['user_name'] ?? '-'); ?></td>
                                <td><?php echo $amount; ?></td>
                                <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($text); ?></span></td>
                                <td><?php echo $date; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Users -->
        <div class="panel">
            <div class="panel-title">User Terbaru</div>
            <div class="panel-sub">5 user terakhir yang mendaftar.</div>

            <?php if (count($latestUsers) === 0): ?>
                <div style="font-size:12px;color:var(--text-muted);">Belum ada user.</div>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Tarikh</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($latestUsers as $u): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($u['name']); ?></td>
                                <td><?php echo htmlspecialchars($u['email']); ?></td>
                                <td><?php echo htmlspecialchars($u['role']); ?></td>
                                <td><?php echo !empty($u['created_at']) ? date('d/m', strtotime($u['created_at'])) : '-'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>

</body>
</html>