<?php
// public/admin/banners.php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ============================================================
   GET BANNER BY ID
============================================================ */
function getBanner($conn, $id){
    $stmt = $conn->prepare("
        SELECT id, title, image_url, link_url, is_active, sort_order, created_at
        FROM banners WHERE id = ? LIMIT 1
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    return $row;
}

/* ============================================================
   AJAX: SAVE BANNER (ADD / EDIT)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_banner') {
    header('Content-Type: application/json');

    $id         = (int)($_POST['id'] ?? 0);
    $title      = trim($_POST['title'] ?? '');
    $image_url  = trim($_POST['image_url'] ?? '');
    $link_url   = trim($_POST['link_url'] ?? '');
    $is_active  = isset($_POST['is_active']) ? 1 : 0;
    $sort_order = (int)($_POST['sort_order'] ?? 0);

    if ($title === '' || $image_url === '') {
        echo json_encode([
            'success' => false,
            'message' => 'Title & URL Banner wajib diisi.'
        ]);
        exit;
    }

    if ($id > 0) {
        // UPDATE
        $stmt = $conn->prepare("
            UPDATE banners
            SET title=?, image_url=?, link_url=?, is_active=?, sort_order=?
            WHERE id=?
        ");
        $stmt->bind_param("sssiii", $title, $image_url, $link_url, $is_active, $sort_order, $id);
        $stmt->execute();
        $stmt->close();
        $newId = $id;
    } else {
        // INSERT
        $stmt = $conn->prepare("
            INSERT INTO banners (title, image_url, link_url, is_active, sort_order)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("sssii", $title, $image_url, $link_url, $is_active, $sort_order);
        $stmt->execute();
        $newId = $stmt->insert_id;
        $stmt->close();
    }

    echo json_encode([
        'success' => true,
        'banner'  => getBanner($conn, $newId)
    ]);
    exit;
}

/* ============================================================
   AJAX: DELETE BANNER
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_banner') {
    header('Content-Type: application/json');
    $id = (int)($_POST['id'] ?? 0);

    if ($id <= 0){
        echo json_encode(['success'=>false,'message'=>'ID tidak sah.']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM banners WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected < 1) {
        echo json_encode(['success'=>false,'message'=>'Gagal delete.']);
        exit;
    }

    echo json_encode(['success'=>true]);
    exit;
}

/* ============================================================
   LOAD ALL BANNERS
============================================================ */
$banners = [];
$res = $conn->query("
    SELECT id, title, image_url, link_url, is_active, sort_order, created_at
    FROM banners 
    ORDER BY sort_order ASC, id DESC
");
while ($row = $res->fetch_assoc()){
    $banners[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Banners - Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
    :root{
        --bg:#020617;
        --panel:#0a0f1f;
        --border:#1e293b;
        --text:#fff;
        --muted:#94a3b8;
        --blue:#2563eb;
        --blue-soft:#1d4ed8;
    }
    body{
        margin:0;
        font-family:"Poppins",sans-serif;
        background:var(--bg);
        color:var(--text);
    }
    .admin-main{
        max-width:1100px;
        margin:0 auto;
        padding:16px;
    }
    @media(min-width:900px){
        .admin-main{ margin-left:240px; }
    }

    .page-head{
        display:flex;
        justify-content:space-between;
        align-items:flex-start;
        flex-wrap:wrap;
        margin-bottom:14px;
    }
    .page-title{ font-size:20px; font-weight:600; }
    .page-sub{ font-size:13px; color:var(--muted); }

    .btn-primary{
        padding:8px 14px;
        border-radius:999px;
        border:none;
        background:linear-gradient(135deg,var(--blue),var(--blue-soft));
        color:#fff;
        cursor:pointer;
        font-size:13px;
        box-shadow:0 8px 22px rgba(37,99,235,.75);
    }

    .banner-list{
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(320px,1fr));
        gap:16px;
        margin-top:16px;
    }

    .banner-card{
        background:var(--panel);
        border:1px solid var(--border);
        border-radius:16px;
        padding:10px;
    }

    .banner-img{
        width:100%;
        border-radius:14px;
        overflow:hidden;
        background:#000;
    }
    .banner-img img{
        width:100%;
        height:auto;
        display:block;
    }

    .banner-title{ font-size:14px; font-weight:600; margin-top:8px; }
    .banner-link{ font-size:12px; color:var(--muted); word-break:break-all; }
    .banner-sort{ font-size:11px; color:var(--muted); margin-top:2px; }

    .badge-active{
        background:rgba(16,185,129,.2);
        color:#4ade80;
        padding:2px 8px;
        border-radius:999px;
        font-size:10px;
        display:inline-block;
        margin-top:6px;
    }
    .badge-inactive{
        background:rgba(239,68,68,.2);
        color:#fca5a5;
        padding:2px 8px;
        border-radius:999px;
        font-size:10px;
        display:inline-block;
        margin-top:6px;
    }

    .btn-sm{
        padding:5px 9px;
        font-size:11px;
        background:#0f172a;
        border:1px solid var(--border);
        color:#e5e7eb;
        cursor:pointer;
        border-radius:999px;
        margin-top:8px;
        margin-right:4px;
    }
    .btn-danger{
        border-color:#b91c1c;
        color:#fecaca;
    }

    /* MODAL */
    .modal-backdrop{
        position:fixed; inset:0;
        background:rgba(0,0,0,.7);
        display:none;
        align-items:center;
        justify-content:center;
        z-index:120;
    }
    .modal-backdrop.show{ display:flex; }
    .modal{
        width:100%; max-width:420px;
        background:#020617;
        border-radius:16px;
        border:1px solid var(--border);
        padding:16px;
    }
    .modal-title{
        margin:0 0 10px;
        font-size:16px;
    }
    .form-group{ margin-bottom:10px; }
    .form-label{ font-size:12px; margin-bottom:4px; display:block; }
    .form-input{
        width:100%; border-radius:10px;
        padding:7px 9px; font-size:13px;
        border:1px solid #1e293b;
        background:#0f172a;
        color:#fff;
    }
    .form-check{ display:flex; align-items:center; gap:6px; font-size:12px; }
    .modal-footer{ text-align:right; margin-top:10px; }
</style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div>
            <div class="page-title">Banners</div>
            <div class="page-sub">Urus paparan banner untuk homepage.</div>
        </div>
        <button class="btn-primary" onclick="openBannerModal()">+ Tambah Banner</button>
    </div>

    <div class="banner-list" id="bannerList">
        <?php foreach ($banners as $b): ?>
            <div class="banner-card" id="banner-<?php echo $b['id']; ?>">

                <div class="banner-img">
                    <img src="<?php echo htmlspecialchars($b['image_url']); ?>">
                </div>

                <div class="banner-title"><?php echo htmlspecialchars($b['title']); ?></div>
                <div class="banner-link"><?php echo htmlspecialchars($b['link_url'] ?: '-'); ?></div>
                <div class="banner-sort">Sort: <?php echo (int)$b['sort_order']; ?></div>

                <?php if ($b['is_active']): ?>
                    <span class="badge-active">Active</span>
                <?php else: ?>
                    <span class="badge-inactive">Inactive</span>
                <?php endif; ?>

                <br>

                <button class="btn-sm"
                    onclick='openBannerModal(<?php echo json_encode($b); ?>)'>Edit</button>

                <button class="btn-sm"
                    onclick='copyBanner(<?php echo json_encode($b); ?>)'>Copy</button>

                <button class="btn-sm btn-danger"
                    onclick='deleteBanner(<?php echo $b["id"]; ?>)'>Delete</button>
            </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- MODAL -->
<div class="modal-backdrop" id="bannerModal">
    <div class="modal">
        <h3 class="modal-title" id="modalTitle">Tambah Banner</h3>

        <form id="bannerForm">
            <input type="hidden" name="action" value="save_banner">
            <input type="hidden" name="id" id="bannerId">

            <div class="form-group">
                <label class="form-label">Title</label>
                <input type="text" class="form-input" name="title" id="bannerTitle" required>
            </div>

            <div class="form-group">
                <label class="form-label">Image URL</label>
                <input type="text" class="form-input" name="image_url" id="bannerImage" required>
            </div>

            <div class="form-group">
                <label class="form-label">Link URL</label>
                <input type="text" class="form-input" name="link_url" id="bannerLink">
            </div>

            <div class="form-group">
                <label class="form-label">Sort Order</label>
                <input type="number" class="form-input" name="sort_order" id="bannerSort" value="0">
            </div>

            <div class="form-group form-check">
                <input type="checkbox" name="is_active" id="bannerActive" checked>
                <label for="bannerActive">Active</label>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn-sm" onclick="closeBannerModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<script>
const bannerList   = document.getElementById('bannerList');
const bannerModal  = document.getElementById('bannerModal');
const modalTitle   = document.getElementById('modalTitle');
const bannerForm   = document.getElementById('bannerForm');

const fId          = document.getElementById('bannerId');
const fTitle       = document.getElementById('bannerTitle');
const fImage       = document.getElementById('bannerImage');
const fLink        = document.getElementById('bannerLink');
const fSort        = document.getElementById('bannerSort');
const fActive      = document.getElementById('bannerActive');

/* OPEN MODAL */
function openBannerModal(b=null){
    if (b){
        modalTitle.textContent = 'Edit Banner';
        fId.value     = b.id;
        fTitle.value  = b.title;
        fImage.value  = b.image_url;
        fLink.value   = b.link_url;
        fSort.value   = b.sort_order;
        fActive.checked = b.is_active == 1;
    } else {
        modalTitle.textContent = 'Tambah Banner';
        fId.value     = '';
        fTitle.value  = '';
        fImage.value  = '';
        fLink.value   = '';
        fSort.value   = 0;
        fActive.checked = true;
    }
    bannerModal.classList.add('show');
}

/* COPY BANNER */
function copyBanner(b){
    openBannerModal({
        ...b,
        id:''
    });
    modalTitle.textContent = 'Copy Banner (New)';
}

/* CLOSE */
function closeBannerModal(){
    bannerModal.classList.remove('show');
}

/* AJAX SUBMIT */
bannerForm.addEventListener('submit', async function(e){
    e.preventDefault();

    const formData = new FormData(bannerForm);

    const res  = await fetch('banners.php', { method:'POST', body:formData });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){
        alert(text);
        return;
    }

    if (!data.success){
        alert(data.message);
        return;
    }

    upsertBannerCard(data.banner);
    closeBannerModal();
});

/* DELETE */
async function deleteBanner(id){
    if (!confirm('Padam banner ini?')) return;

    const fd = new FormData();
    fd.append('action','delete_banner');
    fd.append('id',id);

    const res  = await fetch('banners.php', { method:'POST', body:fd });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){ alert(text); return; }

    if (!data.success){
        alert(data.message);
        return;
    }

    const el = document.getElementById("banner-"+id);
    if (el) el.remove();
}

/* INSERT / UPDATE CARD TANPA REFRESH */
function upsertBannerCard(b){
    const cardId = "banner-"+b.id;
    let el = document.getElementById(cardId);

    const html = `
        <div class="banner-img">
            <img src="${escapeHtml(b.image_url)}">
        </div>
        <div class="banner-title">${escapeHtml(b.title)}</div>
        <div class="banner-link">${escapeHtml(b.link_url || '-')}</div>
        <div class="banner-sort">Sort: ${b.sort_order}</div>
        ${b.is_active == 1 
            ? "<span class='badge-active'>Active</span>" 
            : "<span class='badge-inactive'>Inactive</span>"}
        <br>
        <button class="btn-sm" onclick='openBannerModal(${JSON.stringify(b)})'>Edit</button>
        <button class="btn-sm" onclick='copyBanner(${JSON.stringify(b)})'>Copy</button>
        <button class="btn-sm btn-danger" onclick='deleteBanner(${b.id})'>Delete</button>
    `;

    if (el){
        el.innerHTML = html;
    } else {
        el = document.createElement('div');
        el.className = 'banner-card';
        el.id = cardId;
        el.innerHTML = html;
        bannerList.prepend(el);
    }
}

/* Escape HTML */
function escapeHtml(s){
    return (s||'').replace(/[&<>"]/g, c => ({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'
    }[c]));
}
</script>

</body>
</html>