<?php
// public/admin/transactions.php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config/app.php';
require_once '../../config/db.php';

session_start();

// AUTH ADMIN
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit;
}

$STATUS_LIST = ['pending','processing','success','failed','cancelled'];

/* ============================================================
   HELPER: DAPATKAN 1 TRANSAKSI (JOIN USERS / PRODUCTS / GAMES / PAYMENT METHODS)
============================================================ */
function getTransactionById(mysqli $conn, int $id): ?array {
    $sql = "
        SELECT 
            t.*,
            u.name  AS user_name,
            u.email AS user_email,
            p.product_name,
            g.name  AS game_name,
            pm.name AS payment_name
        FROM transactions t
        LEFT JOIN users          u  ON t.user_id = u.id
        LEFT JOIN products       p  ON t.product_id = p.id
        LEFT JOIN games          g  ON t.game_id = g.id
        LEFT JOIN payment_methods pm ON t.payment_method_id = pm.id
        WHERE t.id = ?
        LIMIT 1
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc() ?: null;
    $stmt->close();
    return $row;
}

/* ============================================================
   AJAX: SAVE TRANSACTION (ADD / EDIT)
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_trx') {
    header('Content-Type: application/json');

    global $STATUS_LIST;

    $id                = (int)($_POST['id'] ?? 0);
    $user_id           = (int)($_POST['user_id'] ?? 0);
    $product_id        = (int)($_POST['product_id'] ?? 0);
    $game_id           = (int)($_POST['game_id'] ?? 0);
    $payment_method_id = (int)($_POST['payment_method_id'] ?? 0);
    $target_account    = trim($_POST['target_account'] ?? '');
    $qty               = (int)($_POST['qty'] ?? 1);
    $amount            = (float)($_POST['amount'] ?? 0);
    $public_price      = (float)($_POST['public_price'] ?? 0);
    $reseller_price    = (float)($_POST['reseller_price'] ?? 0);
    $status            = trim($_POST['status'] ?? 'pending');
    $external_ref      = trim($_POST['external_ref'] ?? '');
    $notes             = trim($_POST['notes'] ?? '');

    if ($user_id <= 0 || $product_id <= 0 || $game_id <= 0 || $payment_method_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'User, product, game & payment method wajib dipilih.'
        ]);
        exit;
    }

    if ($target_account === '') {
        echo json_encode([
            'success' => false,
            'message' => 'Target account (contoh: UID / No. HP) wajib diisi.'
        ]);
        exit;
    }

    if ($qty <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Qty mesti lebih besar dari 0.'
        ]);
        exit;
    }

    if (!in_array($status, $STATUS_LIST, true)) {
        $status = 'pending';
    }

    if ($id > 0) {
        // UPDATE
        $sql = "
            UPDATE transactions
            SET user_id=?, product_id=?, game_id=?, payment_method_id=?,
                target_account=?, qty=?, amount=?, public_price=?, reseller_price=?,
                status=?, external_ref=?, notes=?, updated_at=NOW()
            WHERE id=?
        ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "iiiisidddsssi",
            $user_id, $product_id, $game_id, $payment_method_id,
            $target_account, $qty, $amount, $public_price, $reseller_price,
            $status, $external_ref, $notes, $id
        );
        $stmt->execute();
        $stmt->close();
        $newId = $id;
    } else {
        // INSERT
        $sql = "
            INSERT INTO transactions
            (user_id, product_id, game_id, payment_method_id,
             target_account, qty, amount, public_price, reseller_price,
             status, external_ref, notes, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())
        ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "iiiisidddsss",
            $user_id, $product_id, $game_id, $payment_method_id,
            $target_account, $qty, $amount, $public_price, $reseller_price,
            $status, $external_ref, $notes
        );
        $stmt->execute();
        $newId = $stmt->insert_id;
        $stmt->close();
    }

    $trx = getTransactionById($conn, $newId);

    echo json_encode([
        'success' => true,
        'message' => 'Transaksi berjaya disimpan.',
        'trx'     => $trx
    ]);
    exit;
}

/* ============================================================
   AJAX: TUKAR STATUS TRANSAKSI SAHAJA
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_status') {
    header('Content-Type: application/json');

    global $STATUS_LIST;

    $id     = (int)($_POST['id'] ?? 0);
    $status = trim($_POST['status'] ?? '');

    if ($id <= 0 || !in_array($status, $STATUS_LIST, true)) {
        echo json_encode([
            'success' => false,
            'message' => 'ID transaksi atau status tidak sah.'
        ]);
        exit;
    }

    $stmt = $conn->prepare("UPDATE transactions SET status=?, updated_at=NOW() WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    $stmt->close();

    $trx = getTransactionById($conn, $id);

    echo json_encode([
        'success' => true,
        'message' => 'Status berjaya dikemaskini.',
        'trx'     => $trx
    ]);
    exit;
}

/* ============================================================
   AJAX: DELETE TRANSAKSI
============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_trx') {
    header('Content-Type: application/json');

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'ID transaksi tidak sah.'
        ]);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM transactions WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected < 1) {
        echo json_encode([
            'success' => false,
            'message' => 'Transaksi tidak dijumpai / gagal padam.'
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'Transaksi berjaya dipadam.'
    ]);
    exit;
}

/* ============================================================
   LOAD: USERS / GAMES / PRODUCTS / PAYMENT METHODS
============================================================ */
$users = [];
$res = $conn->query("SELECT id, name, email FROM users ORDER BY name ASC");
while ($row = $res->fetch_assoc()) {
    $users[] = $row;
}

$games = [];
$res = $conn->query("SELECT id, name FROM games ORDER BY name ASC");
while ($row = $res->fetch_assoc()) {
    $games[] = $row;
}

$products = [];
$res = $conn->query("SELECT id, product_name FROM products ORDER BY product_name ASC");
while ($row = $res->fetch_assoc()) {
    $products[] = $row;
}

$paymentMethods = [];
$res = $conn->query("SELECT id, name FROM payment_methods ORDER BY name ASC");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $paymentMethods[] = $row;
    }
}

/* ============================================================
   LOAD: TRANSACTIONS LIST
============================================================ */
$transactions = [];
$sql = "
    SELECT 
        t.*,
        u.name  AS user_name,
        u.email AS user_email,
        p.product_name,
        g.name  AS game_name,
        pm.name AS payment_name
    FROM transactions t
    LEFT JOIN users          u  ON t.user_id = u.id
    LEFT JOIN products       p  ON t.product_id = p.id
    LEFT JOIN games          g  ON t.game_id = g.id
    LEFT JOIN payment_methods pm ON t.payment_method_id = pm.id
    ORDER BY t.id DESC
    LIMIT 300
";
$res = $conn->query($sql);
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $transactions[] = $row;
    }
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Transactions - <?php echo APP_NAME; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
:root{
    --bg:#020617;
    --card:#0b1120;
    --border:#1e293b;
    --text:#ffffff;
    --muted:#94a3b8;
    --blue:#2563eb;
    --blue-soft:#1d4ed8;
}
*{box-sizing:border-box;}
body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:var(--bg);
    color:var(--text);
}
.admin-main{
    max-width:1150px;
    margin:0 auto;
    padding:16px;
}
@media(min-width:900px){
    .admin-main{ margin-left:240px; }
}
.page-head{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    flex-wrap:wrap;
    gap:10px;
    margin-bottom:14px;
}
.page-title{
    font-size:20px;
    font-weight:600;
}
.page-sub{
    font-size:13px;
    color:var(--muted);
}
.btn-primary{
    padding:8px 14px;
    border-radius:999px;
    border:none;
    background:linear-gradient(135deg,var(--blue),var(--blue-soft));
    color:#fff;
    font-size:13px;
    cursor:pointer;
    box-shadow:0 8px 22px rgba(37,99,235,0.8);
}

/* FILTER BAR */
.filter-bar{
    display:flex;
    flex-wrap:wrap;
    gap:8px;
    align-items:center;
    margin-bottom:12px;
}
.filter-input{
    flex:1;
    min-width:160px;
    border-radius:999px;
    padding:7px 12px;
    border:1px solid var(--border);
    background:#020617;
    color:var(--text);
    font-size:13px;
    outline:none;
}
.filter-select{
    min-width:140px;
    border-radius:999px;
    padding:7px 12px;
    border:1px solid var(--border);
    background:#020617;
    color:var(--text);
    font-size:13px;
    outline:none;
}

/* TABLE */
.trx-table-wrap{
    background:var(--card);
    border-radius:16px;
    border:1px solid var(--border);
    padding:10px;
    overflow-x:auto;
}
table{
    width:100%;
    border-collapse:collapse;
    min-width:950px;
    font-size:12px;
}
th, td{
    padding:8px 6px;
    border-bottom:1px solid var(--border);
    text-align:left;
}
th{
    text-transform:uppercase;
    font-size:11px;
    color:var(--muted);
    font-weight:500;
}

.trx-main{
    display:flex;
    flex-direction:column;
    gap:2px;
}
.trx-user{
    font-size:13px;
    font-weight:600;
}
.trx-email{
    font-size:11px;
    color:var(--muted);
}
.trx-product{
    font-size:13px;
    font-weight:600;
}
.trx-game{
    font-size:11px;
    color:var(--muted);
}
.trx-target{
    font-size:11px;
    word-break:break-all;
}
.amount-main{
    font-size:13px;
    font-weight:600;
}
.amount-sub{
    font-size:11px;
    color:var(--muted);
}
.badge-status{
    padding:2px 8px;
    border-radius:999px;
    font-size:10px;
    display:inline-block;
}
.badge-pending{
    background:rgba(234,179,8,.18);
    color:#fde68a;
}
.badge-processing{
    background:rgba(59,130,246,.2);
    color:#bfdbfe;
}
.badge-success{
    background:rgba(16,185,129,.2);
    color:#4ade80;
}
.badge-failed{
    background:rgba(239,68,68,.2);
    color:#fecaca;
}
.badge-cancelled{
    background:rgba(148,163,184,.26);
    color:#e5e7eb;
}
.external-ref{
    font-size:11px;
    color:var(--muted);
    word-break:break-all;
}
.notes-text{
    font-size:11px;
    color:var(--muted);
    max-width:220px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}
.btn-sm{
    padding:5px 8px;
    border-radius:999px;
    border:1px solid var(--border);
    background:#0f172a;
    color:#e5e7eb;
    font-size:11px;
    cursor:pointer;
    margin-right:4px;
    margin-bottom:4px;
}
.btn-danger{
    border-color:#b91c1c;
    color:#fecaca;
}

/* MODALS */
.modal-backdrop{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.7);
    display:none;
    align-items:center;
    justify-content:center;
    z-index:120;
}
.modal-backdrop.show{
    display:flex;
}
.modal{
    width:100%;
    max-width:520px;
    background:#020617;
    border-radius:18px;
    border:1px solid var(--border);
    padding:16px 16px 18px;
    box-shadow:0 25px 60px rgba(0,0,0,.95);
}
.modal-title{
    margin:0 0 10px;
    font-size:16px;
    font-weight:500;
}
.form-group{
    margin-bottom:10px;
}
.form-label{
    display:block;
    font-size:12px;
    margin-bottom:4px;
}
.form-input, .form-select, .form-textarea{
    width:100%;
    border-radius:10px;
    border:1px solid #1f2937;
    background:#0f172a;
    color:#e5e7eb;
    font-size:13px;
    padding:7px 9px;
    outline:none;
}
.form-textarea{
    min-height:70px;
    resize:vertical;
}
.form-check{
    display:flex;
    align-items:center;
    gap:6px;
    font-size:12px;
}
.modal-footer{
    display:flex;
    justify-content:flex-end;
    gap:8px;
    margin-top:12px;
}
</style>
</head>
<body>

<?php include './include/sidebar.php'; ?>
<?php include './include/header.php'; ?>

<div class="admin-main">

    <div class="page-head">
        <div>
            <div class="page-title">Transactions</div>
            <div class="page-sub">Urus semua transaksi: status, amount, user, product, dll.</div>
        </div>
        <button class="btn-primary" onclick="openTrxModal()">+ Tambah Transaksi</button>
    </div>

    <!-- FILTER -->
    <div class="filter-bar">
        <input type="text" id="searchInput" class="filter-input"
               placeholder="Cari ID, user, product, game, target, external ref...">
        <select id="statusFilter" class="filter-select">
            <option value="">Semua Status</option>
            <?php foreach ($STATUS_LIST as $st): ?>
                <option value="<?php echo htmlspecialchars($st); ?>">
                    <?php echo ucfirst($st); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- TABLE -->
    <div class="trx-table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Product / Game</th>
                    <th>Target / Payment</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>External / Notes</th>
                    <th>Tarikh</th>
                    <th width="210">Actions</th>
                </tr>
            </thead>
            <tbody id="trxTbody">
                <?php foreach ($transactions as $t): ?>
                    <?php
                        $searchText = strtolower(
                            $t['id'].' '.
                            ($t['user_name'] ?? '').' '.
                            ($t['user_email'] ?? '').' '.
                            ($t['product_name'] ?? '').' '.
                            ($t['game_name'] ?? '').' '.
                            ($t['target_account'] ?? '').' '.
                            ($t['external_ref'] ?? '').' '.
                            ($t['status'] ?? '')
                        );

                        $amountFmt   = 'RM '.number_format((float)$t['amount'], 2, '.', ',');
                        $pubFmt      = 'RM '.number_format((float)$t['public_price'], 2, '.', ',');
                        $resellerFmt = 'RM '.number_format((float)$t['reseller_price'], 2, '.', ',');

                        $statusClass = 'badge-pending';
                        switch ($t['status']) {
                            case 'processing': $statusClass = 'badge-processing'; break;
                            case 'success':    $statusClass = 'badge-success';    break;
                            case 'failed':     $statusClass = 'badge-failed';     break;
                            case 'cancelled':  $statusClass = 'badge-cancelled';  break;
                        }

                        $createdAt = !empty($t['created_at'])
                            ? date('d/m/Y H:i', strtotime($t['created_at']))
                            : '-';
                        $updatedAt = !empty($t['updated_at'])
                            ? date('d/m/Y H:i', strtotime($t['updated_at']))
                            : '-';
                    ?>
                    <tr id="trx-row-<?php echo $t['id']; ?>"
                        data-status="<?php echo htmlspecialchars($t['status']); ?>"
                        data-search="<?php echo htmlspecialchars($searchText, ENT_QUOTES); ?>">
                        <td>#<?php echo (int)$t['id']; ?></td>
                        <td>
                            <div class="trx-main">
                                <div class="trx-user"><?php echo htmlspecialchars($t['user_name'] ?? '-'); ?></div>
                                <div class="trx-email"><?php echo htmlspecialchars($t['user_email'] ?? '-'); ?></div>
                            </div>
                        </td>
                        <td>
                            <div class="trx-main">
                                <div class="trx-product"><?php echo htmlspecialchars($t['product_name'] ?? '-'); ?></div>
                                <div class="trx-game"><?php echo htmlspecialchars($t['game_name'] ?? '-'); ?></div>
                            </div>
                        </td>
                        <td>
                            <div class="trx-target">
                                <?php echo htmlspecialchars($t['target_account'] ?? '-'); ?>
                            </div>
                            <div class="amount-sub">
                                Payment: <?php echo htmlspecialchars($t['payment_name'] ?? '-'); ?>
                            </div>
                        </td>
                        <td>
                            <div class="amount-main"><?php echo $amountFmt; ?></div>
                            <div class="amount-sub">
                                Qty: <?php echo (int)$t['qty']; ?>
                                · Pub: <?php echo $pubFmt; ?>
                                · Res: <?php echo $resellerFmt; ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge-status <?php echo $statusClass; ?>">
                                <?php echo ucfirst($t['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($t['external_ref'])): ?>
                                <div class="external-ref">
                                    Ref: <?php echo htmlspecialchars($t['external_ref']); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($t['notes'])): ?>
                                <div class="notes-text">
                                    Notes: <?php echo htmlspecialchars($t['notes']); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="amount-sub">Created: <?php echo $createdAt; ?></div>
                            <div class="amount-sub">Updated: <?php echo $updatedAt; ?></div>
                        </td>
                        <td>
                            <button class="btn-sm"
                                onclick='openTrxModal(<?php echo json_encode($t, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>)'>
                                Edit
                            </button>
                            <button class="btn-sm"
                                onclick='quickStatus(<?php echo (int)$t["id"]; ?>, "<?php echo htmlspecialchars($t["status"], ENT_QUOTES); ?>")'>
                                Status
                            </button>
                            <button class="btn-sm btn-danger"
                                onclick="deleteTrx(<?php echo (int)$t['id']; ?>)">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- MODAL ADD/EDIT TRANSACTION -->
<div class="modal-backdrop" id="trxModal">
    <div class="modal">
        <h3 class="modal-title" id="trxModalTitle">Tambah Transaksi</h3>

        <form id="trxForm">
            <input type="hidden" name="action" value="save_trx">
            <input type="hidden" name="id" id="trxId">

            <div class="form-group">
                <label class="form-label">User</label>
                <select class="form-select" name="user_id" id="trxUser" required>
                    <option value="">-- Pilih User --</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?php echo (int)$u['id']; ?>">
                            <?php echo htmlspecialchars($u['name'] ?: $u['email']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Game</label>
                <select class="form-select" name="game_id" id="trxGame" required>
                    <option value="">-- Pilih Game --</option>
                    <?php foreach ($games as $g): ?>
                        <option value="<?php echo (int)$g['id']; ?>">
                            <?php echo htmlspecialchars($g['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Product</label>
                <select class="form-select" name="product_id" id="trxProduct" required>
                    <option value="">-- Pilih Produk --</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?php echo (int)$p['id']; ?>">
                            <?php echo htmlspecialchars($p['product_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Payment Method</label>
                <select class="form-select" name="payment_method_id" id="trxPayment" required>
                    <option value="">-- Pilih Payment Method --</option>
                    <?php foreach ($paymentMethods as $pm): ?>
                        <option value="<?php echo (int)$pm['id']; ?>">
                            <?php echo htmlspecialchars($pm['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Target Account (UID / No. HP / etc)</label>
                <input type="text" class="form-input" name="target_account" id="trxTarget" required>
            </div>

            <div class="form-group">
                <label class="form-label">Qty</label>
                <input type="number" min="1" class="form-input" name="qty" id="trxQty" value="1" required>
            </div>

            <div class="form-group">
                <label class="form-label">Amount Total (RM)</label>
                <input type="number" step="0.01" min="0" class="form-input" name="amount" id="trxAmount" required>
            </div>

            <div class="form-group">
                <label class="form-label">Public Price (RM)</label>
                <input type="number" step="0.01" min="0" class="form-input" name="public_price" id="trxPublicPrice">
            </div>

            <div class="form-group">
                <label class="form-label">Reseller Price (RM)</label>
                <input type="number" step="0.01" min="0" class="form-input" name="reseller_price" id="trxResellerPrice">
            </div>

            <div class="form-group">
                <label class="form-label">Status</label>
                <select class="form-select" name="status" id="trxStatus">
                    <?php foreach ($STATUS_LIST as $st): ?>
                        <option value="<?php echo htmlspecialchars($st); ?>">
                            <?php echo ucfirst($st); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">External Ref (Payment / API Ref)</label>
                <input type="text" class="form-input" name="external_ref" id="trxExternalRef">
            </div>

            <div class="form-group">
                <label class="form-label">Notes</label>
                <textarea class="form-textarea" name="notes" id="trxNotes"></textarea>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn-sm" onclick="closeTrxModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL QUICK STATUS -->
<div class="modal-backdrop" id="statusModal">
    <div class="modal">
        <h3 class="modal-title">Tukar Status</h3>
        <form id="statusForm">
            <input type="hidden" name="action" value="change_status">
            <input type="hidden" name="id" id="statusTrxId">

            <div class="form-group">
                <label class="form-label">Status</label>
                <select class="form-select" name="status" id="statusSelect">
                    <?php foreach ($STATUS_LIST as $st): ?>
                        <option value="<?php echo htmlspecialchars($st); ?>">
                            <?php echo ucfirst($st); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn-sm" onclick="closeStatusModal()">Batal</button>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<script>
// ========== FILTER ==========
const searchInput  = document.getElementById('searchInput');
const statusFilter = document.getElementById('statusFilter');
const trxTbody     = document.getElementById('trxTbody');

searchInput.addEventListener('input', applyFilters);
statusFilter.addEventListener('change', applyFilters);

function applyFilters(){
    const text = searchInput.value.trim().toLowerCase();
    const st   = statusFilter.value;

    const rows = trxTbody.querySelectorAll('tr');
    rows.forEach(row => {
        const rowText = (row.getAttribute('data-search') || '').toLowerCase();
        const rowSt   = row.getAttribute('data-status') || '';

        let show = true;

        if (text && rowText.indexOf(text) === -1) {
            show = false;
        }
        if (st && rowSt !== st) {
            show = false;
        }

        row.style.display = show ? '' : 'none';
    });
}

// ========== MAIN MODAL ==========
const trxModal      = document.getElementById('trxModal');
const trxForm       = document.getElementById('trxForm');
const trxModalTitle = document.getElementById('trxModalTitle');

const fId        = document.getElementById('trxId');
const fUser      = document.getElementById('trxUser');
const fGame      = document.getElementById('trxGame');
const fProduct   = document.getElementById('trxProduct');
const fPayment   = document.getElementById('trxPayment');
const fTarget    = document.getElementById('trxTarget');
const fQty       = document.getElementById('trxQty');
const fAmount    = document.getElementById('trxAmount');
const fPubPrice  = document.getElementById('trxPublicPrice');
const fResPrice  = document.getElementById('trxResellerPrice');
const fStatus    = document.getElementById('trxStatus');
const fExtRef    = document.getElementById('trxExternalRef');
const fNotes     = document.getElementById('trxNotes');

function openTrxModal(trx){
    if (trx) {
        trxModalTitle.textContent = 'Edit Transaksi';
        fId.value       = trx.id;
        fUser.value     = trx.user_id;
        fGame.value     = trx.game_id;
        fProduct.value  = trx.product_id;
        fPayment.value  = trx.payment_method_id;
        fTarget.value   = trx.target_account || '';
        fQty.value      = trx.qty || 1;
        fAmount.value   = trx.amount || '';
        fPubPrice.value = trx.public_price || '';
        fResPrice.value = trx.reseller_price || '';
        fStatus.value   = trx.status || 'pending';
        fExtRef.value   = trx.external_ref || '';
        fNotes.value    = trx.notes || '';
    } else {
        trxModalTitle.textContent = 'Tambah Transaksi';
        fId.value       = '';
        fUser.value     = '';
        fGame.value     = '';
        fProduct.value  = '';
        fPayment.value  = '';
        fTarget.value   = '';
        fQty.value      = 1;
        fAmount.value   = '';
        fPubPrice.value = '';
        fResPrice.value = '';
        fStatus.value   = 'pending';
        fExtRef.value   = '';
        fNotes.value    = '';
    }
    trxModal.classList.add('show');
}

function closeTrxModal(){
    trxModal.classList.remove('show');
}

trxForm.addEventListener('submit', async function(e){
    e.preventDefault();
    const fd = new FormData(trxForm);

    const res  = await fetch('transactions.php', { method:'POST', body:fd });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){
        console.error('RESPON SERVER (save_trx):', text);
        alert(text);
        return;
    }

    if (!data.success){
        alert(data.message || 'Gagal simpan transaksi.');
        return;
    }

    upsertTrxRow(data.trx);
    closeTrxModal();
});

// ========== QUICK STATUS MODAL ==========
const statusModal   = document.getElementById('statusModal');
const statusForm    = document.getElementById('statusForm');
const statusTrxId   = document.getElementById('statusTrxId');
const statusSelect  = document.getElementById('statusSelect');

function quickStatus(id, currentStatus){
    statusTrxId.value = id;
    statusSelect.value = currentStatus || 'pending';
    statusModal.classList.add('show');
}
function closeStatusModal(){
    statusModal.classList.remove('show');
}
statusForm.addEventListener('submit', async function(e){
    e.preventDefault();
    const fd = new FormData(statusForm);

    const res  = await fetch('transactions.php', { method:'POST', body:fd });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){
        console.error('RESPON SERVER (change_status):', text);
        alert(text);
        return;
    }

    if (!data.success){
        alert(data.message || 'Gagal tukar status.');
        return;
    }

    upsertTrxRow(data.trx);
    closeStatusModal();
});

// ========== DELETE ==========
async function deleteTrx(id){
    if (!confirm('Padam transaksi ini?')) return;

    const fd = new FormData();
    fd.append('action','delete_trx');
    fd.append('id', id);

    const res  = await fetch('transactions.php', { method:'POST', body:fd });
    const text = await res.text();

    let data;
    try { data = JSON.parse(text); }
    catch(e){
        console.error('RESPON SERVER (delete_trx):', text);
        alert(text);
        return;
    }

    if (!data.success){
        alert(data.message || 'Gagal padam transaksi.');
        return;
    }

    const row = document.getElementById('trx-row-'+id);
    if (row) row.remove();
}

// ========== UPSERT ROW ==========
function upsertTrxRow(t){
    const rowId = 'trx-row-'+t.id;
    let row = document.getElementById(rowId);

    const amount = parseFloat(t.amount || 0);
    const pub    = parseFloat(t.public_price || 0);
    const res    = parseFloat(t.reseller_price || 0);

    const amountFmt   = 'RM ' + amount.toFixed(2);
    const pubFmt      = 'RM ' + pub.toFixed(2);
    const resellerFmt = 'RM ' + res.toFixed(2);

    let statusClass = 'badge-pending';
    switch (t.status) {
        case 'processing': statusClass = 'badge-processing'; break;
        case 'success':    statusClass = 'badge-success';    break;
        case 'failed':     statusClass = 'badge-failed';     break;
        case 'cancelled':  statusClass = 'badge-cancelled';  break;
    }

    let createdAt = '-';
    let updatedAt = '-';
    if (t.created_at) {
        createdAt = formatDateTime(t.created_at);
    }
    if (t.updated_at) {
        updatedAt = formatDateTime(t.updated_at);
    }

    const searchText = (
        (t.id || '') + ' ' +
        (t.user_name || '') + ' ' +
        (t.user_email || '') + ' ' +
        (t.product_name || '') + ' ' +
        (t.game_name || '') + ' ' +
        (t.target_account || '') + ' ' +
        (t.external_ref || '') + ' ' +
        (t.status || '')
    ).toLowerCase();

    const html = `
        <td>#${t.id}</td>
        <td>
            <div class="trx-main">
                <div class="trx-user">${escapeHtml(t.user_name || '-')}</div>
                <div class="trx-email">${escapeHtml(t.user_email || '-')}</div>
            </div>
        </td>
        <td>
            <div class="trx-main">
                <div class="trx-product">${escapeHtml(t.product_name || '-')}</div>
                <div class="trx-game">${escapeHtml(t.game_name || '-')}</div>
            </div>
        </td>
        <td>
            <div class="trx-target">${escapeHtml(t.target_account || '-')}</div>
            <div class="amount-sub">Payment: ${escapeHtml(t.payment_name || '-')}</div>
        </td>
        <td>
            <div class="amount-main">${amountFmt}</div>
            <div class="amount-sub">
                Qty: ${parseInt(t.qty || 0)}
                · Pub: ${pubFmt}
                · Res: ${resellerFmt}
            </div>
        </td>
        <td>
            <span class="badge-status ${statusClass}">
                ${escapeHtml(capital(t.status || 'pending'))}
            </span>
        </td>
        <td>
            ${t.external_ref ? `<div class="external-ref">Ref: ${escapeHtml(t.external_ref)}</div>` : ''}
            ${t.notes ? `<div class="notes-text">Notes: ${escapeHtml(t.notes)}</div>` : ''}
        </td>
        <td>
            <div class="amount-sub">Created: ${createdAt}</div>
            <div class="amount-sub">Updated: ${updatedAt}</div>
        </td>
        <td>
            <button class="btn-sm" onclick='openTrxModal(${JSON.stringify(t)})'>Edit</button>
            <button class="btn-sm" onclick='quickStatus(${t.id}, "${escapeHtml(t.status || 'pending')}")'>Status</button>
            <button class="btn-sm btn-danger" onclick="deleteTrx(${t.id})">Delete</button>
        </td>
    `;

    if (row) {
        row.innerHTML = html;
        row.setAttribute('data-status', t.status || '');
        row.setAttribute('data-search', searchText.replace(/"/g,'&quot;'));
    } else {
        row = document.createElement('tr');
        row.id = rowId;
        row.setAttribute('data-status', t.status || '');
        row.setAttribute('data-search', searchText.replace(/"/g,'&quot;'));
        row.innerHTML = html;
        trxTbody.prepend(row);
    }

    applyFilters();
}

function escapeHtml(str){
    return (str || '').replace(/[&<>"']/g, function(m){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m] || m;
    });
}
function formatDateTime(s){
    const d = new Date(s);
    if (isNaN(d.getTime())) return s;
    const dd = ('0'+d.getDate()).slice(-2);
    const mm = ('0'+(d.getMonth()+1)).slice(-2);
    const yy = d.getFullYear();
    const hh = ('0'+d.getHours()).slice(-2);
    const mi = ('0'+d.getMinutes()).slice(-2);
    return `${dd}/${mm}/${yy} ${hh}:${mi}`;
}
function capital(s){
    s = s||'';
    return s.charAt(0).toUpperCase()+s.slice(1);
}
</script>

</body>
</html>