<?php
// include/sidebar.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/db.php';

// Guna APP_URL sebagai base root app
$baseUrl = rtrim(defined('APP_URL') ? APP_URL : (defined('BASE_URL') ? BASE_URL : '/'), '/') . '/';

/* ============================
   LOAD SITE SETTINGS (LOGO + THEME COLOR)
============================ */
$settings = [
    'logo_url'     => null,
    'theme_color'  => '#3b82f6', // default
];

$res = $conn->query("SELECT * FROM site_settings WHERE is_active = 1 ORDER BY id ASC LIMIT 1");
if ($res && $res->num_rows > 0) {
    $settings = array_merge($settings, $res->fetch_assoc());
}

$logo = !empty($settings['logo_url'])
    ? $settings['logo_url']
    : ($baseUrl . 'assets/img/logo.png');

// Theme color validate (#RRGGBB sahaja)
$themeColor = '#3b82f6';
if (!empty($settings['theme_color']) && preg_match('/^#([A-Fa-f0-9]{6})$/', $settings['theme_color'])) {
    $themeColor = $settings['theme_color'];
}
?>
<style>
:root{
    --theme-color: <?= htmlspecialchars($themeColor, ENT_QUOTES) ?>;
}

/* BACKDROP (fade in/out) */
.sidebar-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.25s ease-out;
    z-index: 190;
}

/* SIDEBAR (FROM LEFT) */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 78%;
    max-width: 340px;
    height: 100vh;
    background: #05070b;
    color: #ffffff;
    z-index: 200;
    padding: 16px 18px 24px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;

    transform: translateX(-100%);
    transition: transform 0.25s ease-out;
    box-shadow: 4px 0 20px rgba(0,0,0,0.9);
}

/* ACTIVE STATE */
.sidebar-open .sidebar {
    transform: translateX(0);
}

.sidebar-open .sidebar-backdrop {
    opacity: 1;
    pointer-events: auto;
}

/* HEADER ATAS */
.sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-bottom: 12px;
    border-bottom: 1px dashed rgba(255,255,255,0.2);
    margin-bottom: 14px;
}

.sidebar-header img.logo {
    height: 32px;
}

/* CLOSE BTN */
.sidebar-close-btn {
    width: 38px;
    height: 38px;
    border-radius: 999px;
    border: 2px solid var(--theme-color); /* ✅ ikut DB */
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    background: transparent;
    transition: transform .15s ease-out, opacity .15s ease-out;
}
.sidebar-close-btn:hover{
    transform: scale(1.03);
    opacity: .95;
}

.sidebar-close-btn span {
    font-size: 22px;
    line-height: 1;
}

/* HELLO NAME */
.sidebar-hello {
    padding: 4px 0 10px 0;
    font-size: 14px;
    opacity: 0.85;
}

/* NAV LIST */
.sidebar-nav {
    list-style: none;
    padding: 0;
    margin: 8px 0 0 0;
}

.sidebar-nav li {
    margin: 8px 0;
}

.sidebar-link,
.sidebar-toggle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-decoration: none;
    color: #ffffff;
    padding: 9px 2px;
    font-size: 15px;
    width: 100%;
    background: transparent;
    border: none;
    cursor: pointer;
}

.sidebar-link span.text,
.sidebar-toggle span.text {
    letter-spacing: 0.3px;
}

/* ICON SVG */
.sidebar-link svg,
.sidebar-toggle svg {
    width: 22px;
    height: 22px;
    stroke: currentColor;
    fill: none;
    opacity: 0.9;
}

/* hover */
.sidebar-link:hover,
.sidebar-toggle:hover {
    color: #ffffff;
    opacity: 0.92;
}

/* SUB MENU */
.has-sub { margin-top: 6px; }

.sidebar-subnav {
    display: none;
    padding-left: 14px;
    margin-top: 4px;
    border-left: 1px solid rgba(255,255,255,0.08);
}

.sidebar-subnav.open { display: block; }

.sidebar-subnav li { margin: 4px 0; }

.sidebar-sub-link {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 2px;
    font-size: 14px;
    text-decoration: none;
    color: #e5e7eb;
}

.sidebar-sub-link:hover {
    color: var(--theme-color); /* ✅ ikut DB */
}

/* Arrow for dropdown */
.sidebar-toggle .arrow {
    font-size: 14px;
    margin-left: 8px;
    opacity: 0.8;
}

/* Optional: Desktop tweak */
@media (min-width: 992px){
    .sidebar { max-width: 320px; }
}
</style>

<!-- BACKDROP -->
<div id="sidebar-backdrop" class="sidebar-backdrop" onclick="closeSidebar()"></div>

<!-- SIDEBAR -->
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <img src="<?php echo htmlspecialchars($logo); ?>" alt="Logo" class="logo">

        <button type="button" class="sidebar-close-btn" onclick="closeSidebar()">
            <span>&times;</span>
        </button>
    </div>

    <?php if (isset($_SESSION['username'])): ?>
        <div class="sidebar-hello">
            Hi, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
        </div>
    <?php endif; ?>

    <ul class="sidebar-nav">
        <li>
            <a href="<?php echo $baseUrl; ?>index.php" class="sidebar-link">
                <span class="text">Topup</span>
                <svg viewBox="0 0 24 24" stroke-width="1.7">
                    <rect x="7" y="3" width="10" height="18" rx="2" ry="2"></rect>
                    <line x1="11" y1="7" x2="13" y2="7"></line>
                    <circle cx="12" cy="17" r="1"></circle>
                    <line x1="18" y1="9" x2="21" y2="9"></line>
                    <line x1="19.5" y1="7.5" x2="19.5" y2="10.5"></line>
                </svg>
            </a>
        </li>

        <li>
            <a href="<?php echo $baseUrl; ?>cek-transaksi.php" class="sidebar-link">
                <span class="text">Cek Transaksi</span>
                <svg viewBox="0 0 24 24" stroke-width="1.7">
                    <rect x="5" y="3" width="14" height="18" rx="2"></rect>
                    <line x1="9" y1="9" x2="15" y2="9"></line>
                    <line x1="9" y1="13" x2="15" y2="13"></line>
                    <line x1="9" y1="17" x2="13" y2="17"></line>
                </svg>
            </a>
        </li>

        <li>
            <a href="<?php echo $baseUrl; ?>leaderboard.php" class="sidebar-link">
                <span class="text">Leaderboard</span>
                <svg viewBox="0 0 24 24" stroke-width="1.7">
                    <path d="M8 4h8v3a4 4 0 0 1-8 0V4z"></path>
                    <path d="M9 21h6"></path>
                    <path d="M10.5 17h3"></path>
                    <path d="M6 5H4v2a3 3 0 0 0 3 3"></path>
                    <path d="M18 5h2v2a3 3 0 0 1-3 3"></path>
                </svg>
            </a>
        </li>

        <li>
            <a href="<?php echo $baseUrl; ?>check-region.php" class="sidebar-link">
                <span class="text">Check Region</span>
                <svg viewBox="0 0 24 24" stroke-width="1.7">
                    <circle cx="12" cy="12" r="7"></circle>
                    <path d="M12 5v14"></path>
                    <path d="M5 12h14"></path>
                </svg>
            </a>
        </li>

        <li class="has-sub">
            <button type="button" class="sidebar-toggle" onclick="toggleSubmenu('calc-menu', this)">
                <span class="text">Kalkutor</span>
                <span class="arrow">▾</span>
                <svg viewBox="0 0 24 24" stroke-width="1.7">
                    <rect x="6" y="3" width="12" height="18" rx="2"></rect>
                    <rect x="9" y="7" width="6" height="3" rx="1"></rect>
                    <circle cx="9" cy="13" r="1"></circle>
                    <circle cx="12" cy="13" r="1"></circle>
                    <circle cx="15" cy="13" r="1"></circle>
                    <circle cx="9" cy="17" r="1"></circle>
                    <circle cx="12" cy="17" r="1"></circle>
                    <circle cx="15" cy="17" r="1"></circle>
                </svg>
            </button>
            <ul id="calc-menu" class="sidebar-subnav">
                <li><a href="<?php echo $baseUrl; ?>kalkulator-magic-wheel.php" class="sidebar-sub-link"><span class="text">Kalkutor Magic Wheel</span></a></li>
                <li><a href="<?php echo $baseUrl; ?>kalkulator-winrate.php" class="sidebar-sub-link"><span class="text">Kalkutor Win rate</span></a></li>
                <li><a href="<?php echo $baseUrl; ?>kalkulator-zodiac.php" class="sidebar-sub-link"><span class="text">Kalkutor Zodiac</span></a></li>
            </ul>
        </li>

        <?php if (!isset($_SESSION['user_id'])): ?>
            <li>
                <a href="<?php echo $baseUrl; ?>login.php" class="sidebar-link">
                    <span class="text">Masuk</span>
                    <svg viewBox="0 0 24 24" stroke-width="1.7">
                        <path d="M14 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                        <polyline points="10 17 14 12 10 7"></polyline>
                        <line x1="4" y1="12" x2="14" y2="12"></line>
                    </svg>
                </a>
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo $baseUrl; ?>dashboard.php" class="sidebar-link">
                    <span class="text">Dashboard Account</span>
                    <svg viewBox="0 0 24 24" stroke-width="1.7">
                        <circle cx="12" cy="8" r="3.2"></circle>
                        <path d="M6 19c0-3 2.7-5 6-5s6 2 6 5"></path>
                    </svg>
                </a>
            </li>
            <li>
                <a href="<?php echo $baseUrl; ?>logout.php" class="sidebar-link">
                    <span class="text">Logout</span>
                    <svg viewBox="0 0 24 24" stroke-width="1.7">
                        <path d="M10 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h4"></path>
                        <polyline points="14 17 18 12 14 7"></polyline>
                        <line x1="8" y1="12" x2="18" y2="12"></line>
                    </svg>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</div>

<script>
function openSidebar() {
    document.body.classList.add('sidebar-open');
}
function closeSidebar() {
    document.body.classList.remove('sidebar-open');
}
function toggleSubmenu(id, btn) {
    const menu = document.getElementById(id);
    if (!menu) return;

    const isOpen = menu.classList.contains('open');
    menu.classList.toggle('open', !isOpen);

    if (btn) {
        const arrow = btn.querySelector('.arrow');
        if (arrow) arrow.textContent = isOpen ? '▾' : '▴';
    }
}
</script>