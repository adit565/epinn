<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/db.php';

$settings = $conn->query("SELECT * FROM site_settings LIMIT 1")->fetch_assoc();

/* =============================
   THEME COLOR (1 warna dari DB)
============================= */
$themeColor = '#3b82f6'; // default
if (!empty($settings['theme_color']) && preg_match('/^#([A-Fa-f0-9]{6})$/', $settings['theme_color'])) {
    $themeColor = $settings['theme_color'];
}

/* =============================
   FOOTER DATA
============================= */
$footer_text = $settings['footer_text'] ?? 'MINZZ SHOP offers the best gaming top-up experience in Malaysia. Enjoy competitive prices, Safe & Legal Reload Service. Our website operates 24/7 for your convenience.';
$instagram   = $settings['instagram'] ?? '#';
$facebook    = $settings['facebook'] ?? '#';
$telegram    = $settings['telegram'] ?? '#';
$whatsapp    = $settings['whatsapp'] ?? '#';
$logoUrl     = $settings['logo_url'] ?? 'https://files.catbox.moe/gt2o1r.png';
?>

<style>
:root{
    --theme-color: <?= htmlspecialchars($themeColor, ENT_QUOTES) ?>;
}

/* ===== FOOTER WAVE ===== */
.footer-wave{
    background:#020617;
}
.footer-wave svg{
    width:100%;
    height:55px;
    display:block;
}

/* ===== FOOTER MAIN ===== */
.footer{
    background:#0a1122;
    padding:55px 22px 45px;
    color:#e2e8f0;
    font-family:'Poppins', sans-serif;
    margin-top:20px;
}

.footer .logo{
    width:120px;
    margin-bottom:18px;
}

.footer .footer-desc{
    max-width:480px;
    font-size:14px;
    line-height:1.7;
    margin-bottom:20px;
}

/* ===== SOCIAL ICONS ===== */
.footer .social-icons{
    display:flex;
    gap:16px;
    margin:14px 0 28px;
}
.footer .social-icons a svg{
    width:30px;
    height:30px;
    fill:#ffffff;
    transition:.2s;
}
.footer .social-icons a:hover svg{
    fill:var(--theme-color);
}

/* ===== LINKS SECTION ===== */
.footer h3{
    color:var(--theme-color);
    font-size:15px;
    margin-bottom:12px;
}

.footer .links-row{
    display:flex;
    justify-content:space-between;
    gap:60px;
    margin-top:30px;
}

.footer ul{
    list-style:none;
    padding:0;
    margin:0;
}

.footer ul li{
    margin-bottom:10px;
}

.footer ul li a{
    color:#e2e8f0;
    font-size:13px;
    text-decoration:none;
}

.footer ul li a:hover{
    color:var(--theme-color);
}

/* ===== BOTTOM ===== */
.footer-bottom{
    text-align:center;
    margin-top:45px;
    padding-top:18px;
    font-size:13px;
    border-top:1px solid rgba(255,255,255,0.1);
    color:#94a3b8;
}

/* RESPONSIVE */
@media(max-width:600px){
    .footer .links-row{
        flex-direction:column;
        gap:28px;
    }
}
</style>

<!-- ░▒▓ WAVE ▓▒░ -->
<div class="footer-wave">
    <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
        <path fill="#0a1122" d="
            M0,60
            C160,90 260,110 420,100
            C620,85 720,40 900,50
            C1100,65 1260,95 1440,80
            L1440,120 L0,120 Z">
        </path>
    </svg>
</div>

<!-- ░▒▓ FOOTER MAIN ▓▒░ -->
<footer class="footer">

    <img src="<?= htmlspecialchars($logoUrl) ?>" class="logo" alt="Logo">

    <div class="footer-desc">
        <?= nl2br(htmlspecialchars($footer_text)) ?>
    </div>

    <div class="social-icons">
        <a href="<?= htmlspecialchars($instagram) ?>" target="_blank"><svg viewBox="0 0 24 24"><path d="M7 2C4.2 2 2 4.2 2 7v10c0 2.8 2.2 5 5 5h10c2.8 0 5-2.2 5-5V7c0-2.8-2.2-5-5-5H7z"/></svg></a>
        <a href="<?= htmlspecialchars($facebook) ?>" target="_blank"><svg viewBox="0 0 24 24"><path d="M22 12a10 10 0 10-11.5 9.9v-7h-2v-3h2v-2.3c0-2 1.2-3.1 3-3.1"/></svg></a>
        <a href="<?= htmlspecialchars($telegram) ?>" target="_blank"><svg viewBox="0 0 24 24"><path d="M9.964 16.54l-.176 3.115"/></svg></a>
        <a href="<?= htmlspecialchars($whatsapp) ?>" target="_blank"><svg viewBox="0 0 24 24"><path d="M20 3.5A10.5 10.5 0 003.4 18.1"/></svg></a>
    </div>

    <div class="links-row">
        <div>
            <h3>Partnership</h3>
            <ul>
                <li><a href="#">Reseller</a></li>
                <li><a href="#">Web Creation</a></li>
                <li><a href="#">Affiliate</a></li>
                <li><a href="#">Career</a></li>
            </ul>
        </div>

        <div>
            <h3>Site Map</h3>
            <ul>
                <li><a href="<?= BASE_URL ?>contact.php">Contact Us</a></li>
                <li><a href="<?= BASE_URL ?>reviews.php">Reviews</a></li>
                <li><a href="<?= BASE_URL ?>terms.php">Terms & Conditions</a></li>
                <li><a href="<?= BASE_URL ?>privacy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <?= htmlspecialchars($_SERVER['SERVER_NAME']) ?>
    </div>

</footer>