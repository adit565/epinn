<?php
// include/header.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

$baseUrl = defined('BASE_URL') ? BASE_URL : '/';

/* ============================
   LOAD SITE SETTINGS (LOGO)
============================ */
$settings = $conn->query("SELECT * FROM site_settings LIMIT 1")->fetch_assoc();

$logo = $settings['logo_url'] 
    ? $settings['logo_url'] 
    : ($baseUrl . 'assets/img/logo.png'); // fallback
?>
<style>
.app-header {
    position: sticky;
    top: 0;
    z-index: 150;

    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;

    background: rgba(5, 7, 11, 0.72);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

/* LEFT: LOGO */
.app-header-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.app-header-left img.logo {
    height: 36px;
    display: block;
}

/* RIGHT: BUTTONS */
.app-header-right {
    display: flex;
    align-items: center;
    gap: 10px;
}

.header-btn {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.18);
    padding: 7px 11px;
    border-radius: 999px;
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    transition: 0.16s;
}

.header-btn:hover {
    background: rgba(255,255,255,0.14);
}

/* SEARCH BTN (BULAT) */
.search-btn {
    padding: 7px;
    border-radius: 999px;
}
.search-btn svg {
    width: 18px;
    height: 18px;
    stroke: #ffffff;
    stroke-width: 1.8;
}

/* LANGUAGE / CURRENCY */
.lang-btn-flag {
    width: 20px;
    height: 14px;
    border-radius: 3px;
    overflow: hidden;
}
.lang-btn-flag img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.lang-btn-text {
    color: #ffffff;
    font-size: 13px;
}

/* HAMBURGER */
.menu-btn {
    padding: 7px;
    border-radius: 999px;
}
.menu-btn svg {
    width: 20px;
    height: 20px;
    stroke: #ffffff;
    stroke-width: 1.8;
}
</style>

<header class="app-header">

    <div class="app-header-left">
        <!-- LOGO DIAMBIL DARI DATABASE -->
        <img src="<?php echo htmlspecialchars($logo); ?>" 
             alt="Logo" 
             class="logo">
    </div>

    <div class="app-header-right">

        <!-- SEARCH -->
        <button type="button" class="header-btn search-btn">
            <svg viewBox="0 0 24 24" fill="none">
                <circle cx="11" cy="11" r="6"></circle>
                <line x1="15.5" y1="15.5" x2="20" y2="20"></line>
            </svg>
        </button>

        <!-- LANGUAGE / CURRENCY -->
        <button type="button" class="header-btn">
            <span class="lang-btn-flag">
                <img src="<?php echo $baseUrl; ?>assets/img/flag-my.png">
            </span>
            <span class="lang-btn-text">MY / MYR</span>
        </button>

        <!-- HAMBURGER -->
        <button type="button" class="header-btn menu-btn" onclick="openSidebar()">
            <svg viewBox="0 0 24 24" fill="none">
                <line x1="4" y1="7"  x2="20" y2="7"></line>
                <line x1="4" y1="12" x2="20" y2="12"></line>
                <line x1="4" y1="17" x2="20" y2="17"></line>
            </svg>
        </button>

    </div>

</header>