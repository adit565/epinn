<?php
/**
 * Application Base Configuration
 */

/* ---------------------------------------
   START SESSION (elak double start error)
---------------------------------------- */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------------------------------------
   TIMEZONE
---------------------------------------- */
date_default_timezone_set('Asia/Kuala_Lumpur');

/* ---------------------------------------
   DETECT BASE URL AUTOMATICALLY
---------------------------------------- */
$https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$scheme = $https ? "https://" : "http://";

$host      = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');

// kalau dirname() pulangkan "/", kita kosongkan
if ($scriptDir === '/') {
    $scriptDir = '';
}

/**
 * BASE_URL
 * - Base URL ikut directory script semasa.
 * - Contoh:
 *   /public/index.php        → https://domain.com/public/
 *   /public/topup/mlbbmy.php → https://domain.com/public/topup/
 
 */
define('BASE_URL', $scheme . $host . $scriptDir . '/');

/**
 * APP_URL
 * - Base URL untuk root app (folder /public).
 * - Tak kira script sekarang di:
 *     /public/index.php
 *     /public/topup/mlbbmy.php
 *     /public/admin/games.php
 *   APP_URL akan sentiasa: https://domain.com/public/
 */
$appPath = $scriptDir;

// cari "/public" dalam path sekarang
$publicPos = strpos($scriptDir, '/public');
if ($publicPos !== false) {
    // ambil substring sampai hujung "/public"
    $appPath = substr($scriptDir, 0, $publicPos + strlen('/public'));
}

// pastikan ada 1 slash sahaja di hujung
define('APP_URL', rtrim($scheme . $host . $appPath, '/') . '/');

/* ---------------------------------------
   APPLICATION INFO
---------------------------------------- */
define('APP_NAME', 'Web Topup');

define('GAMEVIA_API_KEY', 'API-GV-13a5d0113faca65ba4491ace6828747e');

/* ---------------------------------------
   ERROR DISPLAY HANDLER
   - Localhost = show errors
   - Production = hide errors
---------------------------------------- */
$isLocal = in_array($host, ['localhost', '127.0.0.1']);

if ($isLocal) {
    // Development mode
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    // Production (cPanel)
    ini_set('display_errors', 0);
    error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_WARNING);
}

/* ---------------------------------------
   HELPER FUNCTION: Redirect
---------------------------------------- */
function redirect($url)
{
    // $url di sini boleh jadi 'login.php', 'dashboard.php', dll
    header("Location: " . APP_URL . ltrim($url, '/'));
    exit;
}

/* ---------------------------------------
   HELPER FUNCTION: Require Login
---------------------------------------- */
function require_login()
{
    if (!isset($_SESSION['user_id'])) {
        redirect('login.php');
    }
}