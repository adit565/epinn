<?php

$host = 'localhost'; // kebanyakan shared hosting guna 'localhost'
$user = 'laogames_lao';     // user penuh dari cPanel
$pass = 'Arif7660@';      // password user MySQL tadi
$db   = 'laogames_topup';     // nama database penuh

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");