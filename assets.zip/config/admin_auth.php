<?php
// config/admin_auth.php
require_once __DIR__ . '/app.php';
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$role = $_SESSION['role'] ?? null;

if (!isset($_SESSION['user_id']) || $role !== 'admin') {
    // bukan admin -> tendang ke login biasa
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}